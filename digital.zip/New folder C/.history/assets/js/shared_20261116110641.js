import { getSupabase, getUser, isSupabaseConfigured } from "./supabase.js";

const navItems = [
  ["Blogs", "blog.html"], ["News", "news.html"], ["Classifieds", "classifieds.html"],
  ["Add Product", "deals.html"], ["Businesses", "business.html"], ["Jobs", "jobs.html"],
  ["SEO Tools", "seo-tools.html"], ["Contact", "community.html"]
];

export function renderHeader() {
  const root = document.querySelector("#site-header");
  if (!root) return;
  root.innerHTML = `<div class="announcement"><div class="container announcement-inner"><span><i class="live-dot"></i> India's digital community, all in one place <span class="connection-status" id="connection-status" data-state="checking">Checking Supabase…</span></span><a href="deals.html">Add a product <span aria-hidden="true">↗</span></a></div></div>
    <header class="site-header"><div class="container nav-wrap">
      <a class="brand" href="index.html" aria-label="DigitalDuniya360 home"><span class="brand-mark">D<span>360</span></span><span class="brand-name">DigitalDuniya<span>360</span><small>All in one place</small></span></a>
      <button class="menu-toggle" aria-label="Open navigation" aria-expanded="false"><span></span><span></span></button>
      <nav class="main-nav" aria-label="Main navigation"><a href="index.html">Home</a>${navItems.map(([label, url]) => `<a href="${url}">${label}</a>`).join("")}</nav>
      <div class="nav-actions"><a class="nav-login" href="login.html">Log in</a><button class="nav-logout" type="button" hidden>Log out</button><a class="button button-small" href="post-ad.html">Post free ad <span>↗</span></a></div>
    </div></header>`;
  const toggle = root.querySelector(".menu-toggle");
  toggle.addEventListener("click", () => {
    const expanded = toggle.getAttribute("aria-expanded") === "true";
    toggle.setAttribute("aria-expanded", String(!expanded));
    root.querySelector(".main-nav").classList.toggle("is-open", !expanded);
  });
  refreshAccountLinks(root);
}

async function refreshAccountLinks(root) {
  if (!isSupabaseConfigured) return;
  try {
    const user = await getUser();
    const login = root.querySelector(".nav-login");
    const logout = root.querySelector(".nav-logout");
    if (user && login) { login.href = "user-dashboard.html"; login.textContent = "My dashboard"; }
    if (logout) {
      logout.hidden = !user;
      logout.addEventListener("click", async () => {
        try {
          const supabase = await getSupabase();
          const { error } = await supabase.auth.signOut();
          if (error) throw error;
          location.href = "index.html";
        } catch (error) {
          showToast(error.message, "error");
        }
      });
    }
  } catch (error) { console.error("Could not check the current session:", error); }
}

export function renderFooter() {
  const root = document.querySelector("#site-footer");
  if (!root) return;
  root.innerHTML = `<footer class="site-footer"><div class="container footer-main">
    <div class="footer-brand"><a class="brand brand-light" href="index.html"><span class="brand-mark">D<span>360</span></span><span class="brand-name">DigitalDuniya<span>360</span><small>All in one place</small></span></a><p>A place to discover, share and grow with India's digital community.</p></div>
    <div class="footer-col"><h3>Explore</h3><a href="blog.html">Blogs</a><a href="news.html">News</a><a href="classifieds.html">Classifieds</a><a href="deals.html">Add Product</a></div>
    <div class="footer-col"><h3>For business</h3><a href="business.html">Business directory</a><a href="add-business.html">Add a business</a><a href="jobs.html">Find jobs</a><a href="post-job.html">Post a job</a></div>
    <div class="footer-col"><h3>Connect</h3><a href="community.html">Contact form</a><a href="interactive.html">Quiz & polls</a><a href="seo-tools.html">Free SEO tools</a><a href="register.html">Create an account</a></div>
  </div><div class="container footer-bottom"><span>© ${new Date().getFullYear()} DigitalDuniya360</span><span>Made for India's digital journey.</span><a href="community.html">Contact us</a></div></footer>`;
}

export function showToast(message, type = "success", timeout = 4000) {
  const root = document.querySelector("#toast-root");
  if (!root) return;
  const node = document.createElement("div");
  node.className = `toast toast-${type}`;
  node.setAttribute("role", "status");
  node.textContent = message;
  root.append(node);
  setTimeout(() => node.remove(), timeout);
}

export function escapeHtml(value = "") {
  return String(value).replace(/[&<>"']/g, (c) => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
}

export function formatDate(value) {
  if (!value) return "Date not set";
  return new Intl.DateTimeFormat("en-IN", { day: "numeric", month: "short", year: "numeric" }).format(new Date(value));
}

export async function queryPublic(table, { search = "", category = "", city = "", workType = "", salary = "", minPrice = "", maxPrice = "", sort = "", limit = 60 } = {}) {
  const supabase = await getSupabase();
  if (!supabase) return [];
  let query = supabase.from(table).select("*").eq("status", "published");
  if (table === "classified_ads" && sort === "price_asc") query = query.order("price", { ascending: true, nullsFirst: false });
  else if (table === "classified_ads" && sort === "price_desc") query = query.order("price", { ascending: false, nullsFirst: false });
  else query = query.order("created_at", { ascending: false });
  if (category) query = query.eq("category", category);
  if (city && ["classified_ads","jobs","businesses"].includes(table)) query = query.ilike("city", `%${city}%`);
  if (workType && table === "jobs") query = query.eq("work_type", workType);
  if (salary && table === "jobs") query = query.ilike("salary", `%${salary}%`);
  if (minPrice && table === "classified_ads") query = query.gte("price", Number(minPrice));
  if (maxPrice && table === "classified_ads") query = query.lte("price", Number(maxPrice));
  const searchColumns = {
    blog_posts: "title", news_articles: "title", classified_ads: "title", deals: "title",
    coupons: "title", businesses: "name", jobs: "title"
  };
  if (search && searchColumns[table]) query = query.ilike(searchColumns[table], `%${search.replace(/[%_,]/g, " ")}%`);
  const { data, error } = await query.limit(limit);
  if (error) throw error;
  return data || [];
}

export function emptyState(title = "Nothing here just yet", description = "Check back soon — new content is added regularly.", action = "") {
  return `<div class="empty-state"><span class="empty-icon">✳</span><h3>${escapeHtml(title)}</h3><p>${escapeHtml(description)}</p>${action}</div>`;
}

export function setPageTitle(title, description) {
  document.title = `${title} | DigitalDuniya360`;
  const meta = document.querySelector('meta[name="description"]');
  if (meta) meta.content = description;
}
