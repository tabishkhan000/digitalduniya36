import { getSupabase, isSupabaseConfigured } from "./supabase.js";
import { renderPage } from "./pages.js";
import { renderHeader, renderFooter, showToast } from "./shared.js";
import { initializeConnectionStatus, watchNetworkStatus } from "./common.js";

const page = document.body.dataset.page || "home";

if (page !== "admin") {
  renderHeader();
  renderFooter();
  initializeConnectionStatus();
  watchNetworkStatus();
}
renderPage(page).catch((error) => {
  console.error(error);
  const app = document.querySelector("#app");
  if (app) app.innerHTML = `<section class="container error-panel"><span class="eyebrow">Something went wrong</span><h1>We couldn't load this page.</h1><p>${escapeText(error.message || "Please try again later.")}</p><button class="button button-outline" onclick="location.reload()">Try again</button></section>`;
});

if (!isSupabaseConfigured) showToast("Supabase configuration is invalid. Check assets/js/config.js.", "error", 7000);

const escapeText = (value) => String(value).replace(/[&<>"']/g, (c) => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
