import { getProfile, getSupabase, getUser, isSupabaseConfigured, submitOwned, uploadAdImage, uploadOwnedImage } from "./supabase.js";
import { emptyState, escapeHtml, formatDate, queryPublic, setPageTitle, showToast } from "./shared.js";
import { requestPasswordReset, signOut, submitAuthForm } from "./auth.js";
import { changeOwnPassword, loadOwnSubmissions, removeOwnSubmission, saveProfile } from "./dashboard.js";
import { checkModeratorAccess, createModeratedRecord, deleteModeratedRecord, grantUserRole, moderateRecord as updateModeratedRecord, revokeUserRole } from "./admin.js";
import { homepageStats } from "./homepage-stats.js";

const CONTACT_WEB_APP_URL = "https://script.google.com/macros/s/AKfycbw4Vcyx7Gc3NFzdQuR-wUp83VDX4gAQrjwV0_jhntY4IxGHShCzhrj6YzpkEH2xDtzx3g/exec";

const categoryMap = {
  blog_posts: ["Technology", "Business", "Digital Marketing", "SEO", "AI Tools", "Finance", "Education", "Lifestyle"],
  news_articles: ["India News", "Technology News", "Business News", "Startup News", "Education News", "Finance News"],
  classified_ads: ["Property", "Cars and Bikes", "Mobiles", "Electronics", "Furniture", "Jobs", "Services", "Business Opportunities", "General Products"],
  deals: ["Electronics", "Fashion", "Home and Kitchen", "Mobiles", "Beauty and Personal Care", "Software", "Other"],
  coupons: ["Shopping", "Electronics", "Software", "AI Tools", "Hosting", "Domains"],
  businesses: ["Digital Marketing", "Solar Companies", "Real Estate", "Hotels", "Restaurants", "Education", "Healthcare", "IT Companies", "Manufacturers", "Professional Services"],
  jobs: ["Technology", "Marketing", "Design", "Sales", "Finance", "Education", "Other"]
};

const listings = {
  blog: { title: "Ideas worth sharing.", subtitle: "Fresh perspectives on technology, business and the ideas shaping tomorrow.", table: "blog_posts", item: "articles", action: "Write a blog", actionHref: "user-dashboard.html", crumb: "Blogs" },
  news: { title: "News that moves you.", subtitle: "A considered view of the latest stories from India, technology, business and more.", table: "news_articles", item: "stories", crumb: "News" },
  classifieds: { title: "Find it. Sell it. Share it.", subtitle: "Browse local listings or post a free ad for your products and services.", table: "classified_ads", item: "ads", crumb: "Classifieds", action: "Post free ad", actionHref: "post-ad.html" },
  deals: { title: "Good finds. Better value.", subtitle: "Browse deals and offers published by our community. Verify the terms with the seller before purchase.", table: "deals", item: "deals", crumb: "Deals", disclosure: true },
  coupons: { title: "Offers, without the guesswork.", subtitle: "Browse verified coupon listings. Availability and terms are set by each seller.", table: "coupons", item: "coupons", crumb: "Coupons", disclosure: true },
  business: { title: "Meet businesses doing great work.", subtitle: "Discover local businesses and professional services across India.", table: "businesses", item: "businesses", crumb: "Business directory", action: "Add your business", actionHref: "add-business.html" },
  jobs: { title: "Your next opportunity starts here.", subtitle: "Explore new openings and career opportunities shared by employers.", table: "jobs", item: "jobs", crumb: "Jobs", action: "Post a job", actionHref: "post-job.html" }
};

const formSpecs = {
  "post-ad": { title: "Post a free classified ad", intro: "Describe your listing clearly. Your ad is published as soon as it is submitted.", table: "classified_ads", fields: [
    ["title","Ad title","text",true],["category","Category","select",true],["price","Price in ₹","number",false],["city","City","text",true],["state","State","text",true],["description","Description","textarea",true],["seller_name","Seller name","text",true],["phone","Phone number","tel",true],["whatsapp","WhatsApp number","tel",false],["website_url","Website URL","text",false],["images","Photos","file",false]
  ]},
  "add-business": { title: "Add your business", intro: "Create a useful business profile. Submissions are reviewed before publication.", table: "businesses", fields: [
    ["name","Business name","text",true],["category","Category","select",true],["city","City","text",true],["website","Website","url",false],["phone","Phone","tel",false],["whatsapp","WhatsApp","tel",false],["address","Address","text",false],["description","About your business","textarea",true],["images","Business photos","file",false]
  ]},
  "post-job": { title: "Share a job opportunity", intro: "Give candidates a clear picture of the role, requirements and application process.", table: "jobs", fields: [
    ["title","Job title","text",true],["company_name","Company","text",true],["category","Category","select",true],["city","Location / city","text",true],["work_type","Work type","select",true],["salary","Salary range","text",false],["experience","Experience required","text",false],["apply_url","Application URL or email","text",true],["deadline","Application deadline","date",false],["description","Job description","textarea",true],["skills","Skills (comma separated)","text",false]
  ]},
  "submit-blog": { title: "Submit a blog article", intro: "Share original, useful writing with the community. Articles are pending review until approved.", table: "blog_posts", fields: [
    ["title","Article title","text",true],["website_url","Website URL","text",true],["category","Category","select",true],["summary","Short description","textarea",true],["content","Full article","textarea",true],["featured_image","Featured image","file",false],["seo_title","SEO title","text",false],["meta_description","Meta description","text",false],["tags","Tags (comma separated)","text",false]
  ]}
};

const details = {
  "blog-details": { table: "blog_posts", name: "article" },
  "news-details": { table: "news_articles", name: "news story" },
  "ad-details": { table: "classified_ads", name: "ad" },
  "business-details": { table: "businesses", name: "business" },
  "job-details": { table: "jobs", name: "job" }
};

const categories = [
  ["Technology","⌘","blog.html?category=Technology"],["Business","↗","business.html"],["Education","▤","blog.html?category=Education"],["Property","⌂","classifieds.html?category=Property"],
  ["Electronics","▣","classifieds.html?category=Electronics"],["Jobs","◷","jobs.html"],["Digital Marketing","◎","blog.html?category=Digital%20Marketing"],["Shopping","◇","deals.html"]
];

export async function renderPage(page) {
  const app = document.querySelector("#app");
  if (!app) return;
  if (page === "home") return renderHome(app);
  if (page === "contact" || page === "community") return renderContact(app);
  if (page === "deals" || page === "coupons") return renderOffersPage(app);
  if (page === "search") return renderSearch(app);
  if (listings[page]) return renderListing(app, page);
  if (formSpecs[page]) return renderForm(app, formSpecs[page]);
  if (details[page]) return renderDetail(app, details[page], page);
  if (page === "seo-tools") return renderTools(app);
  if (page === "login" || page === "register") return renderAuth(app, page);
  if (page === "user-dashboard") return renderDashboard(app);
  if (page === "admin") return renderAdmin(app);
  if (page === "interactive") return renderInteractive(app);
  app.innerHTML = `<section class="container error-panel"><h1>Page not found</h1><p>We couldn't find that page.</p><a class="button" href="index.html">Back to home</a></section>`;
}

function renderContact(app) {
  const description = "Contact DigitalDuniya360 using our online message form.";
  setPageTitle("Contact us", description);
  app.innerHTML = `<section class="page-hero"><div class="container"><div class="breadcrumb"><a href="index.html">Home</a> / Contact</div><span class="eyebrow">Get in touch</span><h1>Contact us</h1><p>Have a question or feedback? Send us a message using this form.</p></div></section>
    <section class="section"><div class="container"><div class="form-card contact-form-card"><p class="contact-form-notice" role="note">The form confirms receipt only after the Google Apps Script service returns success. Please do not include passwords or other highly sensitive information.</p>
      <form id="contact-form" autocomplete="off" data-captcha-required="false">
        <div class="contact-honeypot" aria-hidden="true"><label for="contact-extra-check">Leave this field empty</label><input id="contact-extra-check" name="contact_extra_check" type="text" autocomplete="new-password" autocapitalize="off" spellcheck="false" tabindex="-1"></div>
        <div class="form-grid">
          <div class="field"><label for="contact-name">Full name *</label><input id="contact-name" name="name" autocomplete="name" minlength="2" maxlength="120" required></div>
          <div class="field"><label for="contact-email">Email address *</label><input id="contact-email" name="email" type="email" autocomplete="email" maxlength="254" required></div>
          <div class="field"><label for="contact-phone">Phone number</label><input id="contact-phone" name="phone" type="tel" autocomplete="tel" pattern="\\+?[0-9\\s.\\(\\)\\-]{7,30}" title="Enter a valid phone number, or leave this field empty." maxlength="30"></div>
          <div class="field"><label for="contact-subject">Subject *</label><input id="contact-subject" name="subject" minlength="3" maxlength="160" required></div>
          <div class="field full"><label for="contact-message">Message *</label><textarea id="contact-message" name="message" minlength="10" maxlength="5000" required></textarea></div>
          <!-- Add a CAPTCHA widget here and expose its verifier as window.digitalDuniyaContactCaptcha.verify(form). -->
          <div class="field full" id="contact-captcha-slot" data-captcha-slot></div>
        </div><div class="form-submit"><button class="button" type="submit">Send message ↗</button><span class="form-message" aria-live="polite"></span></div>
      </form>
    </div></div></section>`;
  const form = app.querySelector("#contact-form");
  let lastAttemptAt = 0;
  let isSubmitting = false;
  form.addEventListener("submit", async event => {
    event.preventDefault();
    if (isSubmitting) return;
    const message = form.querySelector(".form-message");
    const button = form.querySelector('button[type="submit"]');
    message.textContent = "";
    message.classList.remove("form-error", "form-success");
    if (!form.reportValidity()) return;
    if (form.elements.namedItem("contact_extra_check").value.trim()) {
      message.textContent = "We couldn't verify this submission. Please try again.";
      message.classList.add("form-error");
      return;
    }
    if (Date.now() - lastAttemptAt < 10000) {
      message.textContent = "Please wait a moment before trying again.";
      message.classList.add("form-error");
      return;
    }
    const captcha = window.digitalDuniyaContactCaptcha;
    if (form.dataset.captchaRequired === "true" && typeof captcha?.verify !== "function") {
      message.textContent = "Complete the CAPTCHA check before submitting.";
      message.classList.add("form-error");
      return;
    }

    const values = Object.fromEntries(new FormData(form));
    const payload = {
      name: values.name.trim(),
      email: values.email.trim(),
      phone: values.phone.trim(),
      subject: values.subject.trim(),
      message: values.message.trim()
    };
    if (payload.name.length < 2 || !payload.email || payload.subject.length < 3 || payload.message.length < 10) {
      message.textContent = "Check the required fields and try again.";
      message.classList.add("form-error");
      return;
    }

    isSubmitting = true;
    lastAttemptAt = Date.now();
    button.disabled = true;
    form.setAttribute("aria-busy", "true");
    button.textContent = "Sending…";
    message.textContent = "Sending your message…";
    try {
      // CAPTCHA adapters must finish their challenge and verification before returning true.
      if (typeof captcha?.verify === "function" && await captcha.verify(form) !== true) {
        throw new Error("Complete the CAPTCHA check before submitting.");
      }
      const response = await fetch(CONTACT_WEB_APP_URL, {
        method: "POST",
        headers: { "Content-Type": "text/plain;charset=utf-8" },
        body: JSON.stringify(payload),
        mode: "cors",
        redirect: "follow",
        credentials: "omit",
        cache: "no-store"
      });
      const responseHost = new URL(response.url).hostname;
      if (responseHost === "accounts.google.com") {
        throw new Error("The Apps Script web app requires sign-in. Set its deployment access so website visitors can use it.");
      }
      if (!["script.google.com", "script.googleusercontent.com"].includes(responseHost)) {
        throw new Error("The contact service redirected outside Google Apps Script, so your message was not confirmed.");
      }
      if (!response.ok) throw new Error(`The contact service returned an error (${response.status}).`);
      if (response.type === "opaque" || response.type === "opaqueredirect") {
        throw new Error("The contact service response could not be read, so your message was not confirmed.");
      }
      let result;
      try {
        result = await response.json();
      } catch {
        throw new Error("The contact service did not return a readable confirmation. Your message was not confirmed.");
      }
      if (result?.success !== true) {
        const detail = typeof result?.message === "string" && result.message.trim() ? ` ${result.message.trim()}` : "";
        throw new Error(`The contact service did not confirm receipt.${detail}`);
      }
      form.reset();
      captcha?.reset?.();
      message.textContent = "Thank you. Your message was submitted successfully.";
      message.classList.add("form-success");
    } catch (error) {
      console.error("Contact form submission was not confirmed:", error);
      message.textContent = error instanceof TypeError
        ? "We couldn't confirm that your message was received. Check that the Apps Script web app allows public access and browser requests; it may have received your message."
        : error.message || "We couldn't confirm your submission. Please try again later.";
      message.classList.add("form-error");
    } finally {
      isSubmitting = false;
      button.disabled = false;
      button.textContent = "Send message ↗";
      form.removeAttribute("aria-busy");
    }
  });
}

function renderHome(app) {
  setPageTitle(homepageStats.seoTitle, homepageStats.seoDescription);
  app.innerHTML = `<section class="hero"><div class="container hero-grid">
    <div><span class="eyebrow">India's digital community</span><h1>Discover everything.<br><em>All in one place.</em></h1><p class="hero-copy">Explore businesses, discover amazing deals, find jobs, publish free advertisements and connect with India's digital community.</p>
      <form class="search-box" id="universal-search"><input name="q" aria-label="Search all of DigitalDuniya360" placeholder="What are you looking for today?"><button class="button" type="submit">Search <span>↗</span></button></form>
      <div class="search-tabs">${[["All","index.html"],["Blogs","blog.html"],["Products","classifieds.html"],["Businesses","business.html"],["Jobs","jobs.html"],["Classifieds","classifieds.html"]].map(([n,l])=>`<a href="${l}">${n}</a>`).join("")}</div>
    </div><div class="hero-art" aria-hidden="true"><div class="orbit"></div><div class="art-center"><strong>DD<span style="font-size:15px">360</span></strong><small>All in one place</small></div><div class="float-chip chip-one"><b>⌕</b> Discover local</div><div class="float-chip chip-two"><b>↗</b> Grow together</div><div class="float-chip chip-three"><b>✳</b> Made for India</div></div>
  </div></section>
  <section class="section"><div class="container"><div class="section-head"><div><span class="eyebrow">Explore your interests</span><h2>One platform. Many possibilities.</h2><p>Find your next idea, opportunity or trusted connection.</p></div><a class="text-link" href="search.html">Browse all sections ↗</a></div><div class="category-grid">${categories.map(([n,i,l])=>`<a class="category-card" href="${l}"><span class="category-icon">${i}</span><span><strong>${n}</strong><small>Explore ${n.toLowerCase()}</small></span></a>`).join("")}</div></div></section>
  <section class="section section-white"><div class="container homepage-stat-section">
    ${renderHomepageStatGroup(homepageStats.statistics.community)}
    ${renderHomepageStatGroup(homepageStats.statistics.business)}
    <p class="homepage-stat-note">${escapeHtml(homepageStats.statistics.note)}</p>
  </div></section>
  <section class="section section-white"><div class="container"><div class="section-head"><div><span class="eyebrow">Community offers</span><h2>Products & coupons</h2><p>Shop offers shared by the community. Some links may earn us a commission.</p></div><a class="text-link" href="deals.html">Browse products or add one ↗</a></div><div class="content-grid" id="home-deals">${loadingCards()}</div></div></section>
  <section class="section"><div class="container"><div class="section-head"><div><span class="eyebrow">From the community</span><h2>Ideas and updates</h2></div><a class="text-link" href="blog.html">Read all blogs ↗</a></div><div class="content-grid" id="home-blogs">${loadingCards()}</div></div></section>
  <section class="section section-white"><div class="container"><div class="section-head"><div><span class="eyebrow">Around the country</span><h2>Latest news</h2></div><a class="text-link" href="news.html">More news ↗</a></div><div class="content-grid" id="home-news">${loadingCards()}</div></div></section>
  <section class="section"><div class="container"><div class="section-head"><div><span class="eyebrow">Local connections</span><h2>Recently published classifieds</h2></div><a class="text-link" href="classifieds.html">See listings ↗</a></div><div class="content-grid" id="home-ads">${loadingCards()}</div></div></section>
  <section class="section section-white"><div class="container"><div class="section-head"><div><span class="eyebrow">Discover and grow</span><h2>Business & career opportunities</h2></div><a class="text-link" href="business.html">Explore directory ↗</a></div><div class="content-grid" id="home-businesses">${loadingCards()}</div><div style="height:16px"></div><div class="content-grid" id="home-jobs">${loadingCards()}</div></div></section>
  <section class="section section-beige"><div class="container"><div class="section-head"><div><span class="eyebrow">Useful, free and simple</span><h2>Tools for your digital journey</h2><p>Practical browser-based tools that keep your data on your device.</p></div><a class="text-link" href="seo-tools.html">Explore all 14 tools ↗</a></div><div class="content-grid">${["Word & character counter","Meta tag generator","QR code generator"].map((x,i)=>`<a class="content-card" href="seo-tools.html"><span class="tag">Free tool</span><h3>${x}</h3><p>Quick, private and ready to use in your browser.</p><span class="card-bottom">Try this tool ↗</span></a>`).join("")}</div></div></section>
  <section class="section section-beige"><div class="container"><div class="section-head"><div><span class="eyebrow">${escapeHtml(homepageStats.whyChoose.eyebrow)}</span><h2>${escapeHtml(homepageStats.whyChoose.title)}</h2></div></div><div class="why-grid">${homepageStats.whyChoose.items.map(item=>`<article class="why-card"><span class="why-icon" aria-hidden="true">${escapeHtml(item.icon)}</span><h3>${escapeHtml(item.title)}</h3><p>${escapeHtml(item.description)}</p></article>`).join("")}</div></div></section>
  <section class="section section-white"><div class="container"><article class="privacy-panel"><span class="privacy-icon" aria-hidden="true">◎</span><div><span class="eyebrow">${escapeHtml(homepageStats.privacy.eyebrow)}</span><h2>${escapeHtml(homepageStats.privacy.title)}</h2><p>${escapeHtml(homepageStats.privacy.description)}</p></div></article></div></section>
  <section class="section"><div class="container"><div class="split-cta join-cta"><div><span class="eyebrow">${escapeHtml(homepageStats.join.eyebrow)}</span><h2>${escapeHtml(homepageStats.join.headline)}</h2><p>${escapeHtml(homepageStats.join.description)}</p></div><div class="join-actions">${homepageStats.join.buttons.map(button=>`<a class="button ${button.style==="secondary"?"button-outline join-secondary":""}" href="${escapeHtml(button.href)}">${escapeHtml(button.label)} ↗</a>`).join("")}</div></div></div></section>
  <section class="section"><div class="container split-cta"><div><h2>Notes worth opening.</h2><p>Get occasional updates, useful resources and community news. Unsubscribe any time.</p></div><form class="newsletter" id="newsletter-form"><input type="email" name="email" placeholder="Your email address" aria-label="Your email address" required><button class="button" type="submit">Subscribe ↗</button></form></div></section>`;
  animateHomepageStats(app);
  app.querySelector("#universal-search").addEventListener("submit", (event) => {
    event.preventDefault();
    const q = new URLSearchParams(new FormData(event.currentTarget)).get("q").trim();
    location.href = `search.html${q ? `?q=${encodeURIComponent(q)}` : ""}`;
  });
  app.querySelector("#newsletter-form").addEventListener("submit", subscribeNewsletter);
  loadHomeSection("home-deals", "deals", "deals.html");
  loadHomeSection("home-blogs", "blog_posts", "blog.html");
  loadHomeSection("home-news", "news_articles", "news.html");
  loadHomeSection("home-ads", "classified_ads", "classifieds.html");
  loadHomeSection("home-businesses", "businesses", "business.html");
  loadHomeSection("home-jobs", "jobs", "jobs.html");
}

function renderHomepageStatGroup(group) {
  return `<section class="homepage-stat-group"><div class="section-head"><div><span class="eyebrow">${escapeHtml(group.eyebrow)}</span><h2>${escapeHtml(group.title)}</h2><p>${escapeHtml(group.description)}</p></div></div><div class="homepage-stat-grid">${group.items.map(item=>{
    const value = homepageStats[item.key];
    return `<article class="homepage-stat-card"><span class="homepage-stat-icon" aria-hidden="true">${escapeHtml(item.icon)}</span><strong class="homepage-stat-value" data-stat-value="${escapeHtml(value)}">${escapeHtml(value)}</strong><span class="homepage-stat-label">${escapeHtml(item.label)}</span></article>`;
  }).join("")}</div></section>`;
}

function animateHomepageStats(root) {
  if (!("IntersectionObserver" in window) || window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (!entry.isIntersecting) return;
      observer.unobserve(entry.target);
      const element = entry.target;
      const rawValue = element.dataset.statValue;
      const target = Number(rawValue.replace(/[^\d]/g, ""));
      if (!Number.isFinite(target)) return;
      const suffix = rawValue.replace(/^[\d,]+/, "");
      const duration = 1100;
      const start = performance.now();
      const tick = now => {
        const progress = Math.min((now - start) / duration, 1);
        const eased = 1 - Math.pow(1 - progress, 3);
        element.textContent = `${new Intl.NumberFormat("en-IN").format(Math.round(target * eased))}${suffix}`;
        if (progress < 1) requestAnimationFrame(tick);
      };
      requestAnimationFrame(tick);
    });
  }, { threshold: .35 });
  root.querySelectorAll("[data-stat-value]").forEach(element => observer.observe(element));
}

function loadingCards() { return `<div class="empty-state"><span class="empty-icon">···</span><h3>Loading published content</h3></div>`; }

async function renderSearch(app) {
  const term = new URLSearchParams(location.search).get("q")?.trim() || "";
  setPageTitle(term ? `Search: ${term}` : "Search", "Search published articles, businesses, jobs and listings.");
  app.innerHTML = `<section class="page-hero"><div class="container"><span class="eyebrow">Search all sections</span><h1>Find what you're looking for.</h1><form class="search-box" id="search-form"><input name="q" value="${escapeHtml(term)}" aria-label="Search all sections" placeholder="Search articles, jobs, businesses and more"><button class="button" type="submit">Search ↗</button></form></div></section><section class="section"><div class="container"><div class="section-head"><div><h2>${term ? `Results for “${escapeHtml(term)}”` : "Search DigitalDuniya360"}</h2><p>Only published content is included.</p></div></div><div class="list-grid" id="search-results">${term ? loadingCards() : emptyState("Enter a search term","Search blogs, news, classifieds, deals, coupons, businesses and jobs.")}</div></div></section>`;
  app.querySelector("#search-form").addEventListener("submit", event => {
    event.preventDefault();
    const value = new FormData(event.currentTarget).get("q").trim();
    location.href = `search.html?q=${encodeURIComponent(value)}`;
  });
  if (!term) return;
  const sources = [
    ["Articles","blog_posts","blog-details.html"],["News","news_articles","news-details.html"],
    ["Classifieds","classified_ads","ad-details.html"],["Deals","deals","deals.html"],
    ["Coupons","coupons","coupons.html"],["Businesses","businesses","business-details.html"],
    ["Jobs","jobs","job-details.html"]
  ];
  try {
    const groups = await Promise.all(sources.map(async ([label,table,href]) => ({
      label, href, table, rows: await queryPublic(table,{search:term,limit:12})
    })));
    const rows = groups.flatMap(group => group.rows.map(row => ({...row,label:group.label,href:group.href,table:group.table})));
    app.querySelector("#search-results").innerHTML = rows.length ? rows.map(row => {
      const listing = row.table === "deals" || row.table === "coupons";
      const href = listing ? `${row.href}?q=${encodeURIComponent(term)}` : `${row.href}?slug=${encodeURIComponent(row.slug || row.id)}`;
      return `<a class="data-card" href="${href}"><span class="tag">${escapeHtml(row.label)}</span><h2>${escapeHtml(row.title || row.name || row.company_name || "Untitled")}</h2><p>${escapeHtml(row.summary || row.description || "Open this result to learn more.")}</p><span class="data-bottom"><span>${escapeHtml(row.category || "")}</span><span>Open result ↗</span></span></a>`;
    }).join("") : emptyState("No matching results","Try a different search phrase or browse one of the sections.");
  } catch(error) {
    console.error(error);
    app.querySelector("#search-results").innerHTML = emptyState("Search could not be completed",error.message);
  }
}

async function loadHomeSection(id, table, href) {
  const root = document.getElementById(id);
  try {
    const rows = await queryPublic(table, { limit: 3 });
    root.innerHTML = rows.length ? rows.map((row) => {
      const detail = {blog_posts:"blog-details.html",news_articles:"news-details.html",classified_ads:"ad-details.html",businesses:"business-details.html",jobs:"job-details.html"}[table];
      const target = table === "deals" ? safeHttpUrl(row.affiliate_url) : detail ? `${detail}?slug=${encodeURIComponent(row.slug || row.id)}` : `${href}?q=${encodeURIComponent(row.title || "")}`;
      const price = table === "deals" && row.sale_price !== null && row.sale_price !== undefined ? `<p><strong>₹${escapeHtml(row.sale_price)}</strong>${row.discount_percentage ? ` · ${escapeHtml(row.discount_percentage)}% off` : ""}</p>` : "";
      const imageUrl = table === "deals" && row.image_url ? safeHttpUrl(row.image_url) : "#";
      const image = imageUrl !== "#" ? `<img class="offer-image" src="${escapeHtml(imageUrl)}" alt="" loading="lazy" referrerpolicy="no-referrer">` : "";
      const isOffer = table === "deals";
      return `<a class="content-card" href="${escapeHtml(target)}" ${isOffer ? `target="_blank" rel="sponsored nofollow noopener noreferrer" data-affiliate-id="${escapeHtml(row.id)}" data-affiliate-table="deals"` : ""}>${image}<span class="card-meta"><span class="tag">${escapeHtml(row.merchant || row.category || "Community")}</span><span>${formatDate(row.created_at)}</span></span><h3>${escapeHtml(row.title || row.name || row.company_name || "Untitled")}</h3><p>${escapeHtml(row.description || "Open this listing to learn more.")}</p>${price}${row.coupon_code ? `<p>Coupon: <strong>${escapeHtml(row.coupon_code)}</strong></p>` : ""}<span class="card-bottom">${isOffer ? "Shop offer ↗" : "Explore more ↗"}</span></a>`;
    }).join("") : emptyState("New stories are on the way", "There is no published content in this section yet. Check back soon.", `<a class="button button-outline" href="${href}">Explore section</a>`);
    attachAffiliateTracking(root);
  } catch (error) { console.error(`Loading ${table} failed:`, error); root.innerHTML = emptyState("Content could not be loaded", error.message); }
}

async function renderOffersPage(app) {
  const title = "Add Product";
  const intro = "Post a product or discount code with an Amazon, Flipkart, Meesho or other website link. Published offers appear on the homepage right away.";
  setPageTitle(title, intro);
  app.innerHTML = `<section class="page-hero"><div class="container"><div class="breadcrumb"><a href="index.html">Home</a> / Add Product</div><span class="eyebrow">Community marketplace</span><h1>Add a product or coupon.</h1><p>${intro}</p><div class="disclosure">Affiliate disclosure: some links may earn DigitalDuniya360 or the person who shared the offer a commission. Offers are shared by users, not verified or guaranteed by the merchant; check the price and terms before buying.</div></div></section>
    <section class="section"><div class="container form-layout"><form class="form-card" id="offer-form"><h2>Product details</h2><p>Sign in is required to reduce spam. Your offer will be published immediately.</p><div class="form-grid">
      <div class="field"><label for="offer-type">Offer type *</label><select id="offer-type" name="offer_type" required><option value="product">Product deal</option><option value="coupon">Coupon code</option></select></div>
      <div class="field"><label for="offer-title">Product / offer title *</label><input id="offer-title" name="title" maxlength="160" required></div>
      <div class="field"><label for="offer-merchant">Store / website *</label><select id="offer-merchant" name="merchant" required><option value="">Choose a store or website</option><option>Amazon</option><option>Flipkart</option><option>Meesho</option><option>Website</option></select></div>
      <div class="field"><label for="offer-category">Category *</label><select id="offer-category" name="category" required><option value="">Choose a category</option>${categoryMap.deals.map(value => `<option>${escapeHtml(value)}</option>`).join("")}</select></div>
      <div class="field"><label for="offer-original-price">Original price (₹)</label><input id="offer-original-price" name="original_price" type="number" min="0" step="0.01"></div>
      <div class="field"><label for="offer-sale-price">Offer price (₹)</label><input id="offer-sale-price" name="sale_price" type="number" min="0" step="0.01"></div>
      <div class="field"><label for="offer-coupon-code">Coupon code</label><input id="offer-coupon-code" name="coupon_code" maxlength="80"></div>
      <div class="field"><label for="offer-expires">Expiry date</label><input id="offer-expires" name="expires_at" type="date"></div>
      <div class="field full"><label for="offer-url">Product / affiliate link *</label><input id="offer-url" name="affiliate_url" type="url" placeholder="https://..." required><small>Use a secure HTTPS link. Amazon, Flipkart and Meesho links must match the selected store; Website accepts any HTTPS address.</small></div>
      <div class="field full"><label for="offer-image">Product image (optional)</label><input id="offer-image" name="product_image" type="file" accept="image/jpeg,image/png,image/webp"><small>Upload one JPG, PNG or WebP image, up to 5 MB.</small></div>
      <div class="field full"><label for="offer-description">Details</label><textarea id="offer-description" name="description" maxlength="1200"></textarea></div>
    </div><div class="form-submit"><button class="button" type="submit">Publish offer ↗</button><span class="form-message" aria-live="polite"></span></div><p class="form-message" id="offer-login-note">Posting requires an account. <a href="login.html">Log in</a> or <a href="register.html">create a free account</a>.</p></form>
    <aside class="side-note"><h3>Before you post</h3><ul><li>Choose Amazon, Flipkart, Meesho or Website and use its HTTPS link.</li><li>Make sure the price, discount and coupon code are accurate.</li><li>Do not post misleading, unsafe or unrelated links.</li><li>Offers appear publicly as soon as submitted. Admins may remove misleading posts.</li></ul></aside></div></section>
    <section class="section section-white"><div class="container"><div class="section-head"><div><span class="eyebrow">Shared by the community</span><h2>Latest offers</h2><p>Clicking an offer opens the store in a new tab.</p></div></div><div class="list-controls"><input id="offer-search" placeholder="Search products and coupons" aria-label="Search offers"><select id="offer-category" aria-label="Filter offers by category"><option value="">All categories</option>${categoryMap.deals.map(value => `<option>${escapeHtml(value)}</option>`).join("")}</select><button class="button button-small" id="offer-search-button" type="button">Search</button></div><div class="list-grid" id="offer-results">${loadingCards()}</div></div></section>`;

  const form = app.querySelector("#offer-form");
  const typeInput = form.querySelector("#offer-type");
  const couponInput = form.querySelector("#offer-coupon-code");
  const syncCouponRequirement = () => { couponInput.required = typeInput.value === "coupon"; };
  typeInput.addEventListener("change", syncCouponRequirement);
  syncCouponRequirement();

  const loadOffers = async () => {
    const root = app.querySelector("#offer-results");
    root.innerHTML = loadingCards();
    try {
      const filters = {
        search: app.querySelector("#offer-search").value.trim(),
        category: app.querySelector("#offer-category").value
      };
      const [deals, coupons] = await Promise.all([
        queryPublic("deals", filters),
        queryPublic("coupons", filters)
      ]);
      const rows = [
        ...deals.map(row => ({ ...row, _offer_table: "deals" })),
        ...coupons.map(row => ({ ...row, offer_type: "coupon", _offer_table: "coupons" }))
      ].sort((a, b) => new Date(b.created_at) - new Date(a.created_at)).slice(0, 60);
      root.innerHTML = rows.length ? rows.map(renderOfferCard).join("") : emptyState("No offers found", "Try another search, or be the first to share an offer.");
      attachAffiliateTracking(root);
    } catch (error) {
      console.error("Loading offers failed:", error);
      root.innerHTML = emptyState("Offers could not be loaded", error.message);
    }
  };
  app.querySelector("#offer-search-button").addEventListener("click", loadOffers);
  app.querySelector("#offer-search").addEventListener("keydown", event => {
    if (event.key === "Enter") { event.preventDefault(); loadOffers(); }
  });
  app.querySelector("#offer-category").addEventListener("change", loadOffers);
  form.addEventListener("submit", async event => {
    event.preventDefault();
    const button = form.querySelector('button[type="submit"]');
    const message = form.querySelector(".form-submit .form-message");
    button.disabled = true;
    message.textContent = "Publishing…";
    message.className = "form-message";
    try {
      const user = await getUser();
      if (!user) throw new Error("Please log in or create a free account before posting an offer.");
      const values = Object.fromEntries(new FormData(form));
      const merchant = values.merchant.trim();
      const affiliateUrl = validateOfferUrl(values.affiliate_url, merchant);
      const imageFile = form.querySelector("#offer-image").files[0] || null;
      const originalPrice = values.original_price ? Number(values.original_price) : null;
      const salePrice = values.sale_price ? Number(values.sale_price) : null;
      if (originalPrice !== null && salePrice !== null && salePrice > originalPrice) {
        throw new Error("Offer price cannot be higher than the original price.");
      }
      const discount = originalPrice > 0 && salePrice !== null
        ? Math.round(((originalPrice - salePrice) / originalPrice) * 10000) / 100
        : null;
      const supabase = await getSupabase();
      if (!supabase) throw new Error("Connect Supabase first to post an offer.");
      let uploadedImage;
      try {
        if (imageFile) uploadedImage = await uploadOwnedImage("deal-images", imageFile, ["offers"]);
        const { error } = await supabase.from("deals").insert({
          title: values.title.trim(),
          slug: `${slugify(values.title) || "offer"}-${crypto.randomUUID()}`,
          offer_type: values.offer_type,
          merchant,
          category: values.category,
          description: values.description.trim(),
          original_price: originalPrice,
          sale_price: salePrice,
          discount_percentage: discount,
          coupon_code: values.coupon_code.trim() || null,
          expires_at: values.expires_at || null,
          affiliate_url: affiliateUrl,
          image_url: uploadedImage?.url || null,
          user_id: user.id,
          status: "published"
        });
        if (error) throw error;
      } catch (error) {
        if (uploadedImage) {
          const { error: cleanupError } = await supabase.storage.from("deal-images").remove([uploadedImage.path]);
          if (cleanupError) throw new Error(`${error.message} Image cleanup also failed: ${cleanupError.message}`);
        }
        throw error;
      }
      form.reset();
      syncCouponRequirement();
      message.innerHTML = `Offer published. It is now visible on the <a href="index.html">homepage</a>.`;
      await loadOffers();
      showToast("Offer published successfully.");
    } catch (error) {
      console.error("Offer submission failed:", error);
      message.textContent = error.message || "Offer could not be published.";
      message.classList.add("form-error");
    } finally {
      button.disabled = false;
    }
  });
  await loadOffers();
}

function renderOfferCard(row) {
  const url = safeHttpUrl(row.affiliate_url);
  const imageUrl = row.image_url ? safeHttpUrl(row.image_url) : "#";
  const image = imageUrl !== "#" ? `<img class="offer-image" src="${escapeHtml(imageUrl)}" alt="" loading="lazy" referrerpolicy="no-referrer">` : "";
  const prices = row.sale_price !== null && row.sale_price !== undefined
    ? `<p><strong>₹${escapeHtml(row.sale_price)}</strong>${row.original_price !== null && row.original_price !== undefined ? ` <del>₹${escapeHtml(row.original_price)}</del>` : ""}${row.discount_percentage ? ` · ${escapeHtml(row.discount_percentage)}% off` : ""}</p>`
    : "";
  const coupon = row.coupon_code ? `<p>Coupon code: <strong>${escapeHtml(row.coupon_code)}</strong></p>` : "";
  const label = row.offer_type === "coupon" ? "Coupon" : "Product deal";
  return `<article class="data-card offer-card">${image}<span class="tag">${escapeHtml(label)} · ${escapeHtml(row.merchant || row.category || "")}</span><h2>${escapeHtml(row.title)}</h2><p>${escapeHtml(row.description || "Offer details may change; verify on the store before purchase.")}</p>${prices}${coupon}<span class="data-bottom"><span>${row.expires_at ? `Expires ${formatDate(row.expires_at)}` : formatDate(row.created_at)}</span>${url !== "#" ? `<a class="button button-small" data-affiliate-id="${escapeHtml(row.id)}" data-affiliate-table="${escapeHtml(row._offer_table || "deals")}" href="${escapeHtml(url)}" target="_blank" rel="sponsored nofollow noopener noreferrer">Shop on ${escapeHtml(row.merchant || "store")} ↗</a>` : `<span>Offer link unavailable</span>`}</span></article>`;
}

function attachAffiliateTracking(root) {
  root.querySelectorAll("[data-affiliate-id]").forEach(link => link.addEventListener("click", async () => {
    try {
      const supabase = await getSupabase();
      if (!supabase) return;
      const click = link.dataset.affiliateTable === "coupons"
        ? { coupon_id: link.dataset.affiliateId }
        : { deal_id: link.dataset.affiliateId };
      const { error } = await supabase.from("affiliate_clicks").insert(click);
      if (error) throw error;
    } catch (error) { console.error("Affiliate click tracking failed:", error); }
  }));
}

async function renderListing(app, key) {
  const config = listings[key];
  setPageTitle(config.title, config.subtitle);
  const params = new URLSearchParams(location.search);
  const cats = categoryMap[config.table] || [];
  app.innerHTML = `<section class="page-hero"><div class="container"><div class="breadcrumb"><a href="index.html">Home</a> / ${config.crumb}</div><span class="eyebrow">DigitalDuniya360</span><h1>${config.title}</h1><p>${config.subtitle}</p>${config.disclosure ? `<div class="disclosure">Affiliate disclosure: some links may be affiliate links. We only display offers published by our administrators; please verify availability and terms with the merchant.</div>` : ""}</div></section>
  <section class="section"><div class="container"><div class="list-controls"><input id="listing-search" value="${escapeHtml(params.get("q") || "")}" placeholder="Search ${config.item}..." aria-label="Search ${config.item}">${cats.length ? `<select id="listing-category" aria-label="Filter by category"><option value="">All categories</option>${cats.map(c=>`<option ${params.get("category")===c?"selected":""}>${c}</option>`).join("")}</select>` : ""}${["classifieds","jobs","business"].includes(key) ? `<input id="listing-city" placeholder="City" value="${escapeHtml(params.get("city")||"")}" aria-label="Filter by city">` : ""}${key==="jobs" ? `<select id="listing-work-type" aria-label="Filter by work type"><option value="">All work types</option>${["Full-time","Part-time","Internship","Work from home"].map(t=>`<option>${t}</option>`).join("")}</select><input id="listing-salary" placeholder="Salary contains..." aria-label="Filter by salary">` : ""}${key==="classifieds" ? `<input id="listing-min-price" type="number" min="0" placeholder="Min ₹" aria-label="Minimum price"><input id="listing-max-price" type="number" min="0" placeholder="Max ₹" aria-label="Maximum price"><select id="listing-sort" aria-label="Sort listings"><option value="">Newest first</option><option value="price_asc">Price: low to high</option><option value="price_desc">Price: high to low</option></select>` : ""}<button class="button button-small" id="apply-filters">Search</button>${config.action ? `<a class="button button-outline button-small" href="${config.actionHref}">${config.action}</a>` : ""}</div><div class="list-grid" id="listing-results">${loadingCards()}</div></div></section>`;
  const load = async () => {
    const root = document.querySelector("#listing-results");
    root.innerHTML = loadingCards();
    try {
      const rows = await queryPublic(config.table, {
        search: document.querySelector("#listing-search").value.trim(),
        category: document.querySelector("#listing-category")?.value || "",
        city: document.querySelector("#listing-city")?.value.trim() || "",
        workType: document.querySelector("#listing-work-type")?.value || "",
        salary: document.querySelector("#listing-salary")?.value.trim() || "",
        minPrice: document.querySelector("#listing-min-price")?.value || "",
        maxPrice: document.querySelector("#listing-max-price")?.value || "",
        sort: document.querySelector("#listing-sort")?.value || ""
      });
      root.innerHTML = rows.length ? rows.map(row => listingCard(row, key)).join("") : emptyState("No published " + config.item + " yet", "Try changing your search or check back later.", config.action ? `<a class="button button-outline" href="${config.actionHref}">${config.action}</a>` : "");
      attachAffiliateTracking(root);
    } catch (error) { console.error(error); root.innerHTML = emptyState("We couldn't load this section", error.message); }
  };
  document.querySelector("#apply-filters").addEventListener("click", load);
  document.querySelector("#listing-search").addEventListener("keydown", e => { if(e.key==="Enter"){e.preventDefault();load();} });
  load();
}

function listingCard(row, key) {
  const title = row.title || row.name || row.company_name || "Untitled";
  const desc = row.summary || row.description || "Open to see more information.";
  if (key === "deals" || key === "coupons") {
    const url = row.affiliate_url ? safeHttpUrl(row.affiliate_url) : "#";
    const price = row.sale_price !== null && row.sale_price !== undefined ? `<p><strong>₹${escapeHtml(row.sale_price)}</strong>${row.original_price !== null && row.original_price !== undefined ? ` <del>₹${escapeHtml(row.original_price)}</del>` : ""}${row.discount_percentage !== null && row.discount_percentage !== undefined ? ` · ${escapeHtml(row.discount_percentage)}% off` : ""}</p>` : "";
    const code = row.coupon_code ? `<p>Code: <strong>${escapeHtml(row.coupon_code)}</strong></p>` : "";
    const imageUrl = row.image_url ? safeHttpUrl(row.image_url) : "#";
    const image = imageUrl !== "#" ? `<img class="offer-image" src="${escapeHtml(imageUrl)}" alt="" loading="lazy" referrerpolicy="no-referrer">` : "";
    return `<article class="data-card offer-card">${image}<span class="tag">${escapeHtml(row.offer_type === "coupon" ? "Coupon" : row.merchant || row.category || key)}</span><h2>${escapeHtml(title)}</h2><p>${escapeHtml(desc)}</p>${price}${code}<span class="data-bottom"><span>${row.expires_at ? `Expires ${formatDate(row.expires_at)}` : "Check merchant for availability"}</span>${url !== "#" ? `<a class="button button-small" data-affiliate-id="${escapeHtml(row.id)}" data-affiliate-table="${key}" href="${escapeHtml(url)}" target="_blank" rel="sponsored nofollow noopener noreferrer">View offer ↗</a>` : `<span>Offer link unavailable</span>`}</span></article>`;
  }
  const href = { blog:"blog-details.html",news:"news-details.html",classifieds:"ad-details.html",business:"business-details.html",jobs:"job-details.html" }[key] || `${key}.html`;
  const detailHref = `${href}?slug=${encodeURIComponent(row.slug || row.id)}`;
  const price = row.price !== null && row.price !== undefined ? `<strong>₹${escapeHtml(row.price)}</strong> · ` : "";
  const area = [row.city, row.state].filter(Boolean).join(", ");
  return `<a class="data-card" href="${detailHref}"><span class="tag">${escapeHtml(row.category || key)}</span><h2>${escapeHtml(title)}</h2><p>${escapeHtml(desc)}</p><span class="data-bottom"><span>${price}${escapeHtml(area || formatDate(row.created_at))}</span><span>View details ↗</span></span></a>`;
}

async function renderForm(app, spec) {
  setPageTitle(spec.title, spec.intro);
  const fields = spec.fields.map(([name,label,type,required]) => {
    const choices = categoryMap[spec.table] || (name==="work_type" ? ["Full-time","Part-time","Internship","Work from home"] : []);
    let control = "";
    if (type === "select") control = `<select id="field-${name}" name="${name}" ${required?"required":""}><option value="">Choose one</option>${choices.map(x=>`<option>${escapeHtml(x)}</option>`).join("")}</select>`;
    else if (type === "textarea") control = `<textarea id="field-${name}" name="${name}" ${required?"required":""} ${name==="content"?"minlength=\"80\"":""}></textarea>`;
    else if (type === "file") control = `<input id="field-${name}" type="file" name="${name}" accept="image/jpeg,image/png,image/webp" ${name==="featured_image"?"":"multiple"}><small>JPG, PNG or WebP. Up to ${name==="featured_image"?"1 image":"5 images"}, 5 MB each.</small>`;
    else control = `<input id="field-${name}" type="${type}" name="${name}" ${required?"required":""} ${name==="website_url"?'inputmode="url" autocomplete="url" placeholder="https://example.com" aria-describedby="website-url-hint"':""} ${type==="number"?'min="0" step="0.01"':""}>${name==="website_url"?'<small id="website-url-hint">Enter a domain such as example.com or a full HTTPS URL; we will add https:// when needed.</small>':""}`;
    return `<div class="field ${type==="textarea"||type==="file"?"full":""}"><label for="field-${name}">${escapeHtml(label)}${required?" *":""}</label>${control}</div>`;
  }).join("");
  const isClassifiedAd = spec.table === "classified_ads";
  app.innerHTML = `<section class="page-hero"><div class="container"><div class="breadcrumb"><a href="index.html">Home</a> / Create</div><span class="eyebrow">Share with the community</span><h1>${spec.title}</h1><p>${spec.intro}</p></div></section><section class="section"><div class="container form-layout"><form class="form-card" id="submission-form"><h2>Submission details</h2><div class="form-grid">${fields}</div><div class="form-submit"><button class="button" type="submit">${isClassifiedAd?"Publish ad":"Submit for review"} ↗</button><span class="form-message" aria-live="polite"></span></div></form><aside class="side-note"><h3>Before you submit</h3><p>${isClassifiedAd?"Ads publish immediately. No account is required.":"New submissions are stored as pending and become public only after administrator review."}</p><ul><li>Use accurate, helpful information.</li><li>Do not share confidential or misleading content.</li><li>Make sure you own or may share any images.</li></ul></aside></div></section>`;
  document.querySelector("#submission-form").addEventListener("submit", async event => {
    event.preventDefault();
    const form = event.currentTarget;
    const message = form.querySelector(".form-message");
    const button = form.querySelector("button[type=submit]");
    button.disabled = true; message.textContent = "Submitting…"; message.className = "form-message";
    let publishedAd;
    try {
      const values = Object.fromEntries(new FormData(form).entries());
      const fileInput = form.querySelector('input[type="file"]');
      const files = fileInput?.files;
      if (files?.length > 5) throw new Error("Please select no more than 5 images.");
      if (files) for (const file of files) validateImage(file);
      for (const input of form.querySelectorAll('input[type="file"]')) delete values[input.name];
      for (const [key, val] of Object.entries(values)) if (typeof val === "string") values[key] = val.trim();
      if (spec.table === "blog_posts") {
        values.slug = `${slugify(values.title) || "article"}-${crypto.randomUUID().slice(0, 8)}`;
        values.website_url = normalizeWebsiteUrl(values.website_url);
      }
      if (isClassifiedAd) {
        values.slug = `${slugify(values.title) || "ad"}-${crypto.randomUUID()}`;
        values.website_url = values.website_url ? normalizeWebsiteUrl(values.website_url) : null;
        if (values.price === "") values.price = null;
      }
      if (spec.table === "jobs") {
        values.skills = values.skills ? values.skills.split(",").map(s=>s.trim()).filter(Boolean) : [];
        if (!values.deadline) values.deadline = null;
      }
      if (spec.table === "blog_posts") values.tags = values.tags ? values.tags.split(",").map(s=>s.trim()).filter(Boolean) : [];
      let inserted;
      if (isClassifiedAd) {
        const supabase = await getSupabase();
        if (!supabase) throw new Error("Connect Supabase first to submit content.");
        const user = await getUser();
        const { data, error } = await supabase.from("classified_ads")
          .insert({ ...values, user_id: user?.id || null, status: "published" }).select().single();
        if (error) throw error;
        inserted = data;
        publishedAd = data;
      } else {
        inserted = await submitOwned(spec.table, values);
      }
      if (files?.length) {
        const supabase = await getSupabase();
        const bucket = spec.table === "classified_ads" ? "classified-images" : spec.table === "businesses" ? "business-images" : "blog-images";
        const uploads = [];
        for (const file of files) {
          uploads.push(isClassifiedAd
            ? await uploadAdImage(file, inserted.id)
            : await uploadOwnedImage(bucket,file,[inserted.id]));
        }
        if (spec.table === "blog_posts") {
          const { error } = await supabase.from("blog_posts").update({ featured_image: uploads[0].url }).eq("id",inserted.id);
          if (error) throw error;
        } else {
          const table = spec.table === "classified_ads" ? "ad_images" : "business_images";
          for (const upload of uploads) {
            const row = spec.table === "classified_ads" ? { ad_id: inserted.id, image_url: upload.url, user_id: inserted.user_id } : { business_id: inserted.id, image_url: upload.url, user_id: inserted.user_id };
          const { error } = await supabase.from(table).insert(row);
          if (error) throw error;
          }
        }
      }
      form.reset();
      message.textContent = isClassifiedAd ? "Ad published successfully." : "Submitted successfully. It will appear after admin approval.";
      showToast(message.textContent);
    } catch (error) {
      console.error(error);
      if (publishedAd) {
        form.reset();
        message.textContent = `Your ad is published, but its photos could not be fully saved: ${error.message}`;
        message.classList.add("form-error");
        showToast("Your ad is published, but photo upload failed.", "error");
      } else {
        message.textContent = error.message || "Submission failed.";
        message.classList.add("form-error");
      }
    }
    finally { button.disabled = false; }
  });
}

function validateImage(file) {
  if (!["image/jpeg","image/png","image/webp"].includes(file.type)) throw new Error("Only JPG, PNG or WebP images are accepted.");
  if (file.size > 5 * 1024 * 1024) throw new Error("Each image must be smaller than 5 MB.");
}
function slugify(text) { return text.toLowerCase().trim().replace(/[^a-z0-9]+/g,"-").replace(/^-|-$/g,""); }
function normalizeWebsiteUrl(value) {
  const url = new URL(/^https?:\/\//i.test(value) ? value : `https://${value}`);
  if (!["http:","https:"].includes(url.protocol) || !url.hostname.includes(".")) {
    throw new Error("Enter a valid website address, such as example.com or https://example.com.");
  }
  return url.href;
}

async function renderDetail(app, config, key) {
  setPageTitle("Details", "Explore a community listing on DigitalDuniya360.");
  const slug = new URLSearchParams(location.search).get("slug");
  const supabase = await getSupabase();
  app.innerHTML = `<section class="section"><div class="container detail-content" id="detail-root">${loadingCards()}</div></section>`;
  if (!supabase || !slug) {
    app.querySelector("#detail-root").innerHTML = emptyState("This item isn't available", slug ? "Connect Supabase to view published content." : "A listing link is required to show details.", `<a class="button button-outline" href="index.html">Back to home</a>`);
    return;
  }
  try {
    const { data, error } = await supabase.from(config.table).select("*").eq("status","published").eq("slug",slug).maybeSingle();
    if (error) throw error;
    const record = data || await selectById(supabase, config.table, slug);
    if (!record) { app.querySelector("#detail-root").innerHTML = emptyState("Listing not found","It may have expired or is not published yet."); return; }
    document.title = `${record.title || record.name || "Details"} | DigitalDuniya360`;
    const heroImage = record.featured_image || record.image_url || record.cover_image;
    const relatedImages = key === "ad-details" ? "ad_images" : key === "business-details" ? "business_images" : "";
    const browseUrl = {blog_posts:"blog.html",news_articles:"news.html",classified_ads:"classifieds.html",businesses:"business.html",jobs:"jobs.html"}[config.table] || "index.html";
    const facts = [];
    if (key === "ad-details" && record.seller_name) facts.push(["Seller",record.seller_name]);
    if (key === "business-details" && record.address) facts.push(["Address",record.address]);
    if (key === "business-details" && record.services?.length) facts.push(["Services",record.services.join(", ")]);
    if (key === "job-details") {
      if (record.company_name) facts.push(["Company",record.company_name]);
      if (record.work_type) facts.push(["Work type",record.work_type]);
      if (record.salary) facts.push(["Salary",record.salary]);
      if (record.experience) facts.push(["Experience",record.experience]);
      if (record.deadline) facts.push(["Deadline",formatDate(record.deadline)]);
      if (record.skills?.length) facts.push(["Skills",record.skills.join(", ")]);
    }
    if (key === "news-details" && record.source_name) facts.push(["Source",record.source_name]);
    app.querySelector("#detail-root").innerHTML = `<div class="breadcrumb"><a href="index.html">Home</a> / <a href="${browseUrl}">Browse</a></div><span class="tag">${escapeHtml(record.category || config.name)}</span><h1>${escapeHtml(record.title || record.name || record.company_name || "")}</h1><p class="detail-meta">${formatDate(record.created_at)}${record.city?` · ${escapeHtml(record.city)}`:""}${record.author_name?` · By ${escapeHtml(record.author_name)}`:""}</p>${heroImage?`<img class="detail-image" src="${escapeHtml(safeHttpUrl(heroImage))}" alt="${escapeHtml(record.title || record.name || "Listing image")}" loading="lazy">`:""}${record.price!==undefined&&record.price!==null?`<h2>₹${escapeHtml(record.price)}</h2>`:""}${facts.length?`<dl class="detail-facts">${facts.map(([label,value])=>`<div><dt>${escapeHtml(label)}</dt><dd>${escapeHtml(value)}</dd></div>`).join("")}</dl>`:""}<div class="detail-body">${escapeHtml(record.content || record.description || record.summary || "More information has not been provided.")}</div>${record.website?`<p><a class="button" href="${escapeHtml(safeHttpUrl(record.website))}" target="_blank" rel="noopener noreferrer nofollow">Visit website ↗</a></p>`:""}${record.website_url?`<p><a class="button button-outline" href="${escapeHtml(safeHttpUrl(record.website_url))}" target="_blank" rel="noopener noreferrer nofollow">${key==="ad-details"?"Visit Website":"Visit related website"} ↗</a></p>`:""}${record.source_url?`<p><a class="text-link" href="${escapeHtml(safeHttpUrl(record.source_url))}" target="_blank" rel="noopener noreferrer nofollow">Read source ↗</a></p>`:""}${record.apply_url?`<p><a class="button" href="${escapeHtml(safeActionUrl(record.apply_url))}" target="_blank" rel="noopener noreferrer">Apply now ↗</a></p>`:""}${record.phone?`<p><a class="button button-outline" href="tel:${encodeURIComponent(String(record.phone).replace(/[^\d+]/g,""))}">Call now</a></p>`:""}${record.whatsapp?`<p><a class="button button-outline" href="https://wa.me/${encodeURIComponent(String(record.whatsapp).replace(/\D/g,""))}" target="_blank" rel="noopener noreferrer">Contact on WhatsApp</a></p>`:""}${relatedImages?`<div class="gallery-grid" id="detail-gallery"></div>`:""}${key==="blog-details"?`<section class="discussion"><h2>Comments</h2><div id="discussion-items">${loadingCards()}</div><form id="discussion-form" class="form-card"><div class="field"><label for="discussion-body">Add a comment</label><textarea id="discussion-body" name="body" minlength="2" maxlength="5000" required placeholder="Keep it constructive and relevant."></textarea></div><button class="button button-small" type="submit">Submit comment</button><span class="form-message" aria-live="polite"></span></form></section>`:""}${key==="business-details"?`<section class="discussion"><h2>Reviews</h2><div id="review-items">${loadingCards()}</div><form id="review-form" class="form-card"><div class="field"><label for="review-rating">Your rating</label><select id="review-rating" name="rating" required><option value="">Choose a rating</option><option value="5">5 — Excellent</option><option value="4">4 — Very good</option><option value="3">3 — Good</option><option value="2">2 — Fair</option><option value="1">1 — Poor</option></select></div><div class="field"><label for="review-body">Your review</label><textarea id="review-body" name="body" minlength="5" maxlength="3000" required placeholder="Share a helpful, honest review."></textarea></div><button class="button button-small" type="submit">Submit review</button><span class="form-message" aria-live="polite"></span></form></section>`:""}${["ad-details","business-details","job-details","blog-details"].includes(key)?`<button class="button-quiet" id="report-content">Report this content</button>`:""}`;
    if (relatedImages) loadGallery(supabase, relatedImages, key === "ad-details" ? "ad_id" : "business_id", record.id);
    if (key === "blog-details") setupDiscussion(supabase, record.id);
    if (key === "business-details") setupBusinessReviews(supabase, record.id);
    if (app.querySelector("#report-content")) app.querySelector("#report-content").addEventListener("click", () => submitReport(supabase, key, record.id));
  } catch (error) { console.error(error); app.querySelector("#detail-root").innerHTML = emptyState("Unable to load this listing",error.message); }
}

async function selectById(supabase, table, id) {
  if (!/^[0-9a-f-]{36}$/i.test(id)) return null;
  const { data, error } = await supabase.from(table).select("*").eq("status","published").eq("id",id).maybeSingle();
  if (error) throw error; return data;
}
function safeHttpUrl(raw) {
  try { const url = new URL(raw, location.origin); return ["http:","https:"].includes(url.protocol) ? url.href : "#"; } catch { return "#"; }
}
function validateHttpsUrl(raw, label) {
  let url;
  try { url = new URL(raw); } catch { throw new Error(`Enter a valid ${label.toLowerCase()}.`); }
  if (url.protocol !== "https:" || !url.hostname.includes(".")) {
    throw new Error(`${label} must be a valid HTTPS address.`);
  }
  return url.href;
}
function validateOfferUrl(raw, merchant) {
  const url = new URL(validateHttpsUrl(raw, "Store link"));
  if (merchant === "Website") return url.href;
  const hosts = {
    Amazon: ["amazon.in", "amazon.com", "amzn.to"],
    Flipkart: ["flipkart.com", "fkrt.it"],
    Meesho: ["meesho.com"]
  };
  const domains = hosts[merchant];
  if (!domains || !domains.some(domain => url.hostname === domain || url.hostname.endsWith(`.${domain}`))) {
    throw new Error(`The link does not match the selected ${merchant} store.`);
  }
  return url.href;
}
function safeActionUrl(raw) {
  try { const url = new URL(raw, location.origin); return ["http:","https:","mailto:","tel:"].includes(url.protocol) ? url.href : "#"; } catch { return "#"; }
}

async function loadGallery(supabase, table, foreignKey, id) {
  try {
    const { data, error } = await supabase.from(table).select("image_url").eq(foreignKey,id).order(table==="ad_images"?"position":"created_at",{ascending:true});
    if (error) throw error;
    const gallery = document.querySelector("#detail-gallery");
    if (!gallery || !data?.length) return;
    gallery.innerHTML = data.map((item,index)=>`<img src="${escapeHtml(safeHttpUrl(item.image_url))}" alt="Listing photo ${index+1}" loading="lazy">`).join("");
  } catch(error) { console.error("Could not load listing images:",error); }
}

async function setupDiscussion(supabase, id) {
  const table = "blog_comments";
  const foreignKey = "post_id";
  const root = document.querySelector("#discussion-items");
  try {
    const { data, error } = await supabase.from(table).select("body,created_at").eq(foreignKey,id).eq("status","approved").order("created_at",{ascending:true});
    if (error) throw error;
    root.innerHTML = data?.length ? data.map(item=>`<article class="discussion-item"><p>${escapeHtml(item.body)}</p><small>${formatDate(item.created_at)}</small></article>`).join("") : emptyState("No comments yet","Be the first to contribute to this discussion.");
  } catch(error) { console.error(error); root.innerHTML=emptyState("Discussion could not be loaded",error.message); }
  document.querySelector("#discussion-form").addEventListener("submit",async event=>{
    event.preventDefault();
    const form=event.currentTarget, message=form.querySelector(".form-message"), button=form.querySelector("button");
    button.disabled=true;message.textContent="Submitting…";message.className="form-message";
    try {
      const user = await getUser();
      if (!user) throw new Error("Please log in before contributing.");
      const {error}=await supabase.from(table).insert({[foreignKey]:id,user_id:user.id,body:new FormData(form).get("body").trim(),status:"pending"});
      if(error)throw error;
      form.reset();message.textContent="Submitted for moderation.";
    } catch(error){message.textContent=error.message;message.classList.add("form-error");}
    finally{button.disabled=false;}
  });
}

async function setupBusinessReviews(supabase, businessId) {
  const root = document.querySelector("#review-items");
  const form = document.querySelector("#review-form");
  try {
    const { data, error } = await supabase.from("business_reviews").select("rating,body,created_at")
      .eq("business_id", businessId).eq("status", "approved").order("created_at", { ascending: false });
    if (error) throw error;
    root.innerHTML = data?.length
      ? data.map(review => `<article class="discussion-item"><p>${escapeHtml(review.body)}</p><small>${"★".repeat(review.rating)} · ${formatDate(review.created_at)}</small></article>`).join("")
      : emptyState("No reviews yet", "Be the first to share a helpful review.");
  } catch (error) {
    console.error(error);
    root.innerHTML = emptyState("Reviews could not be loaded", error.message);
  }
  form.addEventListener("submit", async event => {
    event.preventDefault();
    const message = form.querySelector(".form-message");
    const button = form.querySelector("button");
    button.disabled = true;
    message.textContent = "Submitting…";
    message.className = "form-message";
    try {
      const user = await getUser();
      if (!user) throw new Error("Please log in before submitting a review.");
      const values = Object.fromEntries(new FormData(form));
      const { error } = await supabase.from("business_reviews").insert({
        business_id: businessId,
        user_id: user.id,
        rating: Number(values.rating),
        body: values.body.trim(),
        status: "pending"
      });
      if (error) throw error;
      form.reset();
      message.textContent = "Review submitted. It will appear after moderation.";
    } catch (error) {
      message.textContent = error.message;
      message.classList.add("form-error");
    } finally {
      button.disabled = false;
    }
  });
}

async function submitReport(supabase, targetType, targetId) {
  const reason=window.prompt("Briefly describe why this content should be reviewed:");
  if(!reason?.trim())return;
  try{
    const user=await getUser();
    if(!user)throw new Error("Please log in to report content.");
    const {error}=await supabase.from("reports").insert({user_id:user.id,target_type:targetType,target_id:targetId,reason:reason.trim()});
    if(error)throw error;
    showToast("Thank you. Your report has been sent for review.");
  }catch(error){showToast(error.message,"error");}
}

async function renderAuth(app, mode) {
  setPageTitle(mode==="login"?"Log in":"Create your account", "Secure account access for the DigitalDuniya360 community.");
  const isLogin = mode === "login";
  const recovering = isLogin && (new URLSearchParams(location.search).get("type") === "recovery" || new URLSearchParams(location.hash.slice(1)).get("type") === "recovery");
  app.innerHTML = `<section class="auth-wrap"><form class="auth-card" id="auth-form"><span class="eyebrow">${recovering?"Password recovery":isLogin?"Welcome back":"Join the community"}</span><h1>${recovering?"Choose a new password":isLogin?"Good to see you.":"Your next step starts here."}</h1><p>${recovering?"Set a new password for your account.":isLogin?"Log in to manage your listings and take part in the community.":"Create an account to post and share your knowledge."}</p>${!isLogin?`<div class="field"><label for="auth-name">Full name</label><input id="auth-name" name="full_name" required autocomplete="name"></div>`:""}${!recovering?`<div class="field"><label for="auth-email">Email address</label><input id="auth-email" name="email" type="email" required autocomplete="email"></div>`:""}<div class="field"><label for="auth-password">${recovering?"New password":"Password"}</label><input id="auth-password" name="password" type="password" required minlength="8" autocomplete="${isLogin?"current-password":"new-password"}"></div><button class="button" type="submit">${recovering?"Update password":isLogin?"Log in":"Create account"} ↗</button>${isLogin&&!recovering?`<button class="button-quiet" id="reset-password" type="button">Forgot password?</button>`:""}<div class="auth-switch">${isLogin?`New here? <a href="register.html">Create an account</a>`:`Already a member? <a href="login.html">Log in</a>`}</div><div class="form-message" aria-live="polite"></div></form></section>`;
  app.querySelector("#auth-form").addEventListener("submit", async e => {
    e.preventDefault(); const form=e.currentTarget, message=form.querySelector(".form-message"), button=form.querySelector(".button");
    if (!isSupabaseConfigured) { message.textContent="Supabase is not configured. Add your project URL and publishable key in assets/js/config.js."; message.className="form-message form-error"; return; }
    button.disabled=true; message.textContent="Please wait…";
    try {
      const result = await submitAuthForm(form, mode, recovering);
      message.textContent = result.message;
      if (result.redirect) setTimeout(() => location.href = result.redirect, 700);
    } catch(error) { message.textContent=error.message; message.className="form-message form-error"; }
    finally { button.disabled=false; }
  });
  app.querySelector("#reset-password")?.addEventListener("click",async()=>{
    const email=app.querySelector('[name="email"]').value;
    try{await requestPasswordReset(email);showToast("If the account exists, password reset instructions have been sent.");}catch(error){showToast(error.message,"error");}
  });
}

async function renderDashboard(app) {
  setPageTitle("Your dashboard", "Manage your submissions and community account.");
  const user = await getUser();
  if (!user) {
    app.innerHTML = `<section class="section"><div class="container">${emptyState("Sign in to view your dashboard","Your account dashboard is private.",`<a class="button" href="login.html">Log in</a>`)}</div></section>`;
    return;
  }
  const all = await loadOwnSubmissions(user.id);
  const profile = await getProfile(user.id);
  app.innerHTML = `<section class="page-hero"><div class="container"><span class="eyebrow">Your account</span><h1>Your dashboard</h1><p>${escapeHtml(user.email||"Manage your community activity.")}</p></div></section>
    <section class="container dashboard-layout"><nav class="dashboard-nav" aria-label="Dashboard">${[["Overview","#"],["My profile","#profile-settings"],["Submit a blog","submit-blog.html"],["Post an ad","post-ad.html"],["Add business","add-business.html"],["Post a job","post-job.html"]].map(([label,href],i)=>`<a class="${i===0?"active":""}" href="${href}">${label}</a>`).join("")}<button id="logout-button" type="button">Log out</button></nav>
      <div class="dashboard-content"><h1>Welcome back${profile?.full_name ? `, ${escapeHtml(profile.full_name)}` : ""}</h1><p>Manage your profile and track your submissions. Each submission is protected by your account and the database policies.</p>
        <div class="stat-grid">${[["Submissions",all.length],["Pending",all.filter(item=>item.status==="pending").length],["Published",all.filter(item=>item.status==="published").length],["Account","Active"]].map(([label,value])=>`<div class="stat-card"><span>${label}</span><strong>${value}</strong></div>`).join("")}</div>
        <section class="dashboard-panel" id="profile-settings"><h2>My profile</h2><form id="profile-form" class="form-grid">
          <div class="field"><label for="profile-name">Full name</label><input id="profile-name" name="full_name" value="${escapeHtml(profile?.full_name||"")}" required maxlength="120"></div>
          <div class="field"><label for="profile-city">City</label><input id="profile-city" name="city" value="${escapeHtml(profile?.city||"")}" maxlength="100"></div>
          <div class="field"><label for="profile-state">State</label><input id="profile-state" name="state" value="${escapeHtml(profile?.state||"")}" maxlength="100"></div>
          <div class="field"><label for="profile-avatar">Avatar</label><input id="profile-avatar" name="avatar" type="file" accept="image/jpeg,image/png,image/webp"><small>JPG, PNG or WebP, max 5 MB.</small></div>
          <div class="field full"><label for="profile-bio">About me</label><textarea id="profile-bio" name="bio" maxlength="1000">${escapeHtml(profile?.bio||"")}</textarea></div>
          <div class="field full"><div class="form-submit"><button class="button button-small" type="submit">Save profile</button><span class="form-message" aria-live="polite"></span></div></div>
        </form></section>
        <section class="dashboard-panel"><h2>Your submissions</h2><p>Manage your submissions here. Classified ads can be unpublished or deleted by an administrator.</p><div class="table-wrap">${all.length?`<table class="data-table"><thead><tr><th>Title</th><th>Type</th><th>Status</th><th>Submitted</th><th>Actions</th></tr></thead><tbody>${all.map(row=>`<tr><td>${escapeHtml(row.title||row.name||row.body||"Untitled")}</td><td>${escapeHtml(row._name)}</td><td><span class="pill">${escapeHtml(row.status)}</span></td><td>${formatDate(row.created_at)}</td><td>${row._table==="classified_ads"?"":`<button class="button button-outline button-small" data-delete="${escapeHtml(row.id)}" data-table="${escapeHtml(row._table)}">Delete</button>`}</td></tr>`).join("")}</tbody></table>`:emptyState("Nothing submitted yet","Your blogs, ads, businesses, jobs and comments will appear here.")}</div></section>
        <section class="dashboard-panel"><h2>Account security</h2><form id="password-form" class="form-grid"><div class="field"><label for="new-password">New password</label><input id="new-password" name="password" type="password" autocomplete="new-password" minlength="8" required></div><div class="field"><label for="confirm-password">Confirm new password</label><input id="confirm-password" name="confirm_password" type="password" autocomplete="new-password" minlength="8" required></div><div class="field full"><div class="form-submit"><button class="button button-outline button-small" type="submit">Change password</button><span class="form-message" aria-live="polite"></span></div></div></form></section>
      </div>
    </section>`;
  app.querySelector("#logout-button").addEventListener("click", async () => {
    try { await signOut(); location.href="index.html"; }
    catch (error) { showToast(error.message,"error"); }
  });
  app.querySelector("#profile-form").addEventListener("submit", async event => {
    event.preventDefault();
    const form=event.currentTarget, message=form.querySelector(".form-message"), button=form.querySelector("button");
    button.disabled=true;message.textContent="Saving…";
    try {
      const values=Object.fromEntries(new FormData(form));
      const avatar=form.querySelector('[name="avatar"]').files[0];
      delete values.avatar;
      await saveProfile(user.id,{full_name:values.full_name.trim(),city:values.city.trim(),state:values.state.trim(),bio:values.bio.trim()},avatar);
      message.textContent="Profile saved.";
    } catch(error) { message.textContent=error.message;message.classList.add("form-error"); }
    finally { button.disabled=false; }
  });
  app.querySelector("#password-form").addEventListener("submit", async event => {
    event.preventDefault();
    const form=event.currentTarget,values=Object.fromEntries(new FormData(form)),message=form.querySelector(".form-message"),button=form.querySelector("button");
    if(values.password!==values.confirm_password){message.textContent="Passwords do not match.";message.classList.add("form-error");return;}
    button.disabled=true;
    try {await changeOwnPassword(values.password);form.reset();message.textContent="Password updated.";}
    catch(error){message.textContent=error.message;message.classList.add("form-error");}
    finally{button.disabled=false;}
  });
  app.querySelectorAll("[data-delete]").forEach(button=>button.addEventListener("click",async()=>{
    if(!window.confirm("Delete this submission permanently?"))return;
    button.disabled=true;
    try{await removeOwnSubmission(user.id,button.dataset.table,button.dataset.delete);button.closest("tr").remove();showToast("Submission deleted.");}
    catch(error){showToast(error.message,"error");button.disabled=false;}
  }));
}

async function renderAdmin(app) {
  setPageTitle("Admin panel", "Moderation and content management.");
  const supabase=await getSupabase();
  if(!supabase){app.innerHTML=`<section class="section"><div class="container">${emptyState("Connect Supabase to continue","Admin permissions are verified by the database. Configure the client before using the admin panel.")}</div></section>`;return;}
  try{
    const {allowed,isAdmin,user:currentUser}=await checkModeratorAccess();
    if(!allowed){app.innerHTML=`<section class="section"><div class="container">${emptyState("Admin access required","This account does not have the database-verified admin role.",`<a class="button button-outline" href="index.html">Back to home</a>`)}</div></section>`;return;}
    const queues=[
      {label:"Blogs",table:"blog_posts",field:"status",pending:"pending",approve:"published",reject:"rejected"},
      {label:"News",table:"news_articles",field:"status",pending:"pending",approve:"published",reject:"rejected"},
      {label:"Businesses",table:"businesses",field:"status",pending:"pending",approve:"published",reject:"rejected"},
      {label:"Jobs",table:"jobs",field:"status",pending:"pending",approve:"published",reject:"rejected"},
      {label:"Deals",table:"deals",field:"status",pending:"pending",approve:"published",reject:"rejected"},
      {label:"Coupons",table:"coupons",field:"status",pending:"pending",approve:"published",reject:"rejected"},
      {label:"Blog comments",table:"blog_comments",field:"status",pending:"pending",approve:"approved",reject:"rejected"},
      {label:"Business reviews",table:"business_reviews",field:"status",pending:"pending",approve:"approved",reject:"rejected"},
      {label:"Reports",table:"reports",field:"status",pending:"open",approve:"resolved",reject:"dismissed"}
    ];
    const records=await Promise.all(queues.map(async queue=>{const {data,error}=await supabase.from(queue.table).select("*").eq(queue.field,queue.pending).order("created_at",{ascending:true}).limit(100);if(error)throw error;return {...queue,rows:data||[]};}));
    const {data:publishedOffers,error:offersError}=await supabase.from("deals")
      .select("id,title,merchant,offer_type,affiliate_url,created_at")
      .eq("status","published").order("created_at",{ascending:false}).limit(100);
    if(offersError)throw offersError;
    const publishedAds=[];
    if(isAdmin)for(let offset=0;;offset+=1000){
      const {data,error}=await supabase.from("classified_ads").select("id,title,slug,city,state,seller_name,phone,created_at")
        .eq("status","published").order("created_at",{ascending:false}).range(offset,offset+999);
      if(error)throw error;
      publishedAds.push(...(data||[]));
      if(!data||data.length<1000)break;
    }
    const roleQuery=isAdmin?await supabase.from("user_roles").select("id,user_id,role,created_at").order("created_at",{ascending:false}).limit(100):{data:[],error:null};
    if(roleQuery.error)throw roleQuery.error;
    const roleManagement=isAdmin?`<div class="dashboard-panel"><h2>Role management</h2><p>Grant roles only to accounts you trust. Get the user's UUID from Supabase Authentication; registration never grants admin access.</p><form id="role-form" class="form-grid"><div class="field"><label for="role-user">User UUID</label><input id="role-user" name="user_id" required pattern="[0-9a-fA-F-]{36}"></div><div class="field"><label for="role-name">Role</label><select id="role-name" name="role" required><option value="moderator">Moderator</option><option value="admin">Admin</option></select></div><div class="field full"><button class="button button-small" type="submit">Grant role</button><span class="form-message" aria-live="polite"></span></div></form><div class="table-wrap"><table class="data-table"><thead><tr><th>User UUID</th><th>Role</th><th>Granted</th><th></th></tr></thead><tbody>${(roleQuery.data||[]).map(role=>`<tr><td>${escapeHtml(role.user_id)}</td><td>${escapeHtml(role.role)}</td><td>${formatDate(role.created_at)}</td><td>${role.user_id!==currentUser?.id || role.role!=="admin"?`<button class="button button-outline button-small" data-revoke-role="${escapeHtml(role.id)}">Revoke</button>`:""}</td></tr>`).join("")}</tbody></table></div></div>`:"";
    app.innerHTML=`<section class="page-hero"><div class="container"><span class="eyebrow">Administration</span><h1>Moderation & management</h1><p>Every privileged update is checked again by database role policies.</p></div></section>
      <section class="section"><div class="container">
        <div class="dashboard-panel"><h2>Pending moderation</h2><div class="list-grid">${records.flatMap(group=>group.rows.map(row=>`<article class="data-card"><span class="tag">${escapeHtml(group.label)}</span><h2>${escapeHtml(row.title||row.name||row.body||row.reason||"Untitled")}</h2><p>${escapeHtml(row.description||row.summary||row.content||"Awaiting review.")}</p><span class="data-bottom"><span>${formatDate(row.created_at)}</span><span><button class="button button-small" data-moderate="${escapeHtml(row.id)}" data-table="${group.table}" data-status="${group.approve}" data-verified="${group.table==="news_articles"}">${group.table==="reports"?"Resolve":"Approve"}</button> <button class="button button-outline button-small" data-moderate="${escapeHtml(row.id)}" data-table="${group.table}" data-status="${group.reject}">${group.table==="reports"?"Dismiss":"Reject"}</button></span></span></article>`)).join("")||emptyState("No submissions to review","Pending content and reports will appear here.")}</div></div>
        ${isAdmin?`<div class="dashboard-panel"><h2>Published classified ads</h2><p>Unpublish or permanently delete an ad when necessary.</p><div class="table-wrap">${publishedAds.length?`<table class="data-table"><thead><tr><th>Title</th><th>Seller</th><th>Location</th><th>Published</th><th>Actions</th></tr></thead><tbody>${publishedAds.map(ad=>`<tr data-ad-row="${escapeHtml(ad.id)}"><td><a href="ad-details.html?slug=${encodeURIComponent(ad.slug||ad.id)}">${escapeHtml(ad.title)}</a></td><td>${escapeHtml(ad.seller_name)}<br>${escapeHtml(ad.phone)}</td><td>${escapeHtml([ad.city,ad.state].filter(Boolean).join(", "))}</td><td>${formatDate(ad.created_at)}</td><td><button class="button button-outline button-small" data-ad-manage="unpublish" data-ad-id="${escapeHtml(ad.id)}">Unpublish</button> <button class="button button-outline button-small" data-ad-manage="delete" data-ad-id="${escapeHtml(ad.id)}">Delete</button></td></tr>`).join("")}</tbody></table>`:emptyState("No published ads","Published classified ads will appear here.")}</div></div>`:""}
        <div class="dashboard-panel"><h2>Published community offers</h2><p>Offers publish immediately; remove or archive anything misleading or expired.</p><div class="table-wrap">${publishedOffers.length?`<table class="data-table"><thead><tr><th>Offer</th><th>Store</th><th>Type</th><th>Published</th><th>Actions</th></tr></thead><tbody>${publishedOffers.map(offer=>`<tr><td><a href="${escapeHtml(safeHttpUrl(offer.affiliate_url))}" target="_blank" rel="noopener noreferrer">${escapeHtml(offer.title)}</a></td><td>${escapeHtml(offer.merchant||"")}</td><td>${escapeHtml(offer.offer_type||"product")}</td><td>${formatDate(offer.created_at)}</td><td><button class="button button-outline button-small" data-offer-manage="archive" data-offer-id="${escapeHtml(offer.id)}">Unpublish</button> <button class="button button-outline button-small" data-offer-manage="delete" data-offer-id="${escapeHtml(offer.id)}">Delete</button></td></tr>`).join("")}</tbody></table>`:emptyState("No published offers","Community offers will appear here.")}</div></div>
        <div class="dashboard-panel admin-tools"><h2>Add a deal or coupon</h2><p>Only enter offers and coupon codes confirmed by the merchant. New entries stay pending until approved.</p><div class="admin-entry-grid">
          <form class="admin-entry-form" data-admin-create="deals"><h3>New deal</h3>${adminField("title","Title",true)}${adminField("slug","Slug",true)}${adminSelect("category",categoryMap.deals)}${adminField("original_price","Original price",false,"number")}${adminField("sale_price","Sale price",false,"number")}${adminField("discount_percentage","Discount percentage",false,"number")}${adminField("expires_at","Expiry",false,"date")}${adminField("affiliate_url","Merchant / affiliate URL",true,"url")}<div class="field"><label>Description</label><textarea name="description"></textarea></div><button class="button button-small" type="submit">Save deal for review</button><span class="form-message"></span></form>
          <form class="admin-entry-form" data-admin-create="coupons"><h3>New coupon</h3>${adminField("title","Title",true)}${adminField("slug","Slug",true)}${adminSelect("category",categoryMap.coupons)}${adminField("merchant","Merchant",false)}${adminField("coupon_code","Coupon code (verified)",false)}${adminField("expires_at","Expiry",false,"date")}${adminField("affiliate_url","Merchant / affiliate URL",true,"url")}<div class="field"><label>Description</label><textarea name="description"></textarea></div><button class="button button-small" type="submit">Save coupon for review</button><span class="form-message"></span></form>
        </div></div>
        ${roleManagement}
      </div></section>`;
    app.querySelectorAll("[data-moderate]").forEach(button=>button.addEventListener("click",()=>moderateRecord(button)));
    app.querySelectorAll("[data-ad-manage]").forEach(button=>button.addEventListener("click",async()=>{
      const action=button.dataset.adManage;
      if(action==="delete"&&!confirm("Permanently delete this ad and its photos?"))return;
      button.disabled=true;
      try{
        if(action==="delete")await deleteModeratedRecord("classified_ads",button.dataset.adId);
        else await updateModeratedRecord("classified_ads",button.dataset.adId,"archived");
        button.closest("tr").remove();
        showToast(action==="delete"?"Ad deleted.":"Ad unpublished.");
      }catch(error){showToast(error.message,"error");button.disabled=false;}
    }));
    app.querySelectorAll("[data-offer-manage]").forEach(button=>button.addEventListener("click",async()=>{
      const action=button.dataset.offerManage;
      if(action==="delete"&&!confirm("Permanently delete this offer?"))return;
      button.disabled=true;
      try{
        if(action==="delete")await deleteModeratedRecord("deals",button.dataset.offerId);
        else await updateModeratedRecord("deals",button.dataset.offerId,"archived");
        button.closest("tr").remove();
        showToast(action==="delete"?"Offer deleted.":"Offer unpublished.");
      }catch(error){showToast(error.message,"error");button.disabled=false;}
    }));
    app.querySelectorAll("[data-admin-create]").forEach(form=>form.addEventListener("submit",event=>createAdminRecord(event)));
    app.querySelector("#role-form")?.addEventListener("submit",event=>grantRole(event));
    app.querySelectorAll("[data-revoke-role]").forEach(button=>button.addEventListener("click",async()=>{
      if(!confirm("Revoke this role?"))return;
      button.disabled=true;
      try{await revokeUserRole(button.dataset.revokeRole);button.closest("tr").remove();showToast("Role revoked.");}
      catch(error){showToast(error.message,"error");button.disabled=false;}
    }));
  }catch(error){console.error(error);app.innerHTML=`<section class="section"><div class="container">${emptyState("Admin panel could not load",error.message)}</div></section>`;}
}

function adminField(name,label,required,type="text"){
  return `<div class="field"><label for="admin-${name}">${escapeHtml(label)}</label><input id="admin-${name}" name="${name}" type="${type}" ${required?"required":""} ${type==="number"?'min="0" step="0.01"':""}></div>`;
}
function adminSelect(name,options){
  return `<div class="field"><label for="admin-${name}">Category</label><select id="admin-${name}" name="${name}" required><option value="">Select category</option>${options.map(option=>`<option>${escapeHtml(option)}</option>`).join("")}</select></div>`;
}
async function createAdminRecord(event){
  event.preventDefault();
  const form=event.currentTarget,table=form.dataset.adminCreate,values=Object.fromEntries(new FormData(form)),message=form.querySelector(".form-message"),button=form.querySelector("button");
  button.disabled=true;
  try{
    for(const [key,value] of Object.entries(values))if(typeof value==="string")values[key]=value.trim()||null;
    if(!values.slug)values.slug=slugify(values.title||"");
    await createModeratedRecord(table,values);
    form.reset();message.textContent="Saved. It will be published after approval.";showToast("Content submitted to moderation.");
  }catch(error){message.textContent=error.message;message.classList.add("form-error");}
  finally{button.disabled=false;}
}
async function moderateRecord(button){
  button.disabled=true;
  try{
    const table=button.dataset.table,status=button.dataset.status;
    await updateModeratedRecord(table,button.dataset.moderate,status);
    button.closest(".data-card").remove();showToast(`Record updated: ${status}.`);
  }catch(error){showToast(error.message,"error");button.disabled=false;}
}
async function grantRole(event){
  event.preventDefault();
  const form=event.currentTarget,values=Object.fromEntries(new FormData(form)),message=form.querySelector(".form-message"),button=form.querySelector("button");
  button.disabled=true;
  try{
    await grantUserRole(values.user_id.trim(),values.role);
    message.textContent="Role granted. Refresh to see the updated role list.";form.reset();
  }catch(error){message.textContent=error.message;message.classList.add("form-error");}
  finally{button.disabled=false;}
}

async function subscribeNewsletter(event) {
  event.preventDefault();
  try{const supabase=await getSupabase();if(!supabase)throw new Error("Newsletter signup will be available after Supabase is configured.");const email=new FormData(event.currentTarget).get("email").trim().toLowerCase();const {error}=await supabase.from("newsletter_subscribers").insert({email});if(error)throw error;event.currentTarget.reset();showToast("Thanks for subscribing.");}catch(error){showToast(error.message,"error");}
}

async function renderInteractive(app) {
  setPageTitle("Quiz, polls and more", "Take part in community quizzes and polls.");
  app.innerHTML=`<section class="page-hero"><div class="container"><span class="eyebrow">Interactive zone</span><h1>Learn a little. Share a lot.</h1><p>Community quizzes and polls appear here when published by the site team.</p></div></section><section class="section"><div class="container"><div class="content-grid" id="interactive-items">${loadingCards()}</div><div class="notice notice-info">Points and badges are awarded only for eligible contributions. No activity can be repeatedly claimed for points.</div></div></section>`;
  const root=app.querySelector("#interactive-items");
  try{
    const supabase=await getSupabase();if(!supabase){root.innerHTML=emptyState("No activities available yet","Connect to Supabase to load published quizzes and polls.");return;}
    const [{data:quizzes,error:qErr},{data:polls,error:pErr}]=await Promise.all([supabase.from("quizzes").select("id,title,description,category").eq("status","published"),supabase.from("polls").select("id,title,description").eq("status","published")]);
    if(qErr)throw qErr;if(pErr)throw pErr;
    const rows=[...(quizzes||[]).map(x=>({...x,type:"Quiz"})),...(polls||[]).map(x=>({...x,type:"Poll"}))];
    root.innerHTML=rows.length?rows.map(x=>`<article class="content-card"><span class="tag">${x.type}</span><h3>${escapeHtml(x.title)}</h3><p>${escapeHtml(x.description||"")}</p><span class="card-bottom">Coming soon ↗</span></article>`).join(""):emptyState("No quizzes or polls published yet","Activities created by the site team will appear here.");
  }catch(error){console.error(error);root.innerHTML=emptyState("Activities could not be loaded",error.message);}
}

async function renderTools(app) {
  setPageTitle("Free SEO and browser tools", "A useful collection of free, private browser-based tools.");
  app.innerHTML=`<section class="page-hero"><div class="container"><span class="eyebrow">Free tools, no sign-up</span><h1>Useful tools for your digital work.</h1><p>Run locally in your browser. Text and images you enter are not uploaded to DigitalDuniya360.</p></div></section><section class="section"><div class="container"><div class="tool-grid">${toolDefinitions()}</div></div></section>`;
  bindTools(app);
}

function toolDefinitions() {
  const tools=[
    ["word-counter","Word counter","Count words, characters, sentences and reading time.",`<textarea data-input placeholder="Paste or type text here"></textarea><div class="tool-output" data-output>Words: 0 · Characters: 0 · Sentences: 0</div>`],
    ["character-counter","Character counter","Count characters with and without whitespace.",`<textarea data-input placeholder="Paste or type text here"></textarea><div class="tool-output" data-output>Characters: 0 · Without spaces: 0</div>`],
    ["qr","QR code generator","Generate a QR code locally in your browser.",`<input data-input placeholder="Enter text or URL"><button class="button button-small tool-action" data-action="qr">Generate QR code</button><div class="tool-output" data-output>Enter a value to create a QR code.</div>`],
    ["meta","Meta tag generator","Create a simple HTML title and description snippet.",`<input data-title placeholder="Page title"><textarea data-description placeholder="Meta description (up to 160 characters)"></textarea><button class="button button-small tool-action" data-action="meta">Generate tags</button><div class="tool-output" data-output></div>`],
    ["density","Keyword density checker","See the most frequent meaningful words in your text.",`<textarea data-input placeholder="Paste text to analyze"></textarea><button class="button button-small tool-action" data-action="density">Check density</button><div class="tool-output" data-output></div>`],
    ["password","Password generator","Create a strong random password using browser cryptography.",`<input type="number" data-length value="18" min="8" max="64"><button class="button button-small tool-action" data-action="password">Generate password</button><div class="tool-output" data-output></div>`],
    ["url","URL encoder & decoder","Encode or decode a URL component.",`<textarea data-input placeholder="Text or encoded value"></textarea><select data-mode><option value="encode">Encode</option><option value="decode">Decode</option></select><button class="button button-small tool-action" data-action="url">Convert</button><div class="tool-output" data-output></div>`],
    ["image","Image compressor","Compress a local image. Output remains on your device.",`<input type="file" data-file accept="image/*"><label>Quality <input type="range" data-quality min=".2" max=".95" step=".05" value=".75"></label><button class="button button-small tool-action" data-action="compress">Compress image</button><div class="tool-output" data-output></div>`],
    ["webp","Image to WebP converter","Convert a local image to WebP in your browser.",`<input type="file" data-file accept="image/*"><button class="button button-small tool-action" data-action="webp">Convert to WebP</button><div class="tool-output" data-output></div>`],
    ["serp","SERP snippet preview","Preview how a title and description could appear in search.",`<input data-title maxlength="70" placeholder="Page title"><input data-url placeholder="https://example.com/page"><textarea data-description maxlength="160" placeholder="Meta description"></textarea><div class="tool-output" data-output><strong>Page title</strong><br><span style="color:#567d45">https://example.com/page</span><br>Description preview…</div>`],
    ["robots","Robots.txt generator","Create a basic robots.txt file for your website.",`<input data-sitemap placeholder="https://example.com/sitemap.xml"><button class="button button-small tool-action" data-action="robots">Generate robots.txt</button><div class="tool-output" data-output></div>`],
    ["sitemap","Sitemap XML generator","Create a small XML sitemap from one URL per line.",`<textarea data-input placeholder="https://example.com/&#10;https://example.com/about"></textarea><button class="button button-small tool-action" data-action="sitemap">Generate XML</button><div class="tool-output" data-output></div>`],
    ["schema","Schema markup generator","Generate basic Organization JSON-LD markup.",`<input data-name placeholder="Organization name"><input data-url placeholder="Website URL"><input data-logo placeholder="Logo URL (optional)"><button class="button button-small tool-action" data-action="schema">Generate schema</button><div class="tool-output" data-output></div>`],
    ["seo-check","Basic website SEO checker","Check a page's title, description, headings and image alt text.",`<input data-url placeholder="https://example.com"><button class="button button-small tool-action" data-action="seo-check">Check page</button><div class="tool-output" data-output>Note: browser cross-origin rules may block page inspection. This is not a full technical audit.</div>`],
  ];
  return tools.map(([id,title,desc,controls])=>`<section class="tool-panel" id="tool-${id}"><h2>${title}</h2><p>${desc}</p>${controls}</section>`).join("");
}

function bindTools(app) {
  app.querySelector("#tool-word-counter [data-input]").addEventListener("input",e=>{
    const text=e.target.value.trim(), words=text?text.split(/\s+/).length:0, sentences=(text.match(/[.!?]+/g)||[]).length, minutes=Math.ceil(words/200);
    app.querySelector("#tool-word-counter [data-output]").textContent=`Words: ${words} · Characters: ${e.target.value.length} · Sentences: ${sentences} · Reading time: ${minutes} min`;
  });
  app.querySelector("#tool-character-counter [data-input]").addEventListener("input",e=>{
    app.querySelector("#tool-character-counter [data-output]").textContent=`Characters: ${e.target.value.length} · Without spaces: ${e.target.value.replace(/\s/g,"").length}`;
  });
  app.querySelector("#tool-serp [data-title]").addEventListener("input",updateSerp);
  app.querySelector("#tool-serp [data-description]").addEventListener("input",updateSerp);
  app.querySelector("#tool-serp [data-url]").addEventListener("input",updateSerp);
  app.querySelector("#tool-serp [data-url]").addEventListener("input",updateSerp);
  app.querySelectorAll(".tool-action").forEach(button=>button.addEventListener("click",()=>runTool(button.dataset.action,button.closest(".tool-panel"))));
}
function updateSerp(){
  const panel=document.querySelector("#tool-serp"), title=panel.querySelector("[data-title]").value||"Page title", url=panel.querySelector("[data-url]").value||"https://example.com/page", desc=panel.querySelector("[data-description]").value||"Description preview…";
  panel.querySelector("[data-output]").innerHTML=`<strong>${escapeHtml(title)}</strong><br><span style="color:#567d45">${escapeHtml(url)}</span><br>${escapeHtml(desc)}`;
}
async function runTool(action,panel) {
  const output=panel.querySelector("[data-output]");
  try {
    if(action==="qr"){
      const text=panel.querySelector("[data-input]").value.trim();if(!text)throw new Error("Enter text or a URL first.");
      const QRCode=(await import("https://esm.sh/qrcode@1.5.4")).default;
      const canvas=document.createElement("canvas");await QRCode.toCanvas(canvas,text,{width:180,margin:1});output.replaceChildren(canvas);
    } else if(action==="meta") {
      const title=panel.querySelector("[data-title]").value, description=panel.querySelector("[data-description]").value;
      output.textContent=`<title>${title.replace(/[<>&"]/g,"")}</title>\n<meta name="description" content="${description.replace(/[<>&"]/g,"")}">`;
    } else if(action==="density") {
      const words=(panel.querySelector("[data-input]").value.toLowerCase().match(/\b[\p{L}\p{N}]+\b/gu)||[]),counts={};
      words.forEach(w=>{if(w.length>2)counts[w]=(counts[w]||0)+1;});
      const top=Object.entries(counts).sort((a,b)=>b[1]-a[1]).slice(0,12);
      output.textContent=top.length?top.map(([w,n])=>`${w}: ${n} (${(n/words.length*100).toFixed(1)}%)`).join(" · "):"Enter some text to analyze.";
    } else if(action==="password") {
      const length=Number(panel.querySelector("[data-length]").value);if(!Number.isInteger(length)||length<8||length>64)throw new Error("Choose a length from 8 to 64.");
      const alphabet="ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%&*+-_";
      const random=new Uint32Array(length);crypto.getRandomValues(random);
      output.textContent=Array.from(random,n=>alphabet[n%alphabet.length]).join("");
    } else if(action==="url") {
      const raw=panel.querySelector("[data-input]").value;
      output.textContent=panel.querySelector("[data-mode]").value==="encode"?encodeURIComponent(raw):decodeURIComponent(raw);
    } else if(action==="compress"||action==="webp") {
      const file=panel.querySelector("[data-file]").files[0];if(!file)throw new Error("Choose an image first.");
      const bitmap=await createImageBitmap(file),canvas=document.createElement("canvas");canvas.width=bitmap.width;canvas.height=bitmap.height;canvas.getContext("2d").drawImage(bitmap,0,0);
      const type=action==="webp"?"image/webp":file.type,quality=Number(panel.querySelector("[data-quality]")?.value||.75);
      const blob=await new Promise(resolve=>canvas.toBlob(resolve,type,quality));if(!blob)throw new Error("This image format cannot be converted in this browser.");
      const extension=type==="image/png"?".png":type==="image/jpeg"?".jpg":".webp";
      const link=document.createElement("a");link.href=URL.createObjectURL(blob);link.download=`${file.name.replace(/\.[^.]+$/,"")}${action==="webp"?".webp":`-compressed${extension}`}`;link.textContent=`Download result (${(blob.size/1024).toFixed(1)} KB)`;
      output.replaceChildren(link,document.createTextNode(` · Original ${(file.size/1024).toFixed(1)} KB`));
    } else if(action==="robots") {
      const sitemap=panel.querySelector("[data-sitemap]").value.trim();output.textContent=`User-agent: *\nAllow: /\nDisallow: /admin/\nDisallow: /user-dashboard.html\nDisallow: /login.html\nDisallow: /register.html${sitemap?`\nSitemap: ${sitemap}`:""}`;
    } else if(action==="sitemap") {
      const urls=panel.querySelector("[data-input]").value.split(/\s+/).map(x=>x.trim()).filter(Boolean);
      if(!urls.length)throw new Error("Enter at least one URL.");
      const entries=urls.map(value=>{const url=new URL(value);if(!["http:","https:"].includes(url.protocol))throw new Error("Use HTTP or HTTPS URLs only.");return `<url><loc>${escapeHtml(url.href)}</loc></url>`;}).join("");
      output.textContent=`<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">${entries}</urlset>`;
    } else if(action==="schema") {
      const name=panel.querySelector("[data-name]").value,url=panel.querySelector("[data-url]").value,logo=panel.querySelector("[data-logo]").value;
      if(!name||!url)throw new Error("Organization name and valid URL are required.");
      const data={"@context":"https://schema.org","@type":"Organization",name,url};if(logo)data.logo=logo;output.textContent=JSON.stringify(data,null,2);
    } else if(action==="seo-check") {
      const raw=panel.querySelector("[data-url]").value;const url=new URL(raw);if(!["https:","http:"].includes(url.protocol))throw new Error("Enter a valid HTTP or HTTPS URL.");
      if(url.origin!==location.origin)throw new Error("Cross-origin browser rules prevent inspection of this site. Use a same-origin URL or server-side audit tooling.");
      const response=await fetch(url.href,{credentials:"same-origin"});if(!response.ok)throw new Error(`The page returned HTTP ${response.status}.`);
      const doc=new DOMParser().parseFromString(await response.text(),"text/html"),title=doc.querySelector("title")?.textContent?.trim()||"Missing",description=doc.querySelector('meta[name="description"]')?.content?.trim()||"Missing";
      const headings=doc.querySelectorAll("h1").length,images=[...doc.images],missingAlt=images.filter(image=>!image.hasAttribute("alt")).length;
      output.textContent=`Title: ${title} (${title==="Missing"?"missing":"present"})\nMeta description: ${description} (${description==="Missing"?"missing":"present"})\nH1 headings: ${headings} · Images missing alt: ${missingAlt}/${images.length}\nNote: browser checker only; not a full crawler or performance audit.`;
    }
  } catch(error) { output.textContent=error.message;output.classList.add("form-error");setTimeout(()=>output.classList.remove("form-error"),3000); }
}
