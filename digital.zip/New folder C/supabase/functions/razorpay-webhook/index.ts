import {
  checkOrigin,
  createServiceClient,
  handleError,
  HttpError,
  jsonResponse,
  readSecret
} from "../_shared/http.ts";

const encoder = new TextEncoder();

function hex(bytes: ArrayBuffer): string {
  return [...new Uint8Array(bytes)].map(value => value.toString(16).padStart(2, "0")).join("");
}

async function hmacHex(secret: string, value: string): Promise<string> {
  const key = await crypto.subtle.importKey(
    "raw",
    encoder.encode(secret),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"]
  );
  return hex(await crypto.subtle.sign("HMAC", key, encoder.encode(value)));
}

function constantTimeEqual(left: string, right: string): boolean {
  if (!/^[0-9a-f]{64}$/i.test(left) || !/^[0-9a-f]{64}$/i.test(right)) return false;
  let diff = 0;
  for (let index = 0; index < left.length; index++) diff |= left.charCodeAt(index) ^ right.charCodeAt(index);
  return diff === 0;
}

async function markEvent(service: ReturnType<typeof createServiceClient>, eventId: string, status: string, errorMessage?: string) {
  const { error } = await service.from("payment_webhook_events").update({
    status,
    error_message: errorMessage?.slice(0, 500) || null,
    processed_at: new Date().toISOString()
  }).eq("event_id", eventId);
  if (error) throw new HttpError(500, "The webhook result could not be recorded.");
}

function isoFromUnix(value: unknown): string | null {
  const seconds = Number(value);
  if (!Number.isSafeInteger(seconds) || seconds <= 0) return null;
  return new Date(seconds * 1000).toISOString();
}

async function recordSubscriptionStatus(
  service: ReturnType<typeof createServiceClient>,
  subscriptionId: string,
  status: string,
  entity: Record<string, any>
) {
  const { error } = await service.rpc("record_subscription_status", {
    p_subscription_id: subscriptionId,
    p_status: status,
    p_current_start: isoFromUnix(entity.current_start),
    p_current_end: isoFromUnix(entity.current_end)
  });
  if (error) throw new HttpError(503, "Subscription status could not be saved; Razorpay should retry this webhook.");
}

Deno.serve(async request => {
  if (request.method !== "POST") return jsonResponse(request, { error: "Method not allowed." }, 405);
  let eventId = "";
  const service = createServiceClient();
  try {
    checkOrigin(request, true);
    const signature = request.headers.get("x-razorpay-signature") || "";
    eventId = request.headers.get("x-razorpay-event-id") || "";
    if (!eventId || eventId.length > 200) throw new HttpError(400, "Razorpay event ID is required.");
    const rawBody = await request.text();
    const expected = await hmacHex(readSecret("RAZORPAY_WEBHOOK_SECRET"), rawBody);
    if (!constantTimeEqual(signature, expected)) throw new HttpError(401, "Webhook signature verification failed.");

    let event: Record<string, any>;
    try {
      event = JSON.parse(rawBody);
    } catch {
      throw new HttpError(400, "Webhook body is not valid JSON.");
    }
    const eventType = typeof event.event === "string" ? event.event : "unknown";
    const payment = event.payload?.payment?.entity;
    const order = event.payload?.order?.entity;
    const subscription = event.payload?.subscription?.entity;
    const invoice = event.payload?.invoice?.entity;
    const orderId = typeof payment?.order_id === "string" ? payment.order_id
      : typeof order?.id === "string" ? order.id : null;
    const paymentId = typeof payment?.id === "string" ? payment.id : null;
    const subscriptionId = typeof subscription?.id === "string" ? subscription.id
      : typeof payment?.subscription_id === "string" ? payment.subscription_id : null;
    const { error: insertError } = await service.from("payment_webhook_events").insert({
      event_id: eventId,
      event_type: eventType,
      order_id: orderId,
      subscription_id: subscriptionId,
      payment_id: paymentId,
      status: "received"
    });
    if (insertError) {
      if (insertError.code !== "23505") throw new HttpError(500, "Webhook event could not be recorded.");
      const { data: previous, error: readError } = await service
        .from("payment_webhook_events").select("status").eq("event_id", eventId).maybeSingle();
      if (readError) throw new HttpError(500, "Webhook event status could not be checked.");
      if (previous?.status === "processed" || previous?.status === "ignored") {
        return jsonResponse(request, { received: true, duplicate: true });
      }
    }

    const subscriptionStatuses: Record<string, string> = {
      "subscription.authenticated": "authenticated",
      "subscription.activated": "active",
      "subscription.pending": "pending",
      "subscription.halted": "halted",
      "subscription.cancelled": "cancelled",
      "subscription.completed": "completed",
      "subscription.paused": "paused",
      "subscription.resumed": "active"
    };
    if (eventType === "subscription.charged") {
      if (!subscriptionId || !payment || !paymentId) {
        await markEvent(service, eventId, "failed", "Subscription charge details are absent.");
        throw new HttpError(400, "Subscription charge details are absent.");
      }
      if (
        payment.status !== "captured" ||
        payment.captured !== true ||
        Number(payment.amount) <= 0 ||
        payment.currency !== "INR"
      ) {
        await markEvent(service, eventId, "failed", "Razorpay did not confirm a captured INR subscription payment.");
        throw new HttpError(400, "Subscription payment is not captured.");
      }
      const currentStart = isoFromUnix(subscription?.current_start);
      const currentEnd = isoFromUnix(subscription?.current_end);
      if (!currentStart || !currentEnd) {
        await markEvent(service, eventId, "failed", "Subscription billing period is absent.");
        throw new HttpError(400, "Subscription billing period is absent.");
      }
      const { error } = await service.rpc("record_subscription_charge", {
        p_subscription_id: subscriptionId,
        p_payment_id: paymentId,
        p_invoice_id: typeof invoice?.id === "string" ? invoice.id
          : typeof payment.invoice_id === "string" ? payment.invoice_id : null,
        p_amount_paise: Number(payment.amount),
        p_paid_at: isoFromUnix(payment.created_at),
        p_current_start: currentStart,
        p_current_end: currentEnd,
        p_subscription_status: subscription.status === "completed" ? "completed" : "active"
      });
      if (error) {
        await markEvent(service, eventId, "failed", error.message);
        throw new HttpError(503, "Verified subscription payment could not be activated yet; Razorpay should retry this webhook.");
      }
      await markEvent(service, eventId, "processed");
      return jsonResponse(request, { received: true, status: "paid" });
    }

    if (subscriptionStatuses[eventType]) {
      if (!subscriptionId) {
        await markEvent(service, eventId, "failed", "Subscription ID is absent.");
        throw new HttpError(400, "Subscription ID is absent.");
      }
      await recordSubscriptionStatus(service, subscriptionId, subscriptionStatuses[eventType], subscription || {});
      await markEvent(service, eventId, "processed");
      return jsonResponse(request, { received: true, status: subscriptionStatuses[eventType] });
    }

    if (eventType === "payment.failed" && subscriptionId) {
      if (!payment || !paymentId || Number(payment.amount) <= 0 || payment.currency !== "INR") {
        await markEvent(service, eventId, "failed", "Failed subscription payment details are absent.");
        throw new HttpError(400, "Failed subscription payment details are absent.");
      }
      const { error } = await service.rpc("record_subscription_failure", {
        p_subscription_id: subscriptionId,
        p_payment_id: paymentId,
        p_invoice_id: typeof invoice?.id === "string" ? invoice.id
          : typeof payment.invoice_id === "string" ? payment.invoice_id : null,
        p_amount_paise: Number(payment.amount),
        p_failure_code: String(payment.error_code || "payment_failed"),
        p_failure_description: String(payment.error_description || "Razorpay reported a failed subscription payment.")
      });
      if (error) {
        await markEvent(service, eventId, "failed", error.message);
        throw new HttpError(503, "Failed subscription payment could not be recorded; Razorpay should retry this webhook.");
      }
      await markEvent(service, eventId, "processed");
      return jsonResponse(request, { received: true, status: "failed" });
    }

    if (["payment.captured", "order.paid"].includes(eventType) && subscriptionId) {
      await markEvent(service, eventId, "ignored");
      return jsonResponse(request, { received: true, ignored: true, reason: "subscription.charged is authoritative" });
    }

    if (!["payment.captured", "order.paid", "payment.failed"].includes(eventType)) {
      await markEvent(service, eventId, "ignored");
      return jsonResponse(request, { received: true, ignored: true });
    }
    if (!payment || !orderId || !paymentId) {
      await markEvent(service, eventId, "failed", "Required payment fields are absent.");
      return jsonResponse(request, { error: "Required payment fields are absent." }, 400);
    }

    const { data: transaction, error: transactionError } = await service
      .from("payment_transactions")
      .select("id,user_id,amount_paise,order_id,status")
      .eq("order_id", orderId)
      .maybeSingle();
    if (transactionError) throw new HttpError(500, "Payment transaction lookup failed.");
    if (!transaction) {
      await markEvent(service, eventId, "failed", "No local payment transaction matches this order.");
      throw new HttpError(503, "Payment order is not yet available; Razorpay should retry this webhook.");
    }

    if (
      Number(payment.amount) !== transaction.amount_paise ||
      payment.currency !== "INR" ||
      transaction.order_id !== orderId
    ) {
      await markEvent(service, eventId, "failed", "Payment amount, currency, or order does not match.");
      throw new HttpError(400, "Payment details do not match the stored order.");
    }

    if (eventType === "payment.failed") {
      const { error } = await service.from("payment_transactions").update({
        status: "failed",
        payment_id: paymentId,
        failure_code: String(payment.error_code || "payment_failed").slice(0, 100),
        failure_description: String(payment.error_description || "Razorpay reported a failed payment.").slice(0, 500)
      }).eq("id", transaction.id).neq("status", "paid");
      if (error) throw new HttpError(500, "Failed payment status could not be saved.");
      await markEvent(service, eventId, "processed");
      return jsonResponse(request, { received: true, status: "failed" });
    }

    if (payment.status !== "captured" || payment.captured !== true) {
      await markEvent(service, eventId, "failed", "Razorpay did not mark the payment captured.");
      throw new HttpError(400, "Payment is not captured.");
    }

    const { error: activationError } = await service.rpc("activate_membership_from_payment", {
      p_transaction_id: transaction.id,
      p_order_id: orderId,
      p_payment_id: paymentId,
      p_amount_paise: Number(payment.amount),
      p_paid_at: payment.created_at ? new Date(Number(payment.created_at) * 1000).toISOString() : new Date().toISOString()
    });
    if (activationError) {
      await markEvent(service, eventId, "failed", activationError.message);
      throw new HttpError(503, "Verified payment could not be activated yet; Razorpay should retry this webhook.");
    }

    await markEvent(service, eventId, "processed");
    return jsonResponse(request, { received: true, status: "paid" });
  } catch (error) {
    return handleError(request, error);
  }
});
