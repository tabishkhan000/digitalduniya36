import {
  authenticatedRequest,
  checkOrigin,
  createServiceClient,
  handleError,
  HttpError,
  jsonResponse,
  readJson,
  readSecret,
  requiredString
} from "../_shared/http.ts";

const uuidPattern = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const contentTables = new Set(["classified_ads", "blog_posts", "jobs", "businesses"]);

function pageSize(value: unknown, fallback = 50, maximum = 100): number {
  const parsed = Number(value);
  return Number.isInteger(parsed) ? Math.min(maximum, Math.max(1, parsed)) : fallback;
}

async function ensureAdmin(service: ReturnType<typeof createServiceClient>, userId: string): Promise<void> {
  const { data, error } = await service.from("admin_roles").select("id").eq("user_id", userId).maybeSingle();
  if (error) throw new HttpError(500, "Administrator role could not be verified.");
  if (!data) throw new HttpError(403, "Administrator access is required.");
}

async function audit(
  service: ReturnType<typeof createServiceClient>,
  actorId: string,
  action: string,
  entityType: string,
  entityId: string | null,
  details: Record<string, unknown> = {}
) {
  const { error } = await service.from("admin_audit_logs").insert({
    actor_id: actorId,
    action,
    entity_type: entityType,
    entity_id: entityId,
    details
  });
  if (error) throw new HttpError(500, "The action completed, but its audit record could not be saved.");
}

async function userSearch(client: Awaited<ReturnType<typeof authenticatedRequest>>["client"], body: Record<string, unknown>) {
  const query = typeof body.query === "string" ? body.query.slice(0, 120) : "";
  const limit = pageSize(body.limit, 50, 100);
  const offset = Math.max(0, Number.isInteger(Number(body.offset)) ? Number(body.offset) : 0);
  const { data, error } = await client.rpc("admin_search_users", {
    p_query: query,
    p_limit: limit,
    p_offset: offset
  });
  if (error) throw new HttpError(403, "User search was denied.");
  return data;
}

async function userDetail(service: ReturnType<typeof createServiceClient>, userId: string) {
  if (!uuidPattern.test(userId)) throw new HttpError(400, "A valid user ID is required.");
  const [profile, memberships, subscriptions, payments, usage] = await Promise.all([
    service.from("profiles").select("id,email,full_name,account_status,suspended_at,created_at").eq("id", userId).maybeSingle(),
    service.from("user_memberships").select("id,amount_paise,status,starts_at,expires_at,created_at,plan:membership_plans(code,name)").eq("user_id", userId).order("created_at", { ascending: false }).limit(50),
    service.from("user_subscriptions").select("id,razorpay_subscription_id,status,cancel_at_cycle_end,current_period_start,current_period_end,created_at,plan:membership_plans(code,name)").eq("user_id", userId).order("created_at", { ascending: false }).limit(50),
    service.from("payment_transactions").select("id,amount_paise,currency,order_id,payment_id,status,created_at,paid_at,failure_code,plan:membership_plans(code,name)").eq("user_id", userId).order("created_at", { ascending: false }).limit(50),
    service.from("user_free_usage").select("category,source_id,first_used_at").eq("user_id", userId).order("first_used_at", { ascending: true })
  ]);
  for (const result of [profile, memberships, subscriptions, payments, usage]) {
    if (result.error) throw new HttpError(500, "User account details could not be loaded.");
  }
  if (!profile.data) throw new HttpError(404, "User account was not found.");
  return {
    profile: profile.data,
    memberships: memberships.data || [],
    subscriptions: subscriptions.data || [],
    payments: payments.data || [],
    free_usage: usage.data || []
  };
}

async function cancelRecurringSubscription(
  service: ReturnType<typeof createServiceClient>,
  actorId: string,
  subscriptionId: string
) {
  const { data: subscription, error: lookupError } = await service.from("user_subscriptions")
    .select("id,user_id,razorpay_subscription_id,status,cancel_at_cycle_end,current_period_end")
    .eq("razorpay_subscription_id", subscriptionId).maybeSingle();
  if (lookupError) throw new HttpError(500, "Subscription status could not be loaded.");
  if (!subscription) throw new HttpError(404, "Subscription was not found.");
  if (["cancelled", "completed", "expired"].includes(subscription.status)) {
    return { status: subscription.status, unchanged: true };
  }
  if (subscription.cancel_at_cycle_end) {
    return {
      status: subscription.status,
      cancel_at_cycle_end: true,
      current_period_end: subscription.current_period_end,
      unchanged: true
    };
  }

  const periodEnd = subscription.current_period_end
    ? new Date(subscription.current_period_end).getTime()
    : 0;
  const cancelAtCycleEnd = Number.isFinite(periodEnd) && periodEnd > Date.now()
    && ["active", "pending", "halted", "paused"].includes(subscription.status);
  const response = await fetch(
    `https://api.razorpay.com/v1/subscriptions/${encodeURIComponent(subscriptionId)}/cancel`,
    {
      method: "POST",
      headers: {
        Authorization: `Basic ${btoa(`${readSecret("RAZORPAY_KEY_ID")}:${readSecret("RAZORPAY_KEY_SECRET")}`)}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ cancel_at_cycle_end: cancelAtCycleEnd })
    }
  );
  const result = await response.json().catch(() => ({}));
  if (!response.ok || typeof result.status !== "string") {
    throw new HttpError(502, "Razorpay could not cancel the subscription.");
  }
  const { error: statusError } = await service.rpc("record_subscription_status", {
    p_subscription_id: subscriptionId,
    p_status: result.status,
    p_current_start: result.current_start ? new Date(Number(result.current_start) * 1000).toISOString() : null,
    p_current_end: result.current_end ? new Date(Number(result.current_end) * 1000).toISOString() : null
  });
  if (statusError) throw new HttpError(500, "The provider cancelled the subscription, but the local status needs review.");
  const { error: updateError } = await service.from("user_subscriptions").update({
    cancel_at_cycle_end: cancelAtCycleEnd,
    cancel_requested_at: new Date().toISOString()
  }).eq("id", subscription.id);
  if (updateError) throw new HttpError(500, "The cancellation record could not be saved.");
  const { error: pendingTransactionError } = await service.from("payment_transactions")
    .update({ status: "cancelled", failure_description: "Subscription was cancelled before its first payment." })
    .eq("subscription_id", subscriptionId)
    .eq("status", "pending");
  if (pendingTransactionError) throw new HttpError(500, "Subscription was cancelled, but its pending checkout could not be closed.");
  await audit(service, actorId, "membership.subscription_cancelled", "user_subscriptions", subscription.id, {
    user_id: subscription.user_id,
    razorpay_subscription_id: subscriptionId,
    cancel_at_cycle_end: cancelAtCycleEnd,
    current_period_end: result.current_end ? new Date(Number(result.current_end) * 1000).toISOString() : subscription.current_period_end
  });
  return {
    status: result.status,
    cancel_at_cycle_end: cancelAtCycleEnd,
    current_period_end: result.current_end ? new Date(Number(result.current_end) * 1000).toISOString() : subscription.current_period_end
  };
}

async function listContent(service: ReturnType<typeof createServiceClient>, table: string) {
  if (!contentTables.has(table)) throw new HttpError(400, "Unsupported content table.");
  const columns = table === "classified_ads"
    ? "id,user_id,title,category,city,status,created_at"
    : table === "jobs"
      ? "id,user_id,title,company_name,category,city,status,created_at"
      : table === "businesses"
        ? "id,user_id,name,category,city,status,created_at"
        : "id,user_id,title,category,status,created_at";
  const { data, error } = await service.from(table).select(columns).order("created_at", { ascending: false }).limit(100);
  if (error) throw new HttpError(500, "Content records could not be loaded.");
  return data || [];
}

async function setContentStatus(
  service: ReturnType<typeof createServiceClient>,
  actorId: string,
  table: string,
  id: string,
  status: string
) {
  const allowedStatuses: Record<string, string[]> = {
    classified_ads: ["published", "archived"],
    blog_posts: ["published", "archived"],
    jobs: ["published", "archived"],
    businesses: ["published", "suspended"]
  };
  if (!uuidPattern.test(id) || !allowedStatuses[table]?.includes(status)) {
    throw new HttpError(400, "A valid content record and status are required.");
  }
  const { data: current, error: readError } = await service.from(table)
    .select("id,status").eq("id", id).maybeSingle();
  if (readError) throw new HttpError(500, "Content status could not be loaded.");
  if (!current) throw new HttpError(404, "Content record was not found.");
  if (current.status === status) return { status, unchanged: true };

  const update: Record<string, unknown> = {
    status,
    updated_at: new Date().toISOString()
  };
  if (table === "blog_posts" && status === "published") {
    update.published_at = new Date().toISOString();
  }
  const { data, error } = await service.from(table).update(update)
    .eq("id", id).eq("status", current.status).select("id,status").maybeSingle();
  if (error) throw new HttpError(500, "Content status could not be updated.");
  if (!data) throw new HttpError(409, "Content status changed concurrently. Refresh and retry.");
  await audit(service, actorId, "content.status_changed", table, id, {
    previous_status: current.status,
    new_status: status
  });
  return { status: data.status, unchanged: false };
}

async function cancelMembership(
  service: ReturnType<typeof createServiceClient>,
  actorId: string,
  membershipId: string
) {
  if (!uuidPattern.test(membershipId)) throw new HttpError(400, "A valid membership ID is required.");
  const { data, error } = await service.from("user_memberships")
    .select("id,user_id,status,expires_at,razorpay_subscription_id")
    .eq("id", membershipId)
    .maybeSingle();
  if (error) throw new HttpError(500, "Membership status could not be loaded.");
  if (!data) {
    throw new HttpError(404, "Membership was not found.");
  }
  if (data.razorpay_subscription_id) {
    throw new HttpError(409, "Cancel the recurring subscription to stop future membership periods.");
  }
  if (data.status !== "active") return { status: data.status, unchanged: true };
  const { data: updated, error: updateError } = await service.from("user_memberships")
    .update({ status: "cancelled" })
    .eq("id", membershipId)
    .eq("status", "active")
    .select("id,user_id,status,expires_at")
    .maybeSingle();
  if (updateError) throw new HttpError(500, "Membership could not be cancelled.");
  if (!updated) throw new HttpError(409, "Membership status changed concurrently. Refresh and retry.");
  await audit(service, actorId, "membership.cancelled", "user_memberships", membershipId, {
    user_id: updated.user_id,
    expires_at: updated.expires_at
  });
  return { status: updated.status, unchanged: false };
}

async function suspendOrRestore(
  service: ReturnType<typeof createServiceClient>,
  actorId: string,
  userId: string,
  suspend: boolean
) {
  if (!uuidPattern.test(userId)) throw new HttpError(400, "A valid user ID is required.");
  if (userId === actorId) throw new HttpError(400, "You cannot suspend or restore your own account.");
  const { data: targetAdmin, error: roleError } = await service
    .from("admin_roles").select("id").eq("user_id", userId).maybeSingle();
  if (roleError) throw new HttpError(500, "Target account role could not be checked.");
  if (targetAdmin) throw new HttpError(403, "Administrator accounts cannot be suspended from this dashboard.");

  const { data: profile, error: profileError } = await service
    .from("profiles").select("id,account_status").eq("id", userId).maybeSingle();
  if (profileError) throw new HttpError(500, "Target account could not be loaded.");
  if (!profile) throw new HttpError(404, "User account was not found.");
  const nextStatus = suspend ? "suspended" : "active";
  if (profile.account_status === nextStatus) return { status: nextStatus, unchanged: true };

  const { error: authError } = await service.auth.admin.updateUserById(userId, {
    ban_duration: suspend ? "876000h" : "none"
  });
  if (authError) throw new HttpError(502, "Supabase Auth could not update this account.");

  const { error: updateError } = await service.from("profiles").update({
    account_status: nextStatus,
    suspended_at: suspend ? new Date().toISOString() : null,
    suspended_by: suspend ? actorId : null
  }).eq("id", userId);
  if (updateError) {
    const { error: rollbackError } = await service.auth.admin.updateUserById(userId, {
      ban_duration: suspend ? "none" : "876000h"
    });
    if (rollbackError) {
      throw new HttpError(500, "Auth status changed but the profile update and rollback failed; review this account in Supabase.");
    }
    throw new HttpError(500, "The account status was not changed because its profile could not be updated.");
  }

  await audit(service, actorId, suspend ? "user.suspended" : "user.restored", "profiles", userId, {
    previous_status: profile.account_status,
    new_status: nextStatus
  });
  return { status: nextStatus, unchanged: false };
}

Deno.serve(async request => {
  if (request.method === "OPTIONS") {
    const { corsHeaders } = await import("../_shared/http.ts");
    return new Response(null, { status: 204, headers: corsHeaders(request) });
  }
  if (request.method !== "POST") return jsonResponse(request, { error: "Method not allowed." }, 405);
  try {
    checkOrigin(request);
    const { client, user } = await authenticatedRequest(request);
    const service = createServiceClient();
    await ensureAdmin(service, user.id);
    const body = await readJson(request);
    const action = requiredString(body.action, "Action", 40);

    if (action === "overview") {
      const { data, error } = await client.rpc("admin_membership_overview");
      if (error) throw new HttpError(500, "Membership overview could not be loaded.");
      return jsonResponse(request, data);
    }
    if (action === "users") return jsonResponse(request, await userSearch(client, body));
    if (action === "user-detail") {
      return jsonResponse(request, await userDetail(service, requiredString(body.userId, "User ID", 64)));
    }
    if (action === "content") {
      return jsonResponse(request, { rows: await listContent(service, requiredString(body.table, "Content table", 40)) });
    }
    if (action === "set-content-status") {
      return jsonResponse(request, await setContentStatus(
        service,
        user.id,
        requiredString(body.table, "Content table", 40),
        requiredString(body.id, "Content ID", 64),
        requiredString(body.status, "Content status", 32)
      ));
    }
    if (action === "memberships") {
      const limit = pageSize(body.limit, 100, 500);
      const offset = Math.max(0, Number.isInteger(Number(body.offset)) ? Number(body.offset) : 0);
      const { data, error } = await service.from("user_memberships")
        .select("id,user_id,amount_paise,razorpay_subscription_id,status,starts_at,expires_at,created_at,plan:membership_plans(code,name)")
        .order("created_at", { ascending: false }).range(offset, offset + limit - 1);
      if (error) throw new HttpError(500, "Membership records could not be loaded.");
      return jsonResponse(request, { rows: data || [] });
    }
    if (action === "subscriptions") {
      const limit = pageSize(body.limit, 100, 500);
      const offset = Math.max(0, Number.isInteger(Number(body.offset)) ? Number(body.offset) : 0);
      const { data, error } = await service.from("user_subscriptions")
        .select("id,user_id,razorpay_subscription_id,status,cancel_at_cycle_end,current_period_start,current_period_end,created_at,plan:membership_plans(code,name)")
        .order("created_at", { ascending: false }).range(offset, offset + limit - 1);
      if (error) throw new HttpError(500, "Recurring subscriptions could not be loaded.");
      return jsonResponse(request, { rows: data || [] });
    }
    if (action === "payments") {
      const limit = pageSize(body.limit, 100, 500);
      const offset = Math.max(0, Number.isInteger(Number(body.offset)) ? Number(body.offset) : 0);
      const { data, error } = await service.from("payment_transactions")
        .select("id,user_id,amount_paise,currency,order_id,subscription_id,invoice_id,payment_id,status,created_at,paid_at,verified_at,failure_code,plan:membership_plans(code,name)")
        .order("created_at", { ascending: false }).range(offset, offset + limit - 1);
      if (error) throw new HttpError(500, "Payment records could not be loaded.");
      return jsonResponse(request, { rows: data || [] });
    }
    if (action === "free-usage") {
      const limit = pageSize(body.limit, 500, 1000);
      const offset = Math.max(0, Number.isInteger(Number(body.offset)) ? Number(body.offset) : 0);
      const { data, error } = await service.from("user_free_usage")
        .select("id,user_id,category,source_id,first_used_at")
        .order("first_used_at", { ascending: false }).range(offset, offset + limit - 1);
      if (error) throw new HttpError(500, "Free usage records could not be loaded.");
      const ids = [...new Set((data || []).map(row => row.user_id))];
      const { data: profiles, error: profileError } = ids.length
        ? await service.from("profiles").select("id,email,full_name").in("id", ids)
        : { data: [], error: null };
      if (profileError) throw new HttpError(500, "Free usage account labels could not be loaded.");
      const byId = new Map((profiles || []).map(profile => [profile.id, profile]));
      return jsonResponse(request, {
        rows: (data || []).map(row => ({ ...row, user: byId.get(row.user_id) || null }))
      });
    }
    if (action === "plans") {
      const { data, error } = await service.from("membership_plans")
        .select("id,code,name,amount_paise,duration_days,intro_window_hours,is_introductory,billing_type,billing_cycles,is_active,updated_at")
        .in("code", ["intro-60d", "standard-monthly-12"])
        .order("amount_paise");
      if (error) throw new HttpError(500, "Membership plan settings could not be loaded.");
      return jsonResponse(request, { rows: data || [] });
    }
    if (action === "set-plan-active") {
      const code = requiredString(body.code, "Plan code", 32);
      if (!["intro-60d", "standard-monthly-12"].includes(code) || typeof body.isActive !== "boolean") {
        throw new HttpError(400, "A valid plan and availability setting are required.");
      }
      const { data: plan, error } = await service.from("membership_plans")
        .update({ is_active: body.isActive, updated_at: new Date().toISOString() })
        .eq("code", code).select("id,code,is_active").maybeSingle();
      if (error || !plan) throw new HttpError(500, "Plan availability could not be updated.");
      await audit(service, user.id, "membership_plan.availability_changed", "membership_plans", plan.id, {
        code,
        is_active: plan.is_active
      });
      return jsonResponse(request, { plan });
    }
    if (action === "suspend" || action === "restore") {
      const result = await suspendOrRestore(
        service,
        user.id,
        requiredString(body.userId, "User ID", 64),
        action === "suspend"
      );
      return jsonResponse(request, result);
    }
    if (action === "cancel-membership") {
      return jsonResponse(request, await cancelMembership(
        service,
        user.id,
        requiredString(body.membershipId, "Membership ID", 64)
      ));
    }
    if (action === "cancel-subscription") {
      return jsonResponse(request, await cancelRecurringSubscription(
        service,
        user.id,
        requiredString(body.subscriptionId, "Subscription ID", 128)
      ));
    }
    if (action === "activity") {
      const { data, error } = await service.from("admin_audit_logs")
        .select("id,actor_id,action,entity_type,entity_id,details,created_at")
        .order("created_at", { ascending: false }).limit(pageSize(body.limit, 100, 500));
      if (error) throw new HttpError(500, "Administrator activity could not be loaded.");
      return jsonResponse(request, { rows: data || [] });
    }
    throw new HttpError(400, "Unsupported administration action.");
  } catch (error) {
    return handleError(request, error);
  }
});
