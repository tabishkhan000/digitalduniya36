import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const defaultOrigins = [
  "https://digitalduniya360.com",
  "https://www.digitalduniya360.com",
  "http://localhost:8000"
];

export class HttpError extends Error {
  status: number;
  constructor(status: number, message: string) {
    super(message);
    this.status = status;
  }
}

function requiredEnv(name: string): string {
  const value = Deno.env.get(name);
  if (!value) throw new HttpError(500, `Server configuration is missing ${name}.`);
  return value;
}

function allowedOrigins(): Set<string> {
  const configured = Deno.env.get("ALLOWED_ORIGINS");
  return new Set((configured ? configured.split(",") : defaultOrigins).map(value => value.trim()).filter(Boolean));
}

export function checkOrigin(request: Request, allowMissing = false): void {
  const origin = request.headers.get("origin");
  if (!origin && allowMissing) return;
  if (!origin || !allowedOrigins().has(origin)) {
    throw new HttpError(403, "This website origin is not allowed.");
  }
}

export function corsHeaders(request: Request): HeadersInit {
  const origin = request.headers.get("origin");
  if (!origin || !allowedOrigins().has(origin)) return { "Vary": "Origin" };
  return {
    "Access-Control-Allow-Origin": origin,
    "Access-Control-Allow-Headers": "authorization, apikey, content-type, x-client-info",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Access-Control-Max-Age": "86400",
    "Vary": "Origin"
  };
}

export function jsonResponse(request: Request, data: unknown, status = 200): Response {
  return new Response(JSON.stringify(data), {
    status,
    headers: { ...corsHeaders(request), "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" }
  });
}

export function handleError(request: Request, error: unknown): Response {
  if (error instanceof HttpError) return jsonResponse(request, { error: error.message }, error.status);
  console.error("Edge function failed:", error);
  return jsonResponse(request, { error: "The request could not be completed. Please try again." }, 500);
}

export async function readJson(request: Request): Promise<Record<string, unknown>> {
  const contentLength = Number(request.headers.get("content-length") || 0);
  if (contentLength > 120_000) throw new HttpError(413, "Request body is too large.");
  let value: unknown;
  try {
    value = JSON.parse(await request.text());
  } catch {
    throw new HttpError(400, "A valid JSON request body is required.");
  }
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    throw new HttpError(400, "A JSON object is required.");
  }
  return value as Record<string, unknown>;
}

export function createServiceClient() {
  return createClient(requiredEnv("SUPABASE_URL"), requiredEnv("SUPABASE_SERVICE_ROLE_KEY"), {
    auth: { persistSession: false, autoRefreshToken: false }
  });
}

export async function authenticatedRequest(request: Request) {
  const authorization = request.headers.get("authorization") || "";
  const token = authorization.match(/^Bearer\s+(.+)$/i)?.[1];
  if (!token) throw new HttpError(401, "Sign in to continue.");
  const client = createClient(requiredEnv("SUPABASE_URL"), requiredEnv("SUPABASE_ANON_KEY"), {
    auth: { persistSession: false, autoRefreshToken: false },
    global: { headers: { Authorization: `Bearer ${token}` } }
  });
  const { data, error } = await client.auth.getUser(token);
  if (error || !data.user) throw new HttpError(401, "Your session is invalid or expired.");
  return { client, user: data.user };
}

export function requiredString(value: unknown, name: string, maxLength = 256): string {
  if (typeof value !== "string" || !value.trim() || value.length > maxLength) {
    throw new HttpError(400, `${name} is required.`);
  }
  return value.trim();
}

export function readSecret(name: string): string {
  return requiredEnv(name);
}
