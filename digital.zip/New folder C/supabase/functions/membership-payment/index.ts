import {
  authenticatedRequest,
  checkOrigin,
  createServiceClient,
  handleError,
  HttpError,
  jsonResponse,
  readJson,
  readSecret,
  requiredString
} from "../_shared/http.ts";

const encoder = new TextEncoder();

function hex(bytes: ArrayBuffer): string {
  return [...new Uint8Array(bytes)].map(value => value.toString(16).padStart(2, "0")).join("");
}

async function hmacHex(secret: string, value: string): Promise<string> {
  const key = await crypto.subtle.importKey(
    "raw",
    encoder.encode(secret),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"]
  );
  return hex(await crypto.subtle.sign("HMAC", key, encoder.encode(value)));
}

function constantTimeEqual(left: string, right: string): boolean {
  if (!/^[0-9a-f]{64}$/i.test(left) || !/^[0-9a-f]{64}$/i.test(right)) return false;
  let diff = 0;
  for (let index = 0; index < left.length; index++) {
    diff |= left.charCodeAt(index) ^ right.charCodeAt(index);
  }
  return diff === 0;
}

function razorpayAuth(keyId: string, secret: string): string {
  return `Basic ${btoa(`${keyId}:${secret}`)}`;
}

async function createOrder(request: Request, body: Record<string, unknown>, user: { id: string }) {
  const planCode = requiredString(body.planCode, "Plan code", 32);
  if (!["intro-60d", "standard-monthly-12"].includes(planCode)) throw new HttpError(400, "Unknown membership plan.");
  const keyId = readSecret("RAZORPAY_KEY_ID");
  const keySecret = readSecret("RAZORPAY_KEY_SECRET");
  const razorpayPlanId = planCode === "standard-monthly-12"
    ? readSecret("RAZORPAY_STANDARD_PLAN_ID")
    : null;
  const client = (await authenticatedRequest(request)).client;
  const { data: intent, error: intentError } = await client.rpc("create_membership_order_intent", {
    p_plan_code: planCode
  });
  if (intentError) throw new HttpError(409, intentError.message);
  if (!intent || typeof intent !== "object") throw new HttpError(500, "Could not create the payment intent.");

  const transactionId = requiredString(intent.transaction_id, "Payment transaction", 64);
  const amountPaise = Number(intent.amount_paise);
  if (!Number.isSafeInteger(amountPaise) || amountPaise <= 0) throw new HttpError(500, "The plan amount is invalid.");

  if (intent.billing_type === "subscription") {
    if (intent.subscription_id) {
      return {
        transaction_id: transactionId,
        subscription_id: intent.subscription_id,
        amount_paise: amountPaise,
        plan_name: intent.plan_name,
        billing_cycles: Number(intent.billing_cycles),
        key_id: keyId
      };
    }
    if (intent.created !== true) {
      throw new HttpError(409, "Subscription checkout is being prepared. Please wait and try again.");
    }
    if (!razorpayPlanId) throw new HttpError(500, "The recurring Razorpay plan is not configured.");
    const service = createServiceClient();
    let razorpayPlan: Record<string, unknown>;
    try {
      const planResponse = await fetch(`https://api.razorpay.com/v1/plans/${encodeURIComponent(razorpayPlanId)}`, {
        headers: { Authorization: razorpayAuth(keyId, keySecret) }
      });
      const planPayload = await planResponse.json().catch(() => ({}));
      if (!planResponse.ok) {
        throw new HttpError(502, "The configured Razorpay subscription plan could not be verified.");
      }
      razorpayPlan = planPayload;
    } catch (error) {
      await service.from("payment_transactions").update({
        status: "failed",
        failure_code: "razorpay_plan_lookup_failed",
        failure_description: "Razorpay subscription plan could not be verified."
      }).eq("id", transactionId).eq("user_id", user.id).eq("status", "pending");
      if (error instanceof HttpError) throw error;
      throw new HttpError(502, "The configured Razorpay subscription plan could not be verified.");
    }
    const planItem = razorpayPlan.item && typeof razorpayPlan.item === "object"
      ? razorpayPlan.item as Record<string, unknown>
      : null;
    if (
      Number(planItem?.amount) !== amountPaise ||
      planItem?.currency !== "INR" ||
      razorpayPlan.period !== "monthly" ||
      Number(razorpayPlan.interval) !== 1
    ) {
      await service.from("payment_transactions").update({
        status: "failed",
        failure_code: "razorpay_plan_mismatch",
        failure_description: "The configured Razorpay Plan does not match the stored monthly plan."
      }).eq("id", transactionId).eq("user_id", user.id).eq("status", "pending");
      throw new HttpError(500, "The configured Razorpay plan does not match ₹499 monthly billing. Contact the site administrator.");
    }
    let subscription: Record<string, unknown>;
    try {
      const response = await fetch("https://api.razorpay.com/v1/subscriptions", {
        method: "POST",
        headers: {
          Authorization: razorpayAuth(keyId, keySecret),
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          plan_id: razorpayPlanId,
          quantity: 1,
          total_count: Number(intent.billing_cycles),
          customer_notify: true,
          notes: {
            transaction_id: transactionId,
            user_id: user.id,
            plan_code: planCode
          }
        })
      });
      const payload = await response.json().catch(() => ({}));
      if (!response.ok) {
        await service.from("payment_transactions").update({
          status: "failed",
          failure_code: "razorpay_subscription_create_failed",
          failure_description: `Razorpay returned HTTP ${response.status}.`
        }).eq("id", transactionId).eq("user_id", user.id).eq("status", "pending");
        throw new HttpError(502, "Razorpay could not create the subscription. You can try again.");
      }
      subscription = payload;
    } catch (error) {
      if (error instanceof HttpError) throw error;
      await service.from("payment_transactions").update({
        status: "failed",
        failure_code: "razorpay_subscription_network_error",
        failure_description: "Razorpay subscription creation did not complete."
      }).eq("id", transactionId).eq("user_id", user.id).eq("status", "pending");
      throw new HttpError(502, "Razorpay could not be reached. You can try again.");
    }

    if (
      typeof subscription.id !== "string" ||
      subscription.plan_id !== razorpayPlanId ||
      Number(subscription.total_count) !== Number(intent.billing_cycles)
    ) {
      if (typeof subscription.id === "string") {
        try {
          const cancelResponse = await fetch(
            `https://api.razorpay.com/v1/subscriptions/${encodeURIComponent(subscription.id)}/cancel`,
            {
              method: "POST",
              headers: {
                Authorization: razorpayAuth(keyId, keySecret),
                "Content-Type": "application/json"
              },
              body: JSON.stringify({ cancel_at_cycle_end: false })
            }
          );
          if (!cancelResponse.ok) console.error("Could not cancel an unexpected Razorpay subscription:", subscription.id);
        } catch (error) {
          console.error("Could not cancel an unexpected Razorpay subscription:", error);
        }
      }
      await service.from("payment_transactions").update({
        status: "failed",
        failure_code: "razorpay_subscription_mismatch",
        failure_description: "Razorpay returned a subscription with unexpected plan details."
      }).eq("id", transactionId).eq("user_id", user.id).eq("status", "pending");
      throw new HttpError(502, "Razorpay returned a subscription with unexpected plan details.");
    }
    const { error: storeError } = await service.rpc("store_razorpay_subscription", {
      p_transaction_id: transactionId,
      p_subscription_id: subscription.id
    });
    if (storeError) {
      try {
        const cancelResponse = await fetch(
          `https://api.razorpay.com/v1/subscriptions/${encodeURIComponent(subscription.id)}/cancel`,
          {
            method: "POST",
            headers: {
              Authorization: razorpayAuth(keyId, keySecret),
              "Content-Type": "application/json"
            },
            body: JSON.stringify({ cancel_at_cycle_end: false })
          }
        );
        if (!cancelResponse.ok) {
          console.error("Could not cancel an unlinked Razorpay subscription:", subscription.id);
        }
      } catch (error) {
        console.error("Could not cancel an unlinked Razorpay subscription:", error);
      }
      await service.from("payment_transactions").update({
        status: "failed",
        failure_code: "subscription_storage_failed",
        failure_description: "Subscription could not be linked to the account."
      }).eq("id", transactionId).eq("user_id", user.id).eq("status", "pending");
      throw new HttpError(500, "The subscription could not be linked to your account. Contact support before retrying.");
    }
    return {
      transaction_id: transactionId,
      subscription_id: subscription.id,
      amount_paise: amountPaise,
      plan_name: intent.plan_name,
      billing_cycles: Number(intent.billing_cycles),
      key_id: keyId
    };
  }
  if (intent.billing_type !== "one_time") throw new HttpError(500, "The plan billing type is invalid.");

  if (intent.order_id) {
    return {
      transaction_id: transactionId,
      order_id: intent.order_id,
      amount_paise: amountPaise,
      plan_name: intent.plan_name,
      key_id: keyId
    };
  }
  if (intent.created !== true) {
    throw new HttpError(409, "Checkout is being prepared. Please wait a moment and try again.");
  }

  const service = createServiceClient();
  let order: Record<string, unknown>;
  try {
    const response = await fetch("https://api.razorpay.com/v1/orders", {
      method: "POST",
      headers: {
        Authorization: razorpayAuth(keyId, keySecret),
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        amount: amountPaise,
        currency: "INR",
        receipt: transactionId,
        notes: { transaction_id: transactionId, user_id: user.id, plan_code: planCode }
      })
    });
    const payload = await response.json().catch(() => ({}));
    if (!response.ok) {
      await service.from("payment_transactions").update({
        status: "failed",
        failure_code: "razorpay_order_create_failed",
        failure_description: `Razorpay returned HTTP ${response.status}.`
      }).eq("id", transactionId).eq("user_id", user.id).eq("status", "pending");
      throw new HttpError(502, "Razorpay could not create the order. You can try again.");
    }
    order = payload;
  } catch (error) {
    if (error instanceof HttpError) throw error;
    await service.from("payment_transactions").update({
      status: "failed",
      failure_code: "razorpay_order_network_error",
      failure_description: "Razorpay order creation did not complete."
    }).eq("id", transactionId).eq("user_id", user.id).eq("status", "pending");
    throw new HttpError(502, "Razorpay could not be reached. You can try again.");
  }

  if (typeof order.id !== "string" || Number(order.amount) !== amountPaise || order.currency !== "INR") {
    await service.from("payment_transactions").update({
      status: "failed",
      failure_code: "razorpay_order_mismatch",
      failure_description: "Razorpay returned an order with unexpected values."
    }).eq("id", transactionId).eq("user_id", user.id).eq("status", "pending");
    throw new HttpError(502, "Razorpay returned an invalid order.");
  }

  const { data: stored, error: storeError } = await service
    .from("payment_transactions")
    .update({ order_id: order.id })
    .eq("id", transactionId)
    .eq("user_id", user.id)
    .eq("status", "pending")
    .is("order_id", null)
    .select("id")
    .maybeSingle();
  if (storeError) throw new HttpError(500, "The payment order could not be saved.");
  if (!stored) {
    const { data: existing, error: existingError } = await service
      .from("payment_transactions")
      .select("order_id")
      .eq("id", transactionId)
      .eq("user_id", user.id)
      .maybeSingle();
    if (existingError || existing?.order_id !== order.id) {
      throw new HttpError(409, "The payment order changed while checkout was starting. Refresh and retry.");
    }
  }

  return {
    transaction_id: transactionId,
    order_id: order.id,
    amount_paise: amountPaise,
    plan_name: intent.plan_name,
    key_id: keyId
  };
}

async function verifyPayment(request: Request, body: Record<string, unknown>, user: { id: string }) {
  const transactionId = requiredString(body.transactionId, "Transaction ID", 64);
  const orderId = requiredString(body.razorpay_order_id, "Razorpay order ID", 128);
  const paymentId = requiredString(body.razorpay_payment_id, "Razorpay payment ID", 128);
  const signature = requiredString(body.razorpay_signature, "Razorpay signature", 128);
  const keyId = readSecret("RAZORPAY_KEY_ID");
  const keySecret = readSecret("RAZORPAY_KEY_SECRET");
  const expectedSignature = await hmacHex(keySecret, `${orderId}|${paymentId}`);
  if (!constantTimeEqual(signature, expectedSignature)) {
    throw new HttpError(400, "Payment signature verification failed.");
  }

  const service = createServiceClient();
  const { data: transaction, error: transactionError } = await service
    .from("payment_transactions")
    .select("id,user_id,amount_paise,order_id,status")
    .eq("id", transactionId)
    .eq("user_id", user.id)
    .maybeSingle();
  if (transactionError || !transaction || transaction.order_id !== orderId) {
    throw new HttpError(404, "The payment order was not found for this account.");
  }

  const response = await fetch(`https://api.razorpay.com/v1/payments/${encodeURIComponent(paymentId)}`, {
    headers: { Authorization: razorpayAuth(keyId, keySecret) }
  });
  const payment = await response.json().catch(() => ({}));
  if (!response.ok) throw new HttpError(502, "Razorpay payment status could not be verified.");
  if (
    payment.order_id !== orderId ||
    Number(payment.amount) !== transaction.amount_paise ||
    payment.currency !== "INR"
  ) {
    throw new HttpError(400, "Payment details do not match the stored order.");
  }

  if (payment.status !== "captured" || payment.captured !== true) {
    if (payment.status === "failed") {
      await service.from("payment_transactions").update({
        status: "failed",
        payment_id: paymentId,
        failure_code: payment.error_code || "payment_failed",
        failure_description: String(payment.error_description || "Razorpay reported a failed payment.").slice(0, 500)
      }).eq("id", transactionId).eq("user_id", user.id).neq("status", "paid");
      return { status: "failed" };
    }
    return { status: "pending" };
  }

  const { data: activation, error: activationError } = await service.rpc("activate_membership_from_payment", {
    p_transaction_id: transactionId,
    p_order_id: orderId,
    p_payment_id: paymentId,
    p_amount_paise: Number(payment.amount),
    p_paid_at: payment.created_at ? new Date(Number(payment.created_at) * 1000).toISOString() : new Date().toISOString()
  });
  if (activationError) throw new HttpError(409, "Payment was verified, but membership activation needs support review.");
  return activation;
}

function isoFromUnix(value: unknown): string | null {
  const seconds = Number(value);
  if (!Number.isSafeInteger(seconds) || seconds <= 0) return null;
  return new Date(seconds * 1000).toISOString();
}

async function verifySubscription(body: Record<string, unknown>, user: { id: string }) {
  const transactionId = requiredString(body.transactionId, "Transaction ID", 64);
  const subscriptionId = requiredString(body.razorpay_subscription_id, "Razorpay subscription ID", 128);
  const paymentId = requiredString(body.razorpay_payment_id, "Razorpay payment ID", 128);
  const signature = requiredString(body.razorpay_signature, "Razorpay signature", 128);
  const keyId = readSecret("RAZORPAY_KEY_ID");
  const keySecret = readSecret("RAZORPAY_KEY_SECRET");
  const expectedSignature = await hmacHex(keySecret, `${paymentId}|${subscriptionId}`);
  if (!constantTimeEqual(signature, expectedSignature)) {
    throw new HttpError(400, "Subscription payment signature verification failed.");
  }

  const service = createServiceClient();
  const { data: transaction, error: transactionError } = await service
    .from("payment_transactions")
    .select("id,user_id,amount_paise,subscription_id,status")
    .eq("id", transactionId)
    .eq("user_id", user.id)
    .maybeSingle();
  if (transactionError || !transaction || transaction.subscription_id !== subscriptionId) {
    throw new HttpError(404, "The subscription was not found for this account.");
  }

  const [paymentResponse, subscriptionResponse] = await Promise.all([
    fetch(`https://api.razorpay.com/v1/payments/${encodeURIComponent(paymentId)}`, {
      headers: { Authorization: razorpayAuth(keyId, keySecret) }
    }),
    fetch(`https://api.razorpay.com/v1/subscriptions/${encodeURIComponent(subscriptionId)}`, {
      headers: { Authorization: razorpayAuth(keyId, keySecret) }
    })
  ]);
  const payment = await paymentResponse.json().catch(() => ({}));
  const subscription = await subscriptionResponse.json().catch(() => ({}));
  if (!paymentResponse.ok || !subscriptionResponse.ok) {
    throw new HttpError(502, "Razorpay subscription payment status could not be verified.");
  }
  const razorpayPlanId = readSecret("RAZORPAY_STANDARD_PLAN_ID");
  if (
    payment.subscription_id !== subscriptionId ||
    Number(payment.amount) !== transaction.amount_paise ||
    payment.currency !== "INR" ||
    subscription.id !== subscriptionId ||
    subscription.plan_id !== razorpayPlanId
  ) {
    throw new HttpError(400, "Subscription payment details do not match the stored plan.");
  }
  if (payment.status !== "captured" || payment.captured !== true) {
    if (payment.status === "failed") {
      const { error } = await service.rpc("record_subscription_failure", {
        p_subscription_id: subscriptionId,
        p_payment_id: paymentId,
        p_invoice_id: typeof payment.invoice_id === "string" ? payment.invoice_id : null,
        p_amount_paise: Number(payment.amount),
        p_failure_code: String(payment.error_code || "payment_failed"),
        p_failure_description: String(payment.error_description || "Razorpay reported a failed payment.")
      });
      if (error) throw new HttpError(409, "The failed subscription payment could not be recorded.");
      return { status: "failed" };
    }
    return { status: "pending" };
  }

  const currentStart = isoFromUnix(subscription.current_start);
  const currentEnd = isoFromUnix(subscription.current_end);
  if (!currentStart || !currentEnd) return { status: "pending" };
  const { data: activation, error: activationError } = await service.rpc("record_subscription_charge", {
    p_subscription_id: subscriptionId,
    p_payment_id: paymentId,
    p_invoice_id: typeof payment.invoice_id === "string" ? payment.invoice_id : null,
    p_amount_paise: Number(payment.amount),
    p_paid_at: isoFromUnix(payment.created_at),
    p_current_start: currentStart,
    p_current_end: currentEnd,
    p_subscription_status: subscription.status === "completed" ? "completed" : "active"
  });
  if (activationError) throw new HttpError(409, "Payment was verified, but membership activation needs support review.");
  return activation;
}

async function cancelSubscription(body: Record<string, unknown>, user: { id: string }) {
  const subscriptionId = requiredString(body.subscriptionId, "Subscription ID", 128);
  const service = createServiceClient();
  const { data: subscription, error: lookupError } = await service
    .from("user_subscriptions")
    .select("id,user_id,razorpay_subscription_id,status,current_period_start,current_period_end,cancel_at_cycle_end")
    .eq("razorpay_subscription_id", subscriptionId)
    .eq("user_id", user.id)
    .maybeSingle();
  if (lookupError) throw new HttpError(500, "Subscription status could not be loaded.");
  if (!subscription) throw new HttpError(404, "The subscription was not found for this account.");
  if (["cancelled", "completed", "expired"].includes(subscription.status)) {
    return {
      status: subscription.status,
      cancel_at_cycle_end: subscription.cancel_at_cycle_end,
      current_period_end: subscription.current_period_end
    };
  }
  if (subscription.cancel_at_cycle_end) {
    return {
      status: subscription.status,
      cancel_at_cycle_end: true,
      current_period_end: subscription.current_period_end
    };
  }

  const periodEnd = subscription.current_period_end ? new Date(subscription.current_period_end).getTime() : 0;
  const cancelAtCycleEnd = Number.isFinite(periodEnd) && periodEnd > Date.now()
    && ["active", "pending", "halted", "paused"].includes(subscription.status);
  const keyId = readSecret("RAZORPAY_KEY_ID");
  const keySecret = readSecret("RAZORPAY_KEY_SECRET");
  const response = await fetch(
    `https://api.razorpay.com/v1/subscriptions/${encodeURIComponent(subscriptionId)}/cancel`,
    {
      method: "POST",
      headers: {
        Authorization: razorpayAuth(keyId, keySecret),
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ cancel_at_cycle_end: cancelAtCycleEnd })
    }
  );
  const result = await response.json().catch(() => ({}));
  if (!response.ok || typeof result.status !== "string") {
    throw new HttpError(502, "Razorpay could not cancel the subscription. Please try again.");
  }
  const { error: statusError } = await service.rpc("record_subscription_status", {
    p_subscription_id: subscriptionId,
    p_status: result.status,
    p_current_start: isoFromUnix(result.current_start),
    p_current_end: isoFromUnix(result.current_end)
  });
  if (statusError) throw new HttpError(500, "Razorpay cancelled the subscription, but the local status needs support review.");
  const { error: cancellationError } = await service.from("user_subscriptions")
    .update({
      cancel_at_cycle_end: cancelAtCycleEnd,
      cancel_requested_at: new Date().toISOString()
    })
    .eq("id", subscription.id)
    .eq("user_id", user.id);
  if (cancellationError) throw new HttpError(500, "Razorpay cancelled the subscription, but the cancellation record could not be saved.");
  const { error: pendingTransactionError } = await service.from("payment_transactions")
    .update({ status: "cancelled", failure_description: "Subscription was cancelled before its first payment." })
    .eq("subscription_id", subscriptionId)
    .eq("status", "pending");
  if (pendingTransactionError) throw new HttpError(500, "Subscription was cancelled, but its pending checkout could not be closed.");
  return {
    status: result.status,
    cancel_at_cycle_end: cancelAtCycleEnd,
    current_period_end: isoFromUnix(result.current_end) || subscription.current_period_end
  };
}

async function updatePendingStatus(request: Request, body: Record<string, unknown>, user: { id: string }, status: "failed" | "cancelled") {
  const transactionId = requiredString(body.transactionId, "Transaction ID", 64);
  const service = createServiceClient();
  const update = status === "failed"
    ? {
      status,
      failure_code: String(body.failureCode || "checkout_failed").slice(0, 100),
      failure_description: String(body.failureDescription || "Checkout did not complete.").slice(0, 500)
    }
    : { status, failure_description: "Checkout was dismissed by the user." };
  const { data, error } = await service
    .from("payment_transactions")
    .update(update)
    .eq("id", transactionId)
    .eq("user_id", user.id)
    .eq("status", "pending")
    .select("status")
    .maybeSingle();
  if (error) throw new HttpError(500, "The payment status could not be updated.");
  if (data) return { status: data.status };
  const { data: current, error: currentError } = await service
    .from("payment_transactions")
    .select("status")
    .eq("id", transactionId)
    .eq("user_id", user.id)
    .maybeSingle();
  if (currentError || !current) throw new HttpError(404, "The payment transaction was not found.");
  return { status: current.status };
}

Deno.serve(async request => {
  if (request.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: (await import("../_shared/http.ts")).corsHeaders(request) });
  }
  if (request.method !== "POST") return jsonResponse(request, { error: "Method not allowed." }, 405);
  try {
    checkOrigin(request);
    const { user } = await authenticatedRequest(request);
    const body = await readJson(request);
    const action = requiredString(body.action, "Action", 40);
    if (action === "create-order") return jsonResponse(request, await createOrder(request, body, user));
    if (action === "verify-payment") return jsonResponse(request, await verifyPayment(request, body, user));
    if (action === "verify-subscription") return jsonResponse(request, await verifySubscription(body, user));
    if (action === "cancel-subscription") return jsonResponse(request, await cancelSubscription(body, user));
    if (action === "cancel-order") return jsonResponse(request, await updatePendingStatus(request, body, user, "cancelled"));
    if (action === "payment-failed") return jsonResponse(request, await updatePendingStatus(request, body, user, "failed"));
    throw new HttpError(400, "Unsupported payment action.");
  } catch (error) {
    return handleError(request, error);
  }
});
