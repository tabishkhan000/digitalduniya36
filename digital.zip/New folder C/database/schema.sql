-- DigitalDuniya360 Supabase schema
-- Run in Supabase SQL Editor. Never put a service-role key in the website.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  avatar_url text,
  bio text,
  city text,
  state text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.user_roles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  role text not null check (role in ('admin','moderator','user')),
  created_at timestamptz not null default now(),
  unique(user_id, role)
);

create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path = public
as $$
  select exists (
    select 1 from public.user_roles
    where user_id = auth.uid() and role = 'admin'
  );
$$;

create or replace function public.can_moderate()
returns boolean language sql stable security definer set search_path = public
as $$
  select exists (
    select 1 from public.user_roles
    where user_id = auth.uid() and role in ('admin','moderator')
  );
$$;

create or replace function public.set_updated_at()
returns trigger language plpgsql
as $$ begin new.updated_at = now(); return new; end; $$;

create table if not exists public.categories (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug text not null unique,
  section text not null,
  description text,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(section, name)
);

create table if not exists public.blog_posts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  title text not null,
  slug text not null unique,
  category text not null,
  summary text not null default '',
  content text not null,
  website_url text,
  featured_image text,
  seo_title text,
  meta_description text,
  tags text[] not null default '{}',
  status text not null default 'pending' check(status in ('pending','published','rejected','archived')),
  published_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.blog_posts add column if not exists website_url text;
do $$
begin
  if not exists (
    select 1 from pg_constraint
    where conname = 'blog_posts_website_url_format'
      and conrelid = 'public.blog_posts'::regclass
  ) then
    alter table public.blog_posts
      add constraint blog_posts_website_url_format
      check (website_url is null or website_url ~* '^https?://[^[:space:]]+$') not valid;
  end if;
end $$;

create table if not exists public.blog_comments (
  id uuid primary key default gen_random_uuid(),
  post_id uuid not null references public.blog_posts(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  body text not null check(length(body) between 2 and 5000),
  status text not null default 'pending' check(status in ('pending','approved','rejected')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.news_articles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.profiles(id) on delete set null,
  title text not null,
  slug text not null unique,
  category text not null,
  summary text not null default '',
  content text not null,
  image_url text,
  source_name text,
  source_url text,
  verified boolean not null default false,
  status text not null default 'pending' check(status in ('pending','published','rejected','archived')),
  published_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.classified_ads (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.profiles(id) on delete set null,
  title text not null,
  slug text unique,
  category text not null,
  description text not null,
  price numeric(12,2) check(price is null or price >= 0),
  city text not null,
  state text not null,
  seller_name text not null,
  phone text not null,
  whatsapp text,
  website_url text,
  featured boolean not null default false,
  expires_at timestamptz,
  status text not null default 'published' check(status in ('published','expired','archived')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.classified_ads alter column user_id drop not null;
alter table public.classified_ads alter column status set default 'published';
alter table public.classified_ads add column if not exists website_url text;
alter table public.classified_ads drop constraint if exists classified_ads_status_check;
alter table public.classified_ads add constraint classified_ads_status_check
  check(status in ('pending','published','rejected','expired','archived'));
alter table public.classified_ads drop constraint if exists classified_ads_website_url_format;
alter table public.classified_ads add constraint classified_ads_website_url_format
  check(website_url is null or website_url ~* '^https?://[^[:space:]]+$');

create table if not exists public.ad_images (
  id uuid primary key default gen_random_uuid(),
  ad_id uuid not null references public.classified_ads(id) on delete cascade,
  user_id uuid references public.profiles(id) on delete set null,
  image_url text not null,
  position integer not null default 0,
  created_at timestamptz not null default now()
);

create table if not exists public.deals (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete set null,
  title text not null,
  slug text not null unique,
  offer_type text not null default 'product',
  category text not null,
  description text not null default '',
  image_url text,
  merchant text,
  coupon_code text,
  original_price numeric(12,2) check(original_price is null or original_price >= 0),
  sale_price numeric(12,2) check(sale_price is null or sale_price >= 0),
  discount_percentage numeric(5,2) check(discount_percentage is null or (discount_percentage between 0 and 100)),
  affiliate_url text not null,
  expires_at timestamptz,
  status text not null default 'pending' check(status in ('pending','published','rejected','expired','archived')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.deals add column if not exists user_id uuid references auth.users(id) on delete set null;
alter table public.deals add column if not exists offer_type text not null default 'product';
alter table public.deals add column if not exists merchant text;
alter table public.deals add column if not exists coupon_code text;
do $$
begin
  if not exists (
    select 1 from pg_constraint
    where conname = 'deals_offer_type_check' and conrelid = 'public.deals'::regclass
  ) then
    alter table public.deals add constraint deals_offer_type_check
      check (offer_type in ('product','coupon'));
  end if;
end $$;

create table if not exists public.coupons (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  slug text not null unique,
  category text not null,
  description text not null default '',
  merchant text,
  coupon_code text,
  affiliate_url text not null,
  expires_at timestamptz,
  status text not null default 'pending' check(status in ('pending','published','rejected','expired','archived')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.affiliate_clicks (
  id uuid primary key default gen_random_uuid(),
  deal_id uuid references public.deals(id) on delete cascade,
  coupon_id uuid references public.coupons(id) on delete cascade,
  clicked_at timestamptz not null default now(),
  check ((deal_id is null) <> (coupon_id is null))
);

create table if not exists public.businesses (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  name text not null,
  slug text unique,
  category text not null,
  city text not null,
  state text,
  description text not null,
  website text,
  phone text,
  whatsapp text,
  address text,
  logo_url text,
  cover_image text,
  listing_type text not null default 'free' check(listing_type in ('free','featured')),
  services text[] not null default '{}',
  social_links jsonb not null default '{}'::jsonb,
  status text not null default 'pending' check(status in ('pending','published','rejected','suspended')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.business_images (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  image_url text not null,
  created_at timestamptz not null default now()
);

create table if not exists public.business_reviews (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  rating smallint not null check(rating between 1 and 5),
  body text not null check(length(body) between 2 and 3000),
  status text not null default 'pending' check(status in ('pending','approved','rejected')),
  created_at timestamptz not null default now(),
  unique(business_id,user_id)
);

create table if not exists public.jobs (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  title text not null,
  slug text unique,
  company_name text not null,
  category text not null,
  city text not null,
  work_type text not null check(work_type in ('Full-time','Part-time','Internship','Work from home')),
  salary text,
  experience text,
  description text not null,
  skills text[] not null default '{}',
  apply_url text not null,
  deadline date,
  status text not null default 'pending' check(status in ('pending','published','rejected','expired','archived')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.job_applications (
  id uuid primary key default gen_random_uuid(),
  job_id uuid not null references public.jobs(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  resume_url text,
  cover_note text,
  status text not null default 'submitted' check(status in ('submitted','reviewed','withdrawn')),
  created_at timestamptz not null default now(),
  unique(job_id,user_id)
);

create table if not exists public.community_questions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  title text not null,
  slug text unique,
  category text not null,
  description text not null,
  status text not null default 'pending' check(status in ('pending','published','rejected','closed')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.community_answers (
  id uuid primary key default gen_random_uuid(),
  question_id uuid not null references public.community_questions(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  body text not null check(length(body) between 2 and 10000),
  status text not null default 'pending' check(status in ('pending','published','rejected')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.votes (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  question_id uuid references public.community_questions(id) on delete cascade,
  answer_id uuid references public.community_answers(id) on delete cascade,
  value smallint not null check(value in (-1,1)),
  created_at timestamptz not null default now(),
  check ((question_id is null) <> (answer_id is null)),
  unique(user_id,question_id),
  unique(user_id,answer_id)
);

create table if not exists public.saved_items (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  item_type text not null check(item_type in ('blog','news','ad','deal','coupon','business','job','question')),
  item_id uuid not null,
  created_at timestamptz not null default now(),
  unique(user_id,item_type,item_id)
);

create table if not exists public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  title text not null,
  body text not null default '',
  read_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.quizzes (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text not null default '',
  category text not null,
  status text not null default 'draft' check(status in ('draft','published','archived')),
  published_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.quiz_questions (
  id uuid primary key default gen_random_uuid(),
  quiz_id uuid not null references public.quizzes(id) on delete cascade,
  question text not null,
  options jsonb not null,
  correct_option integer not null check(correct_option >= 0),
  position integer not null default 0,
  created_at timestamptz not null default now()
);

create table if not exists public.quiz_attempts (
  id uuid primary key default gen_random_uuid(),
  quiz_id uuid not null references public.quizzes(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  score integer not null default 0,
  answers jsonb not null default '[]'::jsonb,
  completed_at timestamptz not null default now(),
  unique(quiz_id,user_id)
);

create table if not exists public.polls (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text not null default '',
  status text not null default 'draft' check(status in ('draft','published','closed')),
  ends_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.poll_options (
  id uuid primary key default gen_random_uuid(),
  poll_id uuid not null references public.polls(id) on delete cascade,
  label text not null,
  position integer not null default 0,
  created_at timestamptz not null default now(),
  unique(poll_id,position)
);

create table if not exists public.poll_votes (
  id uuid primary key default gen_random_uuid(),
  poll_id uuid not null references public.polls(id) on delete cascade,
  option_id uuid not null references public.poll_options(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  unique(poll_id,user_id)
);

create table if not exists public.user_points (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  activity_key text not null,
  points integer not null check(points > 0),
  created_at timestamptz not null default now(),
  unique(user_id,activity_key)
);

create table if not exists public.user_badges (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  badge_key text not null,
  awarded_at timestamptz not null default now(),
  unique(user_id,badge_key)
);

create table if not exists public.newsletter_subscribers (
  id uuid primary key default gen_random_uuid(),
  email text not null unique check(email = lower(email)),
  confirmed_at timestamptz,
  unsubscribed_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.reports (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references public.profiles(id) on delete set null,
  target_type text not null,
  target_id uuid not null,
  reason text not null,
  details text,
  status text not null default 'open' check(status in ('open','reviewing','resolved','dismissed')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.advertisements (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  image_url text,
  target_url text not null,
  placement text not null,
  starts_at timestamptz,
  ends_at timestamptz,
  status text not null default 'pending' check(status in ('pending','published','paused','expired')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.payments (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  provider_reference text unique,
  amount numeric(12,2) not null check(amount >= 0),
  currency text not null default 'INR',
  purpose text not null,
  status text not null default 'pending' check(status in ('pending','paid','failed','refunded')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- Search and browse indexes
create index if not exists blog_posts_public_idx on public.blog_posts(status,published_at desc);
create index if not exists blog_posts_category_idx on public.blog_posts(category,status);
create index if not exists news_articles_public_idx on public.news_articles(status,published_at desc);
create index if not exists classified_ads_browse_idx on public.classified_ads(status,category,city,created_at desc);
create index if not exists deals_browse_idx on public.deals(status,category,expires_at);
create index if not exists coupons_browse_idx on public.coupons(status,category,expires_at);
create index if not exists businesses_browse_idx on public.businesses(status,category,city);
create index if not exists jobs_browse_idx on public.jobs(status,category,city,created_at desc);
create index if not exists questions_browse_idx on public.community_questions(status,category,created_at desc);
create index if not exists answers_question_idx on public.community_answers(question_id,status,created_at);
create index if not exists comments_post_idx on public.blog_comments(post_id,status,created_at);
create index if not exists notifications_user_idx on public.notifications(user_id,created_at desc);
create index if not exists reports_status_idx on public.reports(status,created_at);
create index if not exists profiles_name_idx on public.profiles using gin(to_tsvector('simple',full_name));

-- Enable RLS on all application tables.
do $$
declare t text;
begin
  foreach t in array array[
    'profiles','user_roles','categories','blog_posts','blog_comments','news_articles',
    'classified_ads','ad_images','deals','coupons','affiliate_clicks','businesses',
    'business_images','business_reviews','jobs','job_applications','community_questions',
    'community_answers','votes','saved_items','notifications','quizzes','quiz_questions',
    'quiz_attempts','polls','poll_options','poll_votes','user_points','user_badges',
    'newsletter_subscribers','reports','advertisements','payments'
  ] loop
    execute format('alter table public.%I enable row level security',t);
  end loop;
end $$;

-- Role check is security-definer and has a fixed search_path to avoid policy recursion.
drop policy if exists "roles_admin_only" on public.user_roles;
create policy "roles_admin_only" on public.user_roles for all
  using (public.is_admin()) with check (public.is_admin());

drop policy if exists "profiles_read_public" on public.profiles;
create policy "profiles_read_public" on public.profiles for select using (id = auth.uid() or public.is_admin());
drop policy if exists "profiles_insert_self" on public.profiles;
create policy "profiles_insert_self" on public.profiles for insert with check (id = auth.uid());
drop policy if exists "profiles_update_self_or_admin" on public.profiles;
create policy "profiles_update_self_or_admin" on public.profiles for update
  using (id = auth.uid() or public.is_admin()) with check (id = auth.uid() or public.is_admin());

drop policy if exists "categories_read_active" on public.categories;
create policy "categories_read_active" on public.categories for select using (is_active or public.is_admin());
drop policy if exists "categories_admin_all" on public.categories;
create policy "categories_admin_all" on public.categories for all
  using (public.is_admin()) with check (public.is_admin());

-- Public published content; submitters can only see their own rows. Own edits remain pending.
do $$
declare t text;
begin
  foreach t in array array['blog_posts','businesses','jobs','community_questions'] loop
    execute format('drop policy if exists "public_published" on public.%I',t);
    execute format('drop policy if exists "owner_insert" on public.%I',t);
    execute format('drop policy if exists "owner_update_pending" on public.%I',t);
    execute format('drop policy if exists "owner_delete" on public.%I',t);
    execute format('create policy "public_published" on public.%I for select using (status = ''published'' or user_id = auth.uid() or public.can_moderate())',t);
    execute format('create policy "owner_insert" on public.%I for insert with check (user_id = auth.uid() and status = ''pending'')',t);
    execute format('create policy "owner_update_pending" on public.%I for update using ((user_id = auth.uid() and status = ''pending'') or public.can_moderate()) with check ((user_id = auth.uid() and status = ''pending'') or public.can_moderate())',t);
    execute format('create policy "owner_delete" on public.%I for delete using (user_id = auth.uid() or public.can_moderate())',t);
  end loop;
end $$;

do $$
declare existing_policy record;
begin
  for existing_policy in
    select policyname from pg_policies
    where schemaname = 'public' and tablename = 'classified_ads'
  loop
    execute format('drop policy %I on public.classified_ads', existing_policy.policyname);
  end loop;
end $$;

drop policy if exists "public_published" on public.classified_ads;
create policy "public_published" on public.classified_ads for select to anon, authenticated
  using (status = 'published' or user_id = auth.uid() or public.can_moderate());
drop policy if exists "owner_delete" on public.classified_ads;
drop policy if exists "classified_ads_admin_delete" on public.classified_ads;
create policy "classified_ads_admin_delete" on public.classified_ads for delete to authenticated
  using (public.is_admin());
drop policy if exists "owner_insert" on public.classified_ads;
create policy "owner_insert" on public.classified_ads for insert to anon, authenticated with check (
  status = 'published' and featured = false and (user_id is null or user_id = auth.uid())
);
drop policy if exists "owner_update_pending" on public.classified_ads;
drop policy if exists "ad_owner_renew_or_moderator_update" on public.classified_ads;
drop policy if exists "classified_ads_admin_update" on public.classified_ads;
create policy "classified_ads_admin_update" on public.classified_ads for update to authenticated
  using (public.is_admin())
  with check (public.is_admin());

revoke all on public.classified_ads from public, anon, authenticated;
grant select, insert on public.classified_ads to anon, authenticated;
grant update, delete on public.classified_ads to authenticated;

drop policy if exists "owner_insert" on public.businesses;
create policy "owner_insert" on public.businesses for insert with check (
  user_id = auth.uid() and status = 'pending' and listing_type = 'free'
);
drop policy if exists "owner_update_pending" on public.businesses;
create policy "owner_update_pending" on public.businesses for update
  using ((user_id = auth.uid() and status = 'pending') or public.can_moderate())
  with check ((user_id = auth.uid() and status = 'pending' and listing_type = 'free') or public.can_moderate());

drop policy if exists "news_public_published" on public.news_articles;
create policy "news_public_published" on public.news_articles for select using (status='published' and verified or public.can_moderate());
drop policy if exists "news_admin_all" on public.news_articles;
create policy "news_admin_all" on public.news_articles for all using (public.can_moderate()) with check (public.can_moderate());

do $$
declare t text;
begin
  foreach t in array array['deals','coupons','advertisements','quizzes','quiz_questions','polls','poll_options'] loop
    if t in ('deals','coupons','advertisements','quizzes','polls') then
      execute format('drop policy if exists "public_published" on public.%I',t);
      execute format('drop policy if exists "admin_manage" on public.%I',t);
      execute format('create policy "public_published" on public.%I for select using (status = ''published'' or public.can_moderate())',t);
      execute format('create policy "admin_manage" on public.%I for all using (public.can_moderate()) with check (public.can_moderate())',t);
    elsif t = 'quiz_questions' then
      execute format('drop policy if exists "parent_published_read" on public.%I',t);
      execute format('drop policy if exists "admin_manage" on public.%I',t);
      execute format('create policy "admin_manage" on public.%I for all using (public.can_moderate()) with check (public.can_moderate())',t);
    else
      execute format('drop policy if exists "parent_published_read" on public.%I',t);
      execute format('drop policy if exists "admin_manage" on public.%I',t);
      execute format('create policy "parent_published_read" on public.%I for select using (exists(select 1 from public.polls p where p.id=poll_id and p.status=''published'') or public.can_moderate())',t);
      execute format('create policy "admin_manage" on public.%I for all using (public.can_moderate()) with check (public.can_moderate())',t);
    end if;
  end loop;
end $$;

-- User-owned child and account data.
do $$
declare t text;
begin
  foreach t in array array['blog_comments','business_reviews','job_applications','community_answers',
    'votes','saved_items','notifications','quiz_attempts','poll_votes','user_points',
    'user_badges','payments','reports'] loop
    execute format('drop policy if exists "owner_read" on public.%I',t);
    execute format('drop policy if exists "owner_insert" on public.%I',t);
    execute format('drop policy if exists "owner_update" on public.%I',t);
    execute format('drop policy if exists "owner_delete" on public.%I',t);
    execute format('create policy "owner_read" on public.%I for select using (user_id = auth.uid() or public.can_moderate())',t);
    if t in ('blog_comments','business_reviews','job_applications','community_answers','votes','saved_items','poll_votes','reports') then
      execute format('create policy "owner_insert" on public.%I for insert with check (user_id = auth.uid())',t);
    end if;
    if t in ('blog_comments','business_reviews','community_answers','saved_items','notifications','reports') then
      execute format('create policy "owner_delete" on public.%I for delete using (user_id = auth.uid() or public.can_moderate())',t);
    end if;
  end loop;
end $$;

drop policy if exists "community_offer_insert" on public.deals;
create policy "community_offer_insert" on public.deals for insert to authenticated with check (
  user_id = auth.uid()
  and status = 'published'
  and (
    (merchant = 'Amazon' and affiliate_url ~* '^https://([a-z0-9-]+\.)*(amazon\.in|amazon\.com|amzn\.to)(:[0-9]+)?(/|[?#]|$)')
    or (merchant = 'Flipkart' and affiliate_url ~* '^https://([a-z0-9-]+\.)*(flipkart\.com|fkrt\.it)(:[0-9]+)?(/|[?#]|$)')
    or (merchant = 'Meesho' and affiliate_url ~* '^https://([a-z0-9-]+\.)*meesho\.com(:[0-9]+)?(/|[?#]|$)')
    or (merchant = 'Website' and affiliate_url ~* '^https://([a-z0-9-]+\.)*[a-z0-9-]+\.[a-z]{2,}(:[0-9]+)?(/|[?#]|$)')
  )
  and (image_url is null or image_url ~* '^https://[^[:space:]]+$')
);

do $$
declare t text;
begin
  foreach t in array array['blog_comments','business_reviews','job_applications','community_answers',
    'votes','saved_items','notifications','quiz_attempts','poll_votes','user_points',
    'user_badges','payments','reports'] loop
    execute format('drop policy if exists "admin_manage" on public.%I',t);
    execute format('create policy "admin_manage" on public.%I for all using (public.can_moderate()) with check (public.can_moderate())',t);
  end loop;
end $$;

drop policy if exists "approved_comments_read" on public.blog_comments;
create policy "approved_comments_read" on public.blog_comments for select using (status='approved' or user_id=auth.uid() or public.can_moderate());
drop policy if exists "approved_reviews_read" on public.business_reviews;
create policy "approved_reviews_read" on public.business_reviews for select using (status='approved' or user_id=auth.uid() or public.can_moderate());
drop policy if exists "published_answers_read" on public.community_answers;
create policy "published_answers_read" on public.community_answers for select using (status='published' or user_id=auth.uid() or public.can_moderate());
drop policy if exists "owner_insert" on public.blog_comments;
create policy "owner_insert" on public.blog_comments for insert with check (
  user_id=auth.uid() and status='pending'
  and exists(select 1 from public.blog_posts p where p.id=post_id and p.status='published')
);
drop policy if exists "owner_insert" on public.business_reviews;
create policy "owner_insert" on public.business_reviews for insert with check (
  user_id=auth.uid() and status='pending'
  and exists(select 1 from public.businesses b where b.id=business_id and b.status='published')
);
drop policy if exists "owner_insert" on public.community_answers;
create policy "owner_insert" on public.community_answers for insert with check (
  user_id=auth.uid() and status='pending'
  and exists(select 1 from public.community_questions q where q.id=question_id and q.status='published')
);
drop policy if exists "owner_insert" on public.poll_votes;
create policy "owner_insert" on public.poll_votes for insert with check (
  user_id=auth.uid() and exists(
    select 1 from public.poll_options o join public.polls p on p.id=o.poll_id
    where o.id=poll_votes.option_id and p.id=poll_votes.poll_id and p.status='published' and (p.ends_at is null or p.ends_at>now())
  )
);
drop policy if exists "owner_insert" on public.votes;
create policy "owner_insert" on public.votes for insert with check (
  user_id=auth.uid() and (
    (question_id is not null and exists(select 1 from public.community_questions q where q.id=question_id and q.status='published'))
    or (answer_id is not null and exists(select 1 from public.community_answers a where a.id=answer_id and a.status='published'))
  )
);
drop policy if exists "owner_insert" on public.reports;
create policy "owner_insert" on public.reports for insert with check (user_id=auth.uid() and status='open');
drop policy if exists "owner_insert" on public.job_applications;
create policy "owner_insert" on public.job_applications for insert with check (user_id=auth.uid() and status='submitted');
drop policy if exists "owner_read" on public.user_points;
create policy "owner_read" on public.user_points for select using (user_id=auth.uid() or public.can_moderate());
drop policy if exists "owner_read" on public.user_badges;
create policy "owner_read" on public.user_badges for select using (user_id=auth.uid() or public.can_moderate());
drop policy if exists "owner_read" on public.quiz_attempts;
create policy "owner_read" on public.quiz_attempts for select using (user_id=auth.uid() or public.can_moderate());
drop policy if exists "owner_read" on public.payments;
create policy "owner_read" on public.payments for select using (user_id=auth.uid() or public.can_moderate());

drop policy if exists "images_public_read" on public.ad_images;
create policy "images_public_read" on public.ad_images for select using (
  exists(select 1 from public.classified_ads a where a.id=ad_id and a.status='published')
  or user_id=auth.uid() or public.can_moderate()
);
drop policy if exists "images_owner_insert" on public.ad_images;
create policy "images_owner_insert" on public.ad_images for insert with check (
  (user_id is null and exists(select 1 from public.classified_ads a where a.id=ad_id and a.status='published'))
  or (user_id=auth.uid() and exists(select 1 from public.classified_ads a where a.id=ad_id and a.user_id=auth.uid() and a.status='published'))
);
drop policy if exists "images_owner_delete" on public.ad_images;
drop policy if exists "images_admin_delete" on public.ad_images;
create policy "images_admin_delete" on public.ad_images for delete to authenticated using (public.is_admin());
grant select, insert on public.ad_images to anon, authenticated;
grant delete on public.ad_images to authenticated;

drop policy if exists "business_images_public_read" on public.business_images;
create policy "business_images_public_read" on public.business_images for select using (
  exists(select 1 from public.businesses b where b.id=business_id and b.status='published')
  or user_id=auth.uid() or public.can_moderate()
);
drop policy if exists "business_images_owner_insert" on public.business_images;
create policy "business_images_owner_insert" on public.business_images for insert with check (
  user_id=auth.uid() and exists(select 1 from public.businesses b where b.id=business_id and b.user_id=auth.uid())
);
drop policy if exists "business_images_owner_delete" on public.business_images;
create policy "business_images_owner_delete" on public.business_images for delete using (user_id=auth.uid() or public.can_moderate());

drop policy if exists "affiliate_click_insert" on public.affiliate_clicks;
create policy "affiliate_click_insert" on public.affiliate_clicks for insert with check (
  (deal_id is not null and exists(select 1 from public.deals where id=deal_id and status='published'))
  or (coupon_id is not null and exists(select 1 from public.coupons where id=coupon_id and status='published'))
);
drop policy if exists "affiliate_click_admin_read" on public.affiliate_clicks;
create policy "affiliate_click_admin_read" on public.affiliate_clicks for select using (public.is_admin());

drop policy if exists "newsletter_subscribe" on public.newsletter_subscribers;
create policy "newsletter_subscribe" on public.newsletter_subscribers for insert with check (true);
drop policy if exists "newsletter_admin_read" on public.newsletter_subscribers;
create policy "newsletter_admin_read" on public.newsletter_subscribers for select using (public.is_admin());
drop policy if exists "newsletter_admin_update" on public.newsletter_subscribers;
create policy "newsletter_admin_update" on public.newsletter_subscribers for update using (public.is_admin()) with check (public.is_admin());

-- Storage setup: public image reads; ad photos also accept anonymous uploads.
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
values
  ('blog-images','blog-images',true,5242880,array['image/jpeg','image/png','image/webp']),
  ('deal-images','deal-images',true,5242880,array['image/jpeg','image/png','image/webp']),
  ('classified-images','classified-images',true,5242880,array['image/jpeg','image/png','image/webp']),
  ('business-images','business-images',true,5242880,array['image/jpeg','image/png','image/webp']),
  ('user-avatars','user-avatars',true,5242880,array['image/jpeg','image/png','image/webp']),
  ('news-images','news-images',true,5242880,array['image/jpeg','image/png','image/webp'])
on conflict(id) do update set public=excluded.public,file_size_limit=excluded.file_size_limit,allowed_mime_types=excluded.allowed_mime_types;

drop policy if exists "public_read_site_images" on storage.objects;
create policy "public_read_site_images" on storage.objects for select using (
  bucket_id in ('blog-images','classified-images','business-images','user-avatars','news-images')
);
drop policy if exists "users_upload_own_images" on storage.objects;
create policy "users_upload_own_images" on storage.objects for insert to authenticated with check (
  bucket_id in ('blog-images','classified-images','business-images','user-avatars','news-images')
  and (storage.foldername(name))[1] = auth.uid()::text
);
drop policy if exists "public_upload_classified_images" on storage.objects;
create policy "public_upload_classified_images" on storage.objects for insert to anon, authenticated with check (
  bucket_id = 'classified-images'
  and (storage.foldername(name))[1] = 'ads'
  and exists(
    select 1 from public.classified_ads a
    where a.id::text = (storage.foldername(name))[2] and a.status = 'published'
  )
);
drop policy if exists "moderators_delete_classified_images" on storage.objects;
drop policy if exists "admins_delete_classified_images" on storage.objects;
create policy "admins_delete_classified_images" on storage.objects for delete to authenticated using (
  bucket_id = 'classified-images' and public.is_admin()
);
drop policy if exists "moderators_delete_deal_images" on storage.objects;
create policy "moderators_delete_deal_images" on storage.objects for delete to authenticated using (
  bucket_id = 'deal-images' and public.can_moderate()
);
drop policy if exists "deal_images_public_read" on storage.objects;
create policy "deal_images_public_read" on storage.objects for select to anon, authenticated using (
  bucket_id = 'deal-images'
);
drop policy if exists "deal_images_owner_upload" on storage.objects;
create policy "deal_images_owner_upload" on storage.objects for insert to authenticated with check (
  bucket_id = 'deal-images'
  and (storage.foldername(name))[1] = auth.uid()::text
);
drop policy if exists "deal_images_owner_delete" on storage.objects;
create policy "deal_images_owner_delete" on storage.objects for delete to authenticated using (
  bucket_id = 'deal-images'
  and (storage.foldername(name))[1] = auth.uid()::text
);
drop policy if exists "users_update_own_images" on storage.objects;
create policy "users_update_own_images" on storage.objects for update to authenticated using (
  bucket_id in ('blog-images','classified-images','business-images','user-avatars','news-images')
  and (storage.foldername(name))[1] = auth.uid()::text
) with check (
  bucket_id in ('blog-images','classified-images','business-images','user-avatars','news-images')
  and (storage.foldername(name))[1] = auth.uid()::text
);
drop policy if exists "users_delete_own_images" on storage.objects;
create policy "users_delete_own_images" on storage.objects for delete to authenticated using (
  bucket_id in ('blog-images','classified-images','business-images','user-avatars','news-images')
  and (storage.foldername(name))[1] = auth.uid()::text
);

-- Optional profile bootstrap for newly registered accounts.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public
as $$
begin
  insert into public.profiles(id,full_name) values(new.id,coalesce(new.raw_user_meta_data->>'full_name',''));
  insert into public.user_roles(user_id,role) values(new.id,'user');
  return new;
end;
$$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();

insert into public.profiles(id,full_name)
select u.id,coalesce(u.raw_user_meta_data->>'full_name','')
from auth.users u
on conflict(id) do nothing;
insert into public.user_roles(user_id,role)
select u.id,'user' from auth.users u
on conflict(user_id,role) do nothing;

-- API grants are broad enough for PostgREST operations; RLS above remains mandatory.
grant usage on schema public to anon, authenticated;
grant select, insert, update, delete on all tables in schema public to anon, authenticated;
revoke update, delete on table public.classified_ads from public, anon;
grant update, delete on table public.classified_ads to authenticated;
grant execute on function public.is_admin() to anon, authenticated;
grant execute on function public.can_moderate() to anon, authenticated;

-- updated_at maintenance for frequently edited records
do $$
declare t text;
begin
  foreach t in array array['profiles','categories','blog_posts','blog_comments','news_articles','classified_ads',
    'deals','coupons','businesses','business_reviews','jobs','community_questions','community_answers',
    'quizzes','polls','reports','advertisements','payments'] loop
    execute format('drop trigger if exists set_updated_at on public.%I',t);
    execute format('create trigger set_updated_at before update on public.%I for each row execute procedure public.set_updated_at()',t);
  end loop;
end $$;

-- Admin bootstrap (run only after creating your own account, replacing the email):
-- insert into public.user_roles(user_id,role)
-- select id,'admin' from auth.users where email='you@example.com'
-- on conflict(user_id,role) do nothing;
