-- Paid memberships, payment ledger, and server-enforced per-category posting credits.
-- Run after schema.sql and community-offers.sql. Existing content is preserved and
-- existing user submissions are backfilled as already-used category credits.
begin;

do $preflight$
begin
  if to_regclass('public.profiles') is null
    or to_regclass('public.user_roles') is null
    or to_regclass('public.classified_ads') is null
    or to_regclass('public.blog_posts') is null
    or to_regclass('public.jobs') is null
    or to_regclass('public.businesses') is null
    or to_regclass('public.deals') is null
    or to_regclass('public.blog_comments') is null
    or to_regclass('public.business_reviews') is null
    or to_regclass('public.community_answers') is null
    or to_regclass('auth.users') is null then
    raise exception 'Required DigitalDuniya360 tables are missing; run database/schema.sql and database/community-offers.sql first.';
  end if;
end
$preflight$;

alter table public.profiles
  add column if not exists email text,
  add column if not exists account_status text not null default 'active',
  add column if not exists suspended_at timestamptz,
  add column if not exists suspended_by uuid references auth.users(id) on delete set null;

do $profile_status_check$
begin
  if not exists (
    select 1 from pg_constraint
    where conname = 'profiles_account_status_check'
      and conrelid = 'public.profiles'::regclass
  ) then
    alter table public.profiles
      add constraint profiles_account_status_check
      check (account_status in ('active','suspended'));
  end if;
end
$profile_status_check$;

update public.profiles p
set email = u.email
from auth.users u
where u.id = p.id and p.email is distinct from u.email;

create table if not exists public.membership_plans (
  id uuid primary key default gen_random_uuid(),
  code text not null unique,
  name text not null,
  amount_paise integer not null check (amount_paise > 0),
  duration_days integer not null check (duration_days > 0),
  intro_window_hours integer,
  is_introductory boolean not null default false,
  billing_type text not null default 'one_time',
  billing_cycles integer,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (
    (is_introductory and intro_window_hours is not null and intro_window_hours > 0)
    or (not is_introductory and intro_window_hours is null)
  )
);

alter table public.membership_plans
  add column if not exists billing_type text not null default 'one_time',
  add column if not exists billing_cycles integer;
alter table public.membership_plans
  drop constraint if exists membership_plans_code_check;
alter table public.membership_plans
  add constraint membership_plans_code_check
  check (code in ('intro-60d','standard-60d','standard-monthly-12'));
alter table public.membership_plans
  drop constraint if exists membership_plans_billing_terms_check;
alter table public.membership_plans
  add constraint membership_plans_billing_terms_check
  check (
    (billing_type='one_time' and billing_cycles is null)
    or (billing_type='subscription' and billing_cycles > 0)
  );

insert into public.membership_plans
  (code,name,amount_paise,duration_days,intro_window_hours,is_introductory,billing_type,billing_cycles)
values
  ('intro-60d','Introductory Membership',900,60,72,true,'one_time',null),
  ('standard-monthly-12','Standard Monthly Membership',49900,30,null,false,'subscription',12)
on conflict (code) do nothing;
update public.membership_plans set is_active=false where code='standard-60d';

create table if not exists public.payment_transactions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete restrict,
  plan_id uuid not null references public.membership_plans(id) on delete restrict,
  amount_paise integer not null check (amount_paise > 0),
  currency text not null default 'INR' check (currency = 'INR'),
  order_id text unique,
  subscription_id text,
  invoice_id text,
  payment_id text unique,
  status text not null default 'pending'
    check (status in ('pending','paid','failed','cancelled')),
  failure_code text,
  failure_description text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  paid_at timestamptz,
  verified_at timestamptz
);

alter table public.payment_transactions
  add column if not exists subscription_id text,
  add column if not exists invoice_id text;
drop index if exists public.payment_transactions_invoice_id_idx;
create unique index payment_transactions_invoice_id_idx
  on public.payment_transactions(invoice_id) where invoice_id is not null and status='paid';

create table if not exists public.user_subscriptions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete restrict,
  plan_id uuid not null references public.membership_plans(id) on delete restrict,
  initial_transaction_id uuid not null unique
    references public.payment_transactions(id) on delete restrict,
  razorpay_subscription_id text not null unique,
  status text not null default 'created'
    check (status in ('created','authenticated','active','pending','halted','cancelled','completed','expired','paused')),
  cancel_at_cycle_end boolean not null default false,
  cancel_requested_at timestamptz,
  current_period_start timestamptz,
  current_period_end timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.user_memberships (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete restrict,
  plan_id uuid not null references public.membership_plans(id) on delete restrict,
  payment_transaction_id uuid not null unique
    references public.payment_transactions(id) on delete restrict,
  amount_paise integer not null check (amount_paise > 0),
  razorpay_subscription_id text,
  status text not null default 'active' check (status in ('active','cancelled')),
  starts_at timestamptz not null,
  expires_at timestamptz not null,
  created_at timestamptz not null default now(),
  check (expires_at > starts_at)
);
alter table public.user_memberships
  add column if not exists razorpay_subscription_id text;

create table if not exists public.user_free_usage (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete restrict,
  category text not null check (category in (
    'classified_ads','blog_posts','jobs','businesses','deals','coupons',
    'community_questions','community_answers','blog_comments','business_reviews'
  )),
  source_id uuid,
  first_used_at timestamptz not null default now(),
  unique (user_id, category)
);

create table if not exists public.admin_roles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null unique references auth.users(id) on delete restrict,
  granted_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now()
);

create table if not exists public.payment_webhook_events (
  event_id text primary key,
  event_type text not null,
  order_id text,
  subscription_id text,
  payment_id text,
  status text not null default 'received'
    check (status in ('received','processed','failed','ignored')),
  error_message text,
  received_at timestamptz not null default now(),
  processed_at timestamptz
);
alter table public.payment_webhook_events
  add column if not exists subscription_id text;

create table if not exists public.admin_audit_logs (
  id uuid primary key default gen_random_uuid(),
  actor_id uuid references auth.users(id) on delete set null,
  action text not null,
  entity_type text not null,
  entity_id text,
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create index if not exists payment_transactions_user_created_idx
  on public.payment_transactions(user_id,created_at desc);
create index if not exists payment_transactions_status_created_idx
  on public.payment_transactions(status,created_at desc);
create unique index if not exists payment_transactions_one_pending_plan_idx
  on public.payment_transactions(user_id,plan_id)
  where status='pending';
create index if not exists user_memberships_user_expiry_idx
  on public.user_memberships(user_id,expires_at desc);
create index if not exists user_memberships_active_expiry_idx
  on public.user_memberships(expires_at)
  where status = 'active';
create index if not exists user_memberships_subscription_idx
  on public.user_memberships(razorpay_subscription_id,expires_at desc)
  where razorpay_subscription_id is not null;
create index if not exists user_subscriptions_user_status_idx
  on public.user_subscriptions(user_id,status,current_period_end desc);
create index if not exists user_free_usage_category_idx
  on public.user_free_usage(category,first_used_at desc);
create index if not exists profiles_email_idx
  on public.profiles using gin(to_tsvector('simple',coalesce(email,'')));
create index if not exists admin_audit_logs_created_idx
  on public.admin_audit_logs(created_at desc);

-- Existing user-owned posts count as used credits; records without an owner remain untouched.
insert into public.user_free_usage (user_id,category,source_id,first_used_at)
select user_id,category,(array_agg(source_id order by first_used_at))[1],min(first_used_at)
from (
  select user_id,'classified_ads'::text as category,id as source_id,created_at as first_used_at
  from public.classified_ads where user_id is not null
  union all
  select user_id,'blog_posts',id,created_at from public.blog_posts
  union all
  select user_id,'jobs',id,created_at from public.jobs
  union all
  select user_id,'businesses',id,created_at from public.businesses
  union all
  select user_id,case when offer_type = 'coupon' then 'coupons' else 'deals' end,id,created_at
  from public.deals where user_id is not null
  union all
  select user_id,'blog_comments',id,created_at from public.blog_comments
  union all
  select user_id,'business_reviews',id,created_at from public.business_reviews
  union all
  select user_id,'community_answers',id,created_at from public.community_answers
  union all
  select user_id,'community_questions',id,created_at from public.community_questions
) submissions
group by user_id,category
on conflict (user_id,category) do nothing;

insert into public.admin_roles (user_id,created_at)
select user_id,min(created_at)
from public.user_roles
where role = 'admin'
group by user_id
on conflict (user_id) do nothing;

create or replace function public.is_admin()
returns boolean
language sql
stable
security definer
set search_path = public, pg_temp
as $$
  select exists (
    select 1 from public.admin_roles where user_id = auth.uid()
  );
$$;

create or replace function public.can_moderate()
returns boolean
language sql
stable
security definer
set search_path = public, pg_temp
as $$
  select public.is_admin() or exists (
    select 1 from public.user_roles
    where user_id = auth.uid() and role = 'moderator'
  );
$$;

create or replace function public.sync_admin_role()
returns trigger
language plpgsql
security definer
set search_path = public, pg_temp
as $$
begin
  if tg_op in ('INSERT','UPDATE') and new.role = 'admin' then
    insert into public.admin_roles(user_id,granted_by)
    values(new.user_id,auth.uid())
    on conflict (user_id) do nothing;
  end if;

  if tg_op in ('DELETE','UPDATE') and old.role = 'admin'
    and (tg_op = 'DELETE' or new.role <> 'admin' or new.user_id <> old.user_id) then
    delete from public.admin_roles ar
    where ar.user_id = old.user_id
      and not exists (
        select 1 from public.user_roles ur
        where ur.user_id = old.user_id and ur.role = 'admin'
          and (tg_op = 'DELETE' or ur.id <> old.id)
      );
  end if;
  if tg_op='DELETE' then return old; end if;
  return new;
end;
$$;

drop trigger if exists sync_admin_role_from_user_roles on public.user_roles;
create trigger sync_admin_role_from_user_roles
after insert or update or delete on public.user_roles
for each row execute procedure public.sync_admin_role();

create or replace function public.sync_profile_from_auth_user()
returns trigger
language plpgsql
security definer
set search_path = public, pg_temp
as $$
begin
  insert into public.profiles(id,full_name,email)
  values(new.id,coalesce(new.raw_user_meta_data->>'full_name',''),new.email)
  on conflict (id) do update set email = excluded.email;

  if tg_op = 'INSERT' then
    insert into public.user_roles(user_id,role)
    values(new.id,'user')
    on conflict (user_id,role) do nothing;
  end if;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
drop trigger if exists on_auth_user_email_updated on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.sync_profile_from_auth_user();
create trigger on_auth_user_email_updated
after update of email on auth.users
for each row execute procedure public.sync_profile_from_auth_user();

create or replace function public.get_my_membership_summary()
returns jsonb
language plpgsql
security definer
set search_path = public, auth, pg_temp
as $$
declare
  v_user_id uuid := auth.uid();
  v_registered_at timestamptz;
  v_now timestamptz := clock_timestamp();
begin
  if v_user_id is null then
    raise exception 'Sign in to view membership information.';
  end if;

  select created_at into v_registered_at from auth.users where id = v_user_id;
  if v_registered_at is null then
    raise exception 'Account registration date is unavailable.';
  end if;

  return jsonb_build_object(
    'server_now',v_now,
    'registered_at',v_registered_at,
    'intro_offer_expires_at',v_registered_at + interval '72 hours',
    'intro_offer_eligible',(
      v_now < v_registered_at + interval '72 hours'
      and exists(select 1 from public.membership_plans where code='intro-60d' and is_active)
      and not exists(
        select 1 from public.user_memberships m
        join public.membership_plans p on p.id=m.plan_id
        where m.user_id=v_user_id and p.is_introductory
      )
    ),
    'plans',coalesce((
      select jsonb_agg(jsonb_build_object(
        'code',code,'name',name,'amount_paise',amount_paise,
        'duration_days',duration_days,'intro_window_hours',intro_window_hours,
        'is_introductory',is_introductory,'is_active',is_active,
        'billing_type',billing_type,'billing_cycles',billing_cycles
      ) order by is_introductory desc,amount_paise)
      from public.membership_plans where is_active
    ),'[]'::jsonb),
    'active_membership',(
      select jsonb_build_object(
        'id',m.id,'plan_code',p.code,'plan_name',p.name,
        'amount_paise',m.amount_paise,'starts_at',m.starts_at,'expires_at',m.expires_at,
        'razorpay_subscription_id',m.razorpay_subscription_id
      )
      from public.user_memberships m
      join public.membership_plans p on p.id=m.plan_id
      where m.user_id=v_user_id and m.status='active'
        and m.starts_at <= v_now and m.expires_at > v_now
      order by m.expires_at desc limit 1
    ),
    'subscriptions',coalesce((
      select jsonb_agg(jsonb_build_object(
        'id',s.id,'plan_code',p.code,'plan_name',p.name,'status',s.status,
        'razorpay_subscription_id',s.razorpay_subscription_id,
        'cancel_at_cycle_end',s.cancel_at_cycle_end,
        'current_period_start',s.current_period_start,
        'current_period_end',s.current_period_end
      ) order by s.created_at desc)
      from public.user_subscriptions s
      join public.membership_plans p on p.id=s.plan_id
      where s.user_id=v_user_id
    ),'[]'::jsonb),
    'membership_history',coalesce((
      select jsonb_agg(jsonb_build_object(
        'id',m.id,'plan_code',p.code,'plan_name',p.name,'amount_paise',m.amount_paise,
        'status',case when m.status='cancelled' then 'cancelled'
          when m.expires_at <= v_now then 'expired'
          when m.starts_at > v_now then 'scheduled' else 'active' end,
        'starts_at',m.starts_at,'expires_at',m.expires_at
      ) order by m.created_at desc)
      from public.user_memberships m
      join public.membership_plans p on p.id=m.plan_id
      where m.user_id=v_user_id
    ),'[]'::jsonb),
    'free_usage',coalesce((
      select jsonb_agg(jsonb_build_object(
        'category',c.category,'used',u.id is not null,'first_used_at',u.first_used_at
      ) order by c.category)
      from unnest(array[
        'classified_ads','blog_posts','jobs','businesses','deals','coupons',
        'community_questions','community_answers','blog_comments','business_reviews'
      ]::text[]) as c(category)
      left join public.user_free_usage u
        on u.user_id=v_user_id and u.category=c.category
    ),'[]'::jsonb),
    'payment_history',coalesce((
      select jsonb_agg(jsonb_build_object(
        'id',t.id,'plan_code',p.code,'plan_name',p.name,
        'amount_paise',t.amount_paise,'currency',t.currency,'status',t.status,
        'order_id',t.order_id,'subscription_id',t.subscription_id,
        'invoice_id',t.invoice_id,'payment_id',t.payment_id,
        'created_at',t.created_at,'paid_at',t.paid_at
      ) order by t.created_at desc)
      from (
        select * from public.payment_transactions
        where user_id=v_user_id order by created_at desc limit 50
      ) t
      join public.membership_plans p on p.id=t.plan_id
    ),'[]'::jsonb)
  );
end;
$$;

create or replace function public.create_membership_order_intent(p_plan_code text)
returns jsonb
language plpgsql
security definer
set search_path = public, auth, pg_temp
as $$
declare
  v_user_id uuid := auth.uid();
  v_now timestamptz := clock_timestamp();
  v_registered_at timestamptz;
  v_plan public.membership_plans%rowtype;
  v_existing public.payment_transactions%rowtype;
  v_transaction_id uuid;
begin
  if v_user_id is null then
    raise exception 'Sign in before purchasing a membership.';
  end if;

  perform 1 from public.profiles where id=v_user_id and account_status='active' for update;
  if not found then
    raise exception 'This account cannot make purchases.';
  end if;

  select created_at into v_registered_at from auth.users where id=v_user_id;
  if v_registered_at is null then
    raise exception 'Account registration date is unavailable.';
  end if;

  select * into v_plan from public.membership_plans
  where code=p_plan_code and is_active;
  if not found then
    raise exception 'This membership plan is unavailable.';
  end if;

  if v_plan.is_introductory then
    if v_now >= v_registered_at + make_interval(hours => v_plan.intro_window_hours) then
      raise exception 'The introductory offer has expired for this account.';
    end if;
    if exists (
      select 1 from public.user_memberships m
      join public.membership_plans p on p.id=m.plan_id
      where m.user_id=v_user_id and p.is_introductory
    ) then
      raise exception 'The introductory membership can only be purchased once.';
    end if;
  else
    if v_now < v_registered_at + interval '72 hours' then
      raise exception 'The standard plan becomes available after the introductory offer expires.';
    end if;
  end if;

  update public.payment_transactions
  set status='cancelled',failure_description='Checkout intent expired.'
  where user_id=v_user_id and plan_id=v_plan.id and status='pending'
    and subscription_id is null
    and created_at < v_now - interval '30 minutes';

  select * into v_existing from public.payment_transactions
  where user_id=v_user_id and plan_id=v_plan.id and status='pending'
  order by created_at desc limit 1;
  if found then
    return jsonb_build_object(
      'transaction_id',v_existing.id,'plan_id',v_plan.id,
      'amount_paise',v_existing.amount_paise,'plan_name',v_plan.name,
      'billing_type',v_plan.billing_type,'billing_cycles',v_plan.billing_cycles,
      'order_id',v_existing.order_id,'subscription_id',v_existing.subscription_id,
      'created',false
    );
  end if;

  if v_plan.billing_type='subscription' and exists (
    select 1 from public.user_subscriptions s
    where s.user_id=v_user_id and s.plan_id=v_plan.id
      and s.status not in ('cancelled','completed','expired')
      and (s.current_period_end is null or s.current_period_end>v_now)
  ) then
    raise exception 'An active or pending recurring membership already exists.';
  end if;

  if (
    select count(*) from public.payment_transactions
    where user_id=v_user_id and created_at > v_now - interval '1 hour'
  ) >= 8 then
    raise exception 'Too many checkout attempts. Please wait and try again.';
  end if;

  insert into public.payment_transactions(user_id,plan_id,amount_paise,status)
  values(v_user_id,v_plan.id,v_plan.amount_paise,'pending')
  returning id into v_transaction_id;

  return jsonb_build_object(
    'transaction_id',v_transaction_id,'plan_id',v_plan.id,
    'amount_paise',v_plan.amount_paise,'plan_name',v_plan.name,
    'billing_type',v_plan.billing_type,'billing_cycles',v_plan.billing_cycles,
    'order_id',null,'subscription_id',null,'created',true
  );
end;
$$;

create or replace function public.submit_content_with_access(
  p_category text,
  p_payload jsonb
)
returns jsonb
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  v_user_id uuid := auth.uid();
  v_id uuid;
  v_table text;
  v_free boolean;
  v_active_member boolean;
  v_access text;
  v_record jsonb;
  v_payload jsonb := coalesce(p_payload,'{}'::jsonb);
begin
  if v_user_id is null then
    raise exception 'Sign in before submitting content.';
  end if;
  if jsonb_typeof(v_payload) <> 'object' then
    raise exception 'Submission data must be an object.';
  end if;
  if octet_length(v_payload::text) > 100000 then
    raise exception 'Submission is too large.';
  end if;

  perform 1 from public.profiles
  where id=v_user_id and account_status='active'
  for update;
  if not found then
    raise exception 'This account cannot submit content.';
  end if;

  if p_category is null or p_category not in (
    'classified_ads','blog_posts','jobs','businesses','deals','coupons',
    'community_questions','community_answers','blog_comments','business_reviews'
  ) then
    raise exception 'This submission category is not supported.';
  end if;

  v_free := not exists (
    select 1 from public.user_free_usage
    where user_id=v_user_id and category=p_category
  );
  select exists (
    select 1 from public.user_memberships
    where user_id=v_user_id and status='active'
      and starts_at <= clock_timestamp() and expires_at > clock_timestamp()
  ) into v_active_member;

  if not v_free and not v_active_member then
    raise exception 'An active membership is required for another submission in this category.';
  end if;

  if p_category in ('deals','coupons') then
    if not (
      (v_payload->>'merchant'='Amazon'
        and coalesce(v_payload->>'affiliate_url','') ~* '^https://([a-z0-9-]+\.)*(amazon\.in|amazon\.com|amzn\.to)(:[0-9]+)?(/|[?#]|$)')
      or (v_payload->>'merchant'='Flipkart'
        and coalesce(v_payload->>'affiliate_url','') ~* '^https://([a-z0-9-]+\.)*(flipkart\.com|fkrt\.it)(:[0-9]+)?(/|[?#]|$)')
      or (v_payload->>'merchant'='Meesho'
        and coalesce(v_payload->>'affiliate_url','') ~* '^https://([a-z0-9-]+\.)*meesho\.com(:[0-9]+)?(/|[?#]|$)')
      or (v_payload->>'merchant'='Website'
        and coalesce(v_payload->>'affiliate_url','') ~* '^https://([a-z0-9-]+\.)*[a-z0-9-]+\.[a-z]{2,}(:[0-9]+)?(/|[?#]|$)')
    ) then
      raise exception 'Choose a supported store and provide a matching HTTPS link.';
    end if;
    if p_category='coupons' and coalesce(v_payload->>'coupon_code','')='' then
      raise exception 'A verified coupon code is required.';
    end if;
    if nullif(v_payload->>'image_url','') is not null
      and (v_payload->>'image_url') !~* '^https://[^[:space:]]+$' then
      raise exception 'Offer images must use HTTPS.';
    end if;
    if nullif(v_payload->>'original_price','') is not null
      and nullif(v_payload->>'sale_price','') is not null
      and (v_payload->>'sale_price')::numeric > (v_payload->>'original_price')::numeric then
      raise exception 'Offer price cannot be higher than the original price.';
    end if;
  end if;

  if v_free then
    insert into public.user_free_usage(user_id,category)
    values(v_user_id,p_category);
    v_access := 'free';
  else
    v_access := 'membership';
  end if;

  case p_category
    when 'classified_ads' then
      v_table := 'classified_ads';
      insert into public.classified_ads(
        user_id,title,slug,category,description,price,city,state,seller_name,phone,
        whatsapp,website_url,featured,status
      ) values (
        v_user_id,v_payload->>'title',
        coalesce(nullif(v_payload->>'slug',''),gen_random_uuid()::text),
        v_payload->>'category',v_payload->>'description',
        nullif(v_payload->>'price','')::numeric,
        v_payload->>'city',v_payload->>'state',v_payload->>'seller_name',
        v_payload->>'phone',nullif(v_payload->>'whatsapp',''),
        nullif(v_payload->>'website_url',''),false,'published'
      ) returning id into v_id;
    when 'blog_posts' then
      v_table := 'blog_posts';
      insert into public.blog_posts(
        user_id,title,slug,category,summary,content,website_url,featured_image,
        seo_title,meta_description,tags,status
      ) values (
        v_user_id,v_payload->>'title',
        coalesce(nullif(v_payload->>'slug',''),gen_random_uuid()::text),
        v_payload->>'category',coalesce(v_payload->>'summary',''),
        v_payload->>'content',nullif(v_payload->>'website_url',''),
        nullif(v_payload->>'featured_image',''),nullif(v_payload->>'seo_title',''),
        nullif(v_payload->>'meta_description',''),
        array(select jsonb_array_elements_text(
          case when jsonb_typeof(v_payload->'tags')='array'
            then v_payload->'tags' else '[]'::jsonb end
        )),
        'pending'
      ) returning id into v_id;
    when 'jobs' then
      v_table := 'jobs';
      insert into public.jobs(
        user_id,title,slug,company_name,category,city,work_type,salary,
        experience,description,skills,apply_url,deadline,status
      ) values (
        v_user_id,v_payload->>'title',
        coalesce(nullif(v_payload->>'slug',''),gen_random_uuid()::text),
        v_payload->>'company_name',v_payload->>'category',v_payload->>'city',
        v_payload->>'work_type',nullif(v_payload->>'salary',''),
        nullif(v_payload->>'experience',''),v_payload->>'description',
        array(select jsonb_array_elements_text(
          case when jsonb_typeof(v_payload->'skills')='array'
            then v_payload->'skills' else '[]'::jsonb end
        )),
        v_payload->>'apply_url',nullif(v_payload->>'deadline','')::date,'pending'
      ) returning id into v_id;
    when 'businesses' then
      v_table := 'businesses';
      insert into public.businesses(
        user_id,name,slug,category,city,state,description,website,phone,
        whatsapp,address,logo_url,cover_image,listing_type,services,social_links,status
      ) values (
        v_user_id,v_payload->>'name',
        coalesce(nullif(v_payload->>'slug',''),gen_random_uuid()::text),
        v_payload->>'category',v_payload->>'city',nullif(v_payload->>'state',''),
        v_payload->>'description',nullif(v_payload->>'website',''),
        nullif(v_payload->>'phone',''),nullif(v_payload->>'whatsapp',''),
        nullif(v_payload->>'address',''),nullif(v_payload->>'logo_url',''),
        nullif(v_payload->>'cover_image',''),'free',
        array(select jsonb_array_elements_text(
          case when jsonb_typeof(v_payload->'services')='array'
            then v_payload->'services' else '[]'::jsonb end
        )),
        coalesce(v_payload->'social_links','{}'::jsonb),'pending'
      ) returning id into v_id;
    when 'deals' then
      v_table := 'deals';
      insert into public.deals(
        user_id,title,slug,offer_type,category,description,image_url,merchant,
        coupon_code,original_price,sale_price,discount_percentage,affiliate_url,expires_at,status
      ) values (
        v_user_id,v_payload->>'title',
        coalesce(nullif(v_payload->>'slug',''),gen_random_uuid()::text),
        'product',v_payload->>'category',coalesce(v_payload->>'description',''),
        nullif(v_payload->>'image_url',''),nullif(v_payload->>'merchant',''),
        nullif(v_payload->>'coupon_code',''),
        nullif(v_payload->>'original_price','')::numeric,
        nullif(v_payload->>'sale_price','')::numeric,
        nullif(v_payload->>'discount_percentage','')::numeric,
        v_payload->>'affiliate_url',nullif(v_payload->>'expires_at','')::timestamptz,
        'published'
      ) returning id into v_id;
    when 'coupons' then
      v_table := 'deals';
      insert into public.deals(
        user_id,title,slug,offer_type,category,description,image_url,merchant,
        coupon_code,original_price,sale_price,discount_percentage,affiliate_url,expires_at,status
      ) values (
        v_user_id,v_payload->>'title',
        coalesce(nullif(v_payload->>'slug',''),gen_random_uuid()::text),
        'coupon',v_payload->>'category',coalesce(v_payload->>'description',''),
        nullif(v_payload->>'image_url',''),nullif(v_payload->>'merchant',''),
        nullif(v_payload->>'coupon_code',''),
        nullif(v_payload->>'original_price','')::numeric,
        nullif(v_payload->>'sale_price','')::numeric,
        nullif(v_payload->>'discount_percentage','')::numeric,
        v_payload->>'affiliate_url',nullif(v_payload->>'expires_at','')::timestamptz,
        'published'
      ) returning id into v_id;
    when 'community_questions' then
      v_table := 'community_questions';
      insert into public.community_questions(user_id,title,slug,category,description,status)
      values (
        v_user_id,v_payload->>'title',
        coalesce(nullif(v_payload->>'slug',''),gen_random_uuid()::text),
        v_payload->>'category',v_payload->>'description','pending'
      ) returning id into v_id;
    when 'community_answers' then
      v_table := 'community_answers';
      if not exists (
        select 1 from public.community_questions
        where id=(v_payload->>'question_id')::uuid and status='published'
      ) then
        raise exception 'Answers can only be added to published questions.';
      end if;
      insert into public.community_answers(question_id,user_id,body,status)
      values ((v_payload->>'question_id')::uuid,v_user_id,v_payload->>'body','pending')
      returning id into v_id;
    when 'blog_comments' then
      v_table := 'blog_comments';
      if not exists (
        select 1 from public.blog_posts
        where id=(v_payload->>'post_id')::uuid and status='published'
      ) then
        raise exception 'Comments can only be added to published articles.';
      end if;
      insert into public.blog_comments(post_id,user_id,body,status)
      values ((v_payload->>'post_id')::uuid,v_user_id,v_payload->>'body','pending')
      returning id into v_id;
    when 'business_reviews' then
      v_table := 'business_reviews';
      if not exists (
        select 1 from public.businesses
        where id=(v_payload->>'business_id')::uuid and status='published'
      ) then
        raise exception 'Reviews can only be added to published businesses.';
      end if;
      insert into public.business_reviews(business_id,user_id,rating,body,status)
      values (
        (v_payload->>'business_id')::uuid,v_user_id,
        (v_payload->>'rating')::smallint,v_payload->>'body','pending'
      ) returning id into v_id;
  end case;

  if v_free then
    update public.user_free_usage
    set source_id=v_id
    where user_id=v_user_id and category=p_category;
  end if;

  execute format('select to_jsonb(t) from public.%I t where id = $1',v_table)
  into v_record using v_id;

  return jsonb_build_object('record',v_record,'access',v_access);
end;
$$;

create or replace function public.store_razorpay_subscription(
  p_transaction_id uuid,
  p_subscription_id text
)
returns jsonb
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  v_transaction public.payment_transactions%rowtype;
  v_plan public.membership_plans%rowtype;
  v_subscription public.user_subscriptions%rowtype;
begin
  if p_subscription_id is null or length(trim(p_subscription_id)) not between 5 and 128 then
    raise exception 'A valid Razorpay subscription ID is required.';
  end if;
  select * into v_transaction
  from public.payment_transactions where id=p_transaction_id for update;
  if not found or v_transaction.status<>'pending' then
    raise exception 'A pending subscription checkout was not found.';
  end if;
  select * into v_plan from public.membership_plans where id=v_transaction.plan_id;
  if not found or v_plan.billing_type<>'subscription' then
    raise exception 'This checkout is not for a recurring plan.';
  end if;
  select * into v_subscription
  from public.user_subscriptions where initial_transaction_id=p_transaction_id;
  if found then
    if v_subscription.razorpay_subscription_id<>p_subscription_id then
      raise exception 'A different Razorpay subscription is already linked to this checkout.';
    end if;
    return jsonb_build_object('status',v_subscription.status,'subscription_id',p_subscription_id);
  end if;
  if exists (
    select 1 from public.user_subscriptions
    where razorpay_subscription_id=p_subscription_id
  ) then
    raise exception 'This Razorpay subscription is already linked to another account.';
  end if;
  insert into public.user_subscriptions(
    user_id,plan_id,initial_transaction_id,razorpay_subscription_id,status
  ) values (
    v_transaction.user_id,v_transaction.plan_id,p_transaction_id,p_subscription_id,'created'
  );
  update public.payment_transactions
  set subscription_id=p_subscription_id
  where id=p_transaction_id and status='pending';
  return jsonb_build_object('status','created','subscription_id',p_subscription_id);
end;
$$;

create or replace function public.record_subscription_charge(
  p_subscription_id text,
  p_payment_id text,
  p_invoice_id text,
  p_amount_paise integer,
  p_paid_at timestamptz,
  p_current_start timestamptz,
  p_current_end timestamptz,
  p_subscription_status text default 'active'
)
returns jsonb
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  v_subscription public.user_subscriptions%rowtype;
  v_plan public.membership_plans%rowtype;
  v_payment_transaction_id uuid;
  v_existing_transaction public.payment_transactions%rowtype;
  v_membership_id uuid;
begin
  if p_payment_id is null or length(trim(p_payment_id)) not between 5 and 128
    or p_current_start is null or p_current_end is null or p_current_end<=p_current_start then
    raise exception 'Verified subscription payment details are incomplete.';
  end if;
  if p_subscription_status not in ('active','completed') then
    raise exception 'The subscription is not in a payable state.';
  end if;
  select * into v_subscription
  from public.user_subscriptions
  where razorpay_subscription_id=p_subscription_id
  for update;
  if not found then
    raise exception 'The local subscription was not found.';
  end if;
  select * into v_plan from public.membership_plans where id=v_subscription.plan_id;
  if not found or v_plan.billing_type<>'subscription'
    or v_plan.amount_paise<>p_amount_paise then
    raise exception 'The recurring payment does not match the stored plan.';
  end if;
  select id into v_payment_transaction_id
  from public.payment_transactions where payment_id=p_payment_id;
  if found then
    if not exists (
      select 1 from public.payment_transactions
      where id=v_payment_transaction_id and subscription_id=p_subscription_id
        and status='paid'
    ) then
      raise exception 'This payment is already linked to another transaction.';
    end if;
    select id into v_membership_id
    from public.user_memberships
    where payment_transaction_id=v_payment_transaction_id;
    return jsonb_build_object(
      'status','paid','membership_id',v_membership_id,'duplicate',true
    );
  end if;
  if p_invoice_id is not null and exists (
    select 1 from public.payment_transactions where invoice_id=p_invoice_id and status='paid'
  ) then
    raise exception 'This subscription invoice has already been processed.';
  end if;

  select * into v_existing_transaction
  from public.payment_transactions
  where id=v_subscription.initial_transaction_id
  for update;
  if v_existing_transaction.status='pending' then
    v_payment_transaction_id:=v_existing_transaction.id;
    update public.payment_transactions
    set subscription_id=p_subscription_id,invoice_id=p_invoice_id,
        payment_id=p_payment_id,status='paid',
        paid_at=coalesce(p_paid_at,clock_timestamp()),verified_at=clock_timestamp(),
        failure_code=null,failure_description=null
    where id=v_payment_transaction_id;
  else
    insert into public.payment_transactions(
      user_id,plan_id,amount_paise,subscription_id,invoice_id,payment_id,status,paid_at,verified_at
    ) values (
      v_subscription.user_id,v_subscription.plan_id,p_amount_paise,
      p_subscription_id,p_invoice_id,p_payment_id,'paid',
      coalesce(p_paid_at,clock_timestamp()),clock_timestamp()
    ) returning id into v_payment_transaction_id;
  end if;

  insert into public.user_memberships(
    user_id,plan_id,payment_transaction_id,amount_paise,razorpay_subscription_id,
    status,starts_at,expires_at
  ) values (
    v_subscription.user_id,v_subscription.plan_id,v_payment_transaction_id,
    p_amount_paise,p_subscription_id,'active',p_current_start,p_current_end
  ) returning id into v_membership_id;

  update public.user_subscriptions
  set status=case
        when v_subscription.status in ('cancelled','completed','expired')
          and p_subscription_status not in ('cancelled','completed','expired')
          then v_subscription.status
        else p_subscription_status end,
      current_period_start=p_current_start,
      current_period_end=p_current_end,
      updated_at=clock_timestamp()
  where id=v_subscription.id;
  insert into public.admin_audit_logs(actor_id,action,entity_type,entity_id,details)
  values (
    null,'membership.subscription_cycle_paid','user_subscriptions',v_subscription.id::text,
    jsonb_build_object(
      'user_id',v_subscription.user_id,'payment_id',p_payment_id,
      'invoice_id',p_invoice_id,'amount_paise',p_amount_paise,
      'membership_id',v_membership_id
    )
  );
  return jsonb_build_object(
    'status','paid','membership_id',v_membership_id,'duplicate',false
  );
end;
$$;

create or replace function public.record_subscription_status(
  p_subscription_id text,
  p_status text,
  p_current_start timestamptz default null,
  p_current_end timestamptz default null
)
returns jsonb
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  v_subscription public.user_subscriptions%rowtype;
begin
  if p_status not in ('created','authenticated','active','pending','halted','cancelled','completed','expired','paused') then
    raise exception 'Unsupported Razorpay subscription status.';
  end if;
  update public.user_subscriptions
  set status=case
        when status in ('cancelled','completed','expired')
          and p_status not in ('cancelled','completed','expired')
          then status
        else p_status end,
      current_period_start=coalesce(p_current_start,current_period_start),
      current_period_end=coalesce(p_current_end,current_period_end),
      updated_at=clock_timestamp()
  where razorpay_subscription_id=p_subscription_id
  returning * into v_subscription;
  if not found then
    raise exception 'The local subscription was not found.';
  end if;
  if v_subscription.status in ('cancelled','expired') then
    update public.payment_transactions
    set status='cancelled',failure_description='Subscription ended before its first payment.'
    where id=v_subscription.initial_transaction_id and status='pending';
  end if;
  insert into public.admin_audit_logs(actor_id,action,entity_type,entity_id,details)
  values (
    null,'membership.subscription_status_changed','user_subscriptions',v_subscription.id::text,
    jsonb_build_object('user_id',v_subscription.user_id,'status',p_status)
  );
  return jsonb_build_object('status',v_subscription.status);
end;
$$;

create or replace function public.record_subscription_failure(
  p_subscription_id text,
  p_payment_id text,
  p_invoice_id text,
  p_amount_paise integer,
  p_failure_code text,
  p_failure_description text
)
returns jsonb
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  v_subscription public.user_subscriptions%rowtype;
  v_plan public.membership_plans%rowtype;
begin
  select * into v_subscription
  from public.user_subscriptions
  where razorpay_subscription_id=p_subscription_id
  for update;
  if not found then
    raise exception 'The local subscription was not found.';
  end if;
  select * into v_plan from public.membership_plans where id=v_subscription.plan_id;
  if not found or v_plan.amount_paise<>p_amount_paise then
    raise exception 'The failed payment does not match the stored plan.';
  end if;
  if exists (select 1 from public.payment_transactions where payment_id=p_payment_id) then
    return jsonb_build_object('status','duplicate');
  end if;
  insert into public.payment_transactions(
    user_id,plan_id,amount_paise,subscription_id,invoice_id,payment_id,status,
    failure_code,failure_description
  ) values (
    v_subscription.user_id,v_subscription.plan_id,p_amount_paise,
    p_subscription_id,p_invoice_id,p_payment_id,'failed',
    left(p_failure_code,100),left(p_failure_description,500)
  );
  return jsonb_build_object('status','failed');
end;
$$;

create or replace function public.activate_membership_from_payment(
  p_transaction_id uuid,
  p_order_id text,
  p_payment_id text,
  p_amount_paise integer,
  p_paid_at timestamptz default clock_timestamp()
)
returns jsonb
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  v_transaction public.payment_transactions%rowtype;
  v_plan public.membership_plans%rowtype;
  v_membership_id uuid;
  v_start timestamptz;
  v_paid_at timestamptz := coalesce(p_paid_at,clock_timestamp());
begin
  select * into v_transaction
  from public.payment_transactions where id=p_transaction_id for update;
  if not found then
    raise exception 'Payment transaction was not found.';
  end if;
  if v_transaction.order_id is distinct from p_order_id
    or v_transaction.amount_paise <> p_amount_paise then
    raise exception 'Verified payment does not match the stored order.';
  end if;

  select * into v_plan from public.membership_plans where id=v_transaction.plan_id;
  if not found or v_plan.amount_paise <> v_transaction.amount_paise then
    raise exception 'Stored membership plan amount does not match the payment.';
  end if;
  if v_plan.billing_type<>'one_time' then
    raise exception 'Recurring payments must be activated through the subscription handler.';
  end if;

  if v_transaction.status='paid' then
    if v_transaction.payment_id is distinct from p_payment_id then
      raise exception 'This order has already been paid with another payment.';
    end if;
    select id into v_membership_id
    from public.user_memberships
    where payment_transaction_id=p_transaction_id;
    return jsonb_build_object('status','paid','membership_id',v_membership_id,'duplicate',true);
  end if;

  if exists (
    select 1 from public.payment_transactions
    where payment_id=p_payment_id and id<>p_transaction_id
  ) then
    raise exception 'This Razorpay payment is already attached to another transaction.';
  end if;

  perform 1 from public.profiles where id=v_transaction.user_id for update;
  select greatest(
    clock_timestamp(),
    coalesce(max(expires_at) filter (
      where status='active' and expires_at > clock_timestamp()
    ),clock_timestamp())
  ) into v_start
  from public.user_memberships where user_id=v_transaction.user_id;

  insert into public.user_memberships(
    user_id,plan_id,payment_transaction_id,amount_paise,status,starts_at,expires_at
  ) values (
    v_transaction.user_id,v_transaction.plan_id,v_transaction.id,
    v_transaction.amount_paise,'active',v_start,
    v_start + make_interval(days => v_plan.duration_days)
  )
  on conflict (payment_transaction_id) do nothing
  returning id into v_membership_id;

  if v_membership_id is null then
    select id into v_membership_id from public.user_memberships
    where payment_transaction_id=p_transaction_id;
  end if;

  update public.payment_transactions
  set payment_id=p_payment_id,status='paid',paid_at=v_paid_at,verified_at=clock_timestamp(),
      failure_code=null,failure_description=null
  where id=p_transaction_id;

  insert into public.admin_audit_logs(actor_id,action,entity_type,entity_id,details)
  values (
    null,'membership.activated','user_memberships',v_membership_id::text,
    jsonb_build_object('user_id',v_transaction.user_id,'plan_code',v_plan.code,
      'amount_paise',v_transaction.amount_paise,'transaction_id',v_transaction.id)
  );

  return jsonb_build_object('status','paid','membership_id',v_membership_id,'duplicate',false);
end;
$$;

create or replace function public.admin_membership_overview()
returns jsonb
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  v_now timestamptz := clock_timestamp();
begin
  if not public.is_admin() then
    raise exception 'Administrator access is required.';
  end if;
  return jsonb_build_object(
    'total_users',(select count(*) from public.profiles),
    'active_memberships',(select count(*) from public.user_memberships
      where status='active' and starts_at<=v_now and expires_at>v_now),
    'expired_memberships',(select count(*) from public.user_memberships
      where status='active' and expires_at<=v_now),
    'paid_users',(select count(distinct user_id) from public.user_memberships
      where status='active' and starts_at<=v_now and expires_at>v_now),
    'free_users',(select count(*) from public.profiles p where not exists(
      select 1 from public.user_memberships m where m.user_id=p.id
        and m.status='active' and m.starts_at<=v_now and m.expires_at>v_now
    )),
    'intro_payments',(select count(*)
      from public.payment_transactions t join public.membership_plans p on p.id=t.plan_id
      where t.status='paid' and p.code='intro-60d'),
    'standard_payments',(select count(*)
      from public.payment_transactions t join public.membership_plans p on p.id=t.plan_id
      where t.status='paid' and p.code='standard-monthly-12'),
    'verified_revenue_paise',(select coalesce(sum(amount_paise),0)
      from public.payment_transactions where status='paid')
  );
end;
$$;

create or replace function public.admin_search_users(
  p_query text default '',
  p_limit integer default 50,
  p_offset integer default 0
)
returns jsonb
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  v_query text := left(trim(coalesce(p_query,'')),120);
  v_limit integer := greatest(1,least(coalesce(p_limit,50),100));
  v_offset integer := greatest(coalesce(p_offset,0),0);
begin
  if not public.is_admin() then
    raise exception 'Administrator access is required.';
  end if;
  return jsonb_build_object(
    'total',(
      select count(*) from public.profiles p
      where v_query='' or strpos(lower(coalesce(p.email,'')),lower(v_query))>0
        or strpos(lower(p.full_name),lower(v_query))>0
    ),
    'users',coalesce((
      select jsonb_agg(to_jsonb(rows) order by rows.created_at desc)
      from (
        select p.id,p.email,p.full_name,p.account_status,p.suspended_at,p.created_at
        from public.profiles p
        where v_query='' or strpos(lower(coalesce(p.email,'')),lower(v_query))>0
          or strpos(lower(p.full_name),lower(v_query))>0
        order by p.created_at desc
        limit v_limit offset v_offset
      ) rows
    ),'[]'::jsonb)
  );
end;
$$;

create or replace function public.audit_admin_content_change()
returns trigger
language plpgsql
security definer
set search_path = public, pg_temp
as $$
declare
  v_old jsonb;
  v_new jsonb;
  v_id text;
begin
  if auth.uid() is null or not public.can_moderate() then
    if tg_op='DELETE' then return old; end if;
    return new;
  end if;
  if tg_op <> 'INSERT' then v_old := to_jsonb(old); end if;
  if tg_op <> 'DELETE' then v_new := to_jsonb(new); end if;
  v_id := coalesce(v_new->>'id',v_old->>'id');
  insert into public.admin_audit_logs(actor_id,action,entity_type,entity_id,details)
  values (
    auth.uid(),'content.'||lower(tg_op),tg_table_name,v_id,
    jsonb_build_object(
      'old_status',v_old->>'status',
      'new_status',v_new->>'status'
    )
  );
  if tg_op='DELETE' then return old; end if;
  return new;
end;
$$;

do $audit_triggers$
declare t text;
begin
  foreach t in array array[
    'blog_posts','classified_ads','businesses','jobs','deals','coupons',
    'blog_comments','business_reviews','community_questions','community_answers'
  ] loop
    execute format('drop trigger if exists admin_content_audit on public.%I',t);
    execute format(
      'create trigger admin_content_audit after insert or update or delete on public.%I for each row execute procedure public.audit_admin_content_change()',
      t
    );
  end loop;
end
$audit_triggers$;

drop trigger if exists set_updated_at on public.membership_plans;
create trigger set_updated_at before update on public.membership_plans
for each row execute procedure public.set_updated_at();
drop trigger if exists set_updated_at on public.payment_transactions;
create trigger set_updated_at before update on public.payment_transactions
for each row execute procedure public.set_updated_at();
drop trigger if exists set_updated_at on public.user_subscriptions;
create trigger set_updated_at before update on public.user_subscriptions
for each row execute procedure public.set_updated_at();

-- User submissions must pass through submit_content_with_access; admin moderation remains available.
do $submission_policies$
declare t text;
begin
  foreach t in array array[
    'blog_posts','businesses','jobs','community_questions',
    'blog_comments','business_reviews','community_answers'
  ] loop
    execute format('drop policy if exists "owner_insert" on public.%I',t);
    execute format('drop policy if exists "membership_admin_insert" on public.%I',t);
    execute format(
      'create policy "membership_admin_insert" on public.%I for insert to authenticated with check (public.can_moderate())',
      t
    );
  end loop;
end
$submission_policies$;

drop policy if exists "owner_insert" on public.classified_ads;
drop policy if exists "membership_admin_insert" on public.classified_ads;
create policy "membership_admin_insert" on public.classified_ads
  for insert to authenticated with check (public.can_moderate());
drop policy if exists "community_offer_insert" on public.deals;

drop policy if exists "images_owner_insert" on public.ad_images;
create policy "images_owner_insert" on public.ad_images for insert to authenticated
  with check (
    user_id=auth.uid()
    and exists (
      select 1 from public.classified_ads a
      where a.id=ad_id and a.user_id=auth.uid() and a.status='published'
    )
  );

drop policy if exists "public_upload_classified_images" on storage.objects;
drop policy if exists "classified_images_owner_upload" on storage.objects;
create policy "classified_images_owner_upload" on storage.objects for insert to authenticated
  with check (
    bucket_id='classified-images'
    and (storage.foldername(name))[1]='ads'
    and exists (
      select 1 from public.classified_ads a
      where a.id::text=(storage.foldername(name))[2]
        and a.user_id=auth.uid() and a.status='published'
    )
  );

alter table public.membership_plans enable row level security;
alter table public.user_memberships enable row level security;
alter table public.payment_transactions enable row level security;
alter table public.user_subscriptions enable row level security;
alter table public.user_free_usage enable row level security;
alter table public.admin_roles enable row level security;
alter table public.payment_webhook_events enable row level security;
alter table public.admin_audit_logs enable row level security;

drop policy if exists "membership_plans_public_read" on public.membership_plans;
create policy "membership_plans_public_read" on public.membership_plans
  for select to anon,authenticated using (is_active or public.is_admin());
drop policy if exists "user_memberships_owner_read" on public.user_memberships;
create policy "user_memberships_owner_read" on public.user_memberships
  for select to authenticated using (user_id=auth.uid() or public.is_admin());
drop policy if exists "payment_transactions_owner_read" on public.payment_transactions;
create policy "payment_transactions_owner_read" on public.payment_transactions
  for select to authenticated using (user_id=auth.uid() or public.is_admin());
drop policy if exists "user_subscriptions_owner_read" on public.user_subscriptions;
create policy "user_subscriptions_owner_read" on public.user_subscriptions
  for select to authenticated using (user_id=auth.uid() or public.is_admin());
drop policy if exists "user_free_usage_owner_read" on public.user_free_usage;
create policy "user_free_usage_owner_read" on public.user_free_usage
  for select to authenticated using (user_id=auth.uid() or public.is_admin());
drop policy if exists "admin_roles_admin_read" on public.admin_roles;
create policy "admin_roles_admin_read" on public.admin_roles
  for select to authenticated using (public.is_admin());
drop policy if exists "payment_webhook_events_admin_read" on public.payment_webhook_events;
create policy "payment_webhook_events_admin_read" on public.payment_webhook_events
  for select to authenticated using (public.is_admin());
drop policy if exists "admin_audit_logs_admin_read" on public.admin_audit_logs;
create policy "admin_audit_logs_admin_read" on public.admin_audit_logs
  for select to authenticated using (public.is_admin());

revoke all on public.membership_plans,public.user_memberships,public.payment_transactions,
  public.user_subscriptions,
  public.user_free_usage,public.admin_roles,public.payment_webhook_events,public.admin_audit_logs
  from public,anon,authenticated;
grant select on public.membership_plans to anon,authenticated;
grant select on public.user_memberships,public.payment_transactions,public.user_subscriptions,public.user_free_usage,
  public.admin_roles,public.payment_webhook_events,public.admin_audit_logs to authenticated;

revoke update on public.profiles from public,anon,authenticated;
grant update (full_name,avatar_url,bio,city,state) on public.profiles to authenticated;

revoke all on function public.sync_admin_role() from public,anon,authenticated;
revoke all on function public.sync_profile_from_auth_user() from public,anon,authenticated;
revoke all on function public.audit_admin_content_change() from public,anon,authenticated;
revoke all on function public.activate_membership_from_payment(uuid,text,text,integer,timestamptz)
  from public,anon,authenticated;
grant execute on function public.activate_membership_from_payment(uuid,text,text,integer,timestamptz)
  to service_role;
revoke all on function public.store_razorpay_subscription(uuid,text) from public,anon,authenticated;
grant execute on function public.store_razorpay_subscription(uuid,text) to service_role;
revoke all on function public.record_subscription_charge(text,text,text,integer,timestamptz,timestamptz,timestamptz,text)
  from public,anon,authenticated;
grant execute on function public.record_subscription_charge(text,text,text,integer,timestamptz,timestamptz,timestamptz,text)
  to service_role;
revoke all on function public.record_subscription_status(text,text,timestamptz,timestamptz)
  from public,anon,authenticated;
grant execute on function public.record_subscription_status(text,text,timestamptz,timestamptz)
  to service_role;
revoke all on function public.record_subscription_failure(text,text,text,integer,text,text)
  from public,anon,authenticated;
grant execute on function public.record_subscription_failure(text,text,text,integer,text,text)
  to service_role;

revoke all on function public.get_my_membership_summary() from public,anon;
grant execute on function public.get_my_membership_summary() to authenticated;
revoke all on function public.create_membership_order_intent(text) from public,anon;
grant execute on function public.create_membership_order_intent(text) to authenticated;
revoke all on function public.submit_content_with_access(text,jsonb) from public,anon;
grant execute on function public.submit_content_with_access(text,jsonb) to authenticated;
revoke all on function public.admin_membership_overview() from public,anon;
grant execute on function public.admin_membership_overview() to authenticated;
revoke all on function public.admin_search_users(text,integer,integer) from public,anon;
grant execute on function public.admin_search_users(text,integer,integer) to authenticated;

insert into public.admin_audit_logs(actor_id,action,entity_type,entity_id,details)
values(
  null,'membership.migration_applied','database','membership-system',
  jsonb_build_object('existing_user_content_counted',true)
);

commit;
