-- Enable signed-in users to publish product deals and coupon offers immediately, with one optional product image.
-- Existing published deal rows and other content policies are preserved.
begin;

do $preflight$
begin
  if to_regclass('public.deals') is null then
    raise exception 'Required table public.deals is missing; run database/schema.sql first.';
  end if;
  if to_regprocedure('public.can_moderate()') is null then
    raise exception 'Expected public.can_moderate() function; run database/schema.sql first.';
  end if;
  if to_regclass('storage.buckets') is null or to_regclass('storage.objects') is null then
    raise exception 'Supabase Storage is unavailable; run database/schema.sql first.';
  end if;
end
$preflight$;

alter table public.deals add column if not exists user_id uuid references auth.users(id) on delete set null;
alter table public.deals add column if not exists offer_type text not null default 'product';
alter table public.deals add column if not exists merchant text;
alter table public.deals add column if not exists coupon_code text;
alter table public.deals enable row level security;

insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
values ('deal-images','deal-images',true,5242880,array['image/jpeg','image/png','image/webp'])
on conflict(id) do update set public=excluded.public,file_size_limit=excluded.file_size_limit,allowed_mime_types=excluded.allowed_mime_types;

do $offer_type_check$
begin
  if not exists (
    select 1 from pg_constraint
    where conname = 'deals_offer_type_check'
      and conrelid = 'public.deals'::regclass
  ) then
    alter table public.deals add constraint deals_offer_type_check
      check (offer_type in ('product','coupon'));
  end if;
end
$offer_type_check$;

drop policy if exists "community_offer_insert" on public.deals;
create policy "community_offer_insert" on public.deals for insert to authenticated with check (
  user_id = auth.uid()
  and status = 'published'
  and (
    (merchant = 'Amazon' and affiliate_url ~* '^https://([a-z0-9-]+\.)*(amazon\.in|amazon\.com|amzn\.to)(:[0-9]+)?(/|[?#]|$)')
    or (merchant = 'Flipkart' and affiliate_url ~* '^https://([a-z0-9-]+\.)*(flipkart\.com|fkrt\.it)(:[0-9]+)?(/|[?#]|$)')
    or (merchant = 'Meesho' and affiliate_url ~* '^https://([a-z0-9-]+\.)*meesho\.com(:[0-9]+)?(/|[?#]|$)')
    or (merchant = 'Website' and affiliate_url ~* '^https://([a-z0-9-]+\.)*[a-z0-9-]+\.[a-z]{2,}(:[0-9]+)?(/|[?#]|$)')
  )
  and (image_url is null or image_url ~* '^https://[^[:space:]]+$')
);

drop policy if exists "deal_images_public_read" on storage.objects;
create policy "deal_images_public_read" on storage.objects for select to anon, authenticated using (
  bucket_id = 'deal-images'
);
drop policy if exists "deal_images_owner_upload" on storage.objects;
create policy "deal_images_owner_upload" on storage.objects for insert to authenticated with check (
  bucket_id = 'deal-images'
  and (storage.foldername(name))[1] = auth.uid()::text
);
drop policy if exists "deal_images_owner_delete" on storage.objects;
create policy "deal_images_owner_delete" on storage.objects for delete to authenticated using (
  bucket_id = 'deal-images'
  and (storage.foldername(name))[1] = auth.uid()::text
);
drop policy if exists "moderators_delete_deal_images" on storage.objects;
create policy "moderators_delete_deal_images" on storage.objects for delete to authenticated using (
  bucket_id = 'deal-images' and public.can_moderate()
);

grant select on table public.deals to anon, authenticated;
grant insert, update, delete on table public.deals to authenticated;

commit;
