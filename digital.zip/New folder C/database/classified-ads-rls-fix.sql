-- Apply to an existing Supabase project to repair classified-ad submission RLS.
-- This migration preserves existing ad rows and never disables RLS.
begin;

do $preflight$
declare
  unexpected_policies text;
  missing_columns text;
begin
  if to_regclass('public.classified_ads') is null or to_regclass('public.ad_images') is null then
    raise exception 'Required table public.classified_ads or public.ad_images is missing.';
  end if;
  if to_regclass('storage.buckets') is null or to_regclass('storage.objects') is null then
    raise exception 'Supabase Storage tables are unavailable; no changes were made.';
  end if;
  if to_regprocedure('public.is_admin()') is null
    or to_regprocedure('public.can_moderate()') is null then
    raise exception 'Expected public.is_admin() and public.can_moderate() functions; no changes were made.';
  end if;
  if not exists (
    select 1 from pg_proc p
    where p.oid = to_regprocedure('public.is_admin()')
      and p.prosecdef and p.proconfig @> array['search_path=public']::text[]
  ) or not exists (
    select 1 from pg_proc p
    where p.oid = to_regprocedure('public.can_moderate()')
      and p.prosecdef and p.proconfig @> array['search_path=public']::text[]
  ) then
    raise exception 'Admin helpers must be SECURITY DEFINER with a fixed public search_path; no changes were made.';
  end if;

  select string_agg(required.column_name, ', ' order by required.column_name)
  into missing_columns
  from (values
    ('classified_ads','id'), ('classified_ads','user_id'), ('classified_ads','title'),
    ('classified_ads','slug'), ('classified_ads','category'), ('classified_ads','description'),
    ('classified_ads','price'), ('classified_ads','city'), ('classified_ads','state'),
    ('classified_ads','seller_name'), ('classified_ads','phone'), ('classified_ads','whatsapp'),
    ('classified_ads','website_url'), ('classified_ads','featured'), ('classified_ads','status'),
    ('ad_images','ad_id'), ('ad_images','user_id'), ('ad_images','image_url')
  ) as required(table_name, column_name)
  where not exists (
    select 1 from information_schema.columns c
    where c.table_schema = 'public'
      and c.table_name = required.table_name
      and c.column_name = required.column_name
  );
  if missing_columns is not null then
    raise exception 'Expected ad columns are missing: %; no changes were made.', missing_columns;
  end if;
  if not exists (
    select 1 from information_schema.columns
    where table_schema='public' and table_name='classified_ads'
      and column_name='user_id' and udt_name='uuid'
  ) or not exists (
    select 1 from information_schema.columns
    where table_schema='public' and table_name='classified_ads'
      and column_name='featured' and data_type='boolean'
  ) or not exists (
    select 1 from information_schema.columns
    where table_schema='public' and table_name='classified_ads'
      and column_name='status' and data_type in ('text','character varying')
  ) or not exists (
    select 1 from information_schema.columns
    where table_schema='public' and table_name='classified_ads'
      and column_name='website_url' and data_type in ('text','character varying')
  ) or not exists (
    select 1 from information_schema.columns
    where table_schema='public' and table_name='ad_images'
      and column_name='ad_id' and udt_name='uuid'
  ) or not exists (
    select 1 from information_schema.columns
    where table_schema='public' and table_name='ad_images'
      and column_name='user_id' and udt_name='uuid'
  ) or not exists (
    select 1 from information_schema.columns
    where table_schema='public' and table_name='ad_images'
      and column_name='image_url' and data_type in ('text','character varying')
  ) then
    raise exception 'An ad or image column has an unexpected type; no changes were made.';
  end if;
  if not exists (
    select 1 from storage.buckets
    where id='classified-images' and public
      and (file_size_limit is null or file_size_limit >= 5242880)
      and (allowed_mime_types is null
        or allowed_mime_types @> array['image/jpeg','image/png','image/webp'])
  ) then
    raise exception 'classified-images bucket must exist, be public, and permit JPG/PNG/WebP files up to 5 MB; no changes were made.';
  end if;

  select string_agg(policyname || ' (' || cmd || ')', ', ' order by policyname)
  into unexpected_policies
  from pg_policies
  where schemaname='public' and tablename='classified_ads'
    and policyname not in (
      'public_published','owner_insert','owner_update_pending','owner_delete',
      'owner_renew_expired','ad_owner_renew_or_moderator_update',
      'classified_ads_admin_update','classified_ads_admin_delete'
    );
  if unexpected_policies is not null then
    raise exception 'Unreviewed classified_ads policies found: %. Inspect them before migration; no changes were made.', unexpected_policies;
  end if;

  select string_agg(policyname || ' (' || cmd || ')', ', ' order by policyname)
  into unexpected_policies
  from pg_policies
  where schemaname='public' and tablename='ad_images'
    and policyname not in (
      'images_public_read','images_owner_insert','images_owner_delete','images_admin_delete'
    );
  if unexpected_policies is not null then
    raise exception 'Unreviewed ad_images policies found: %. Inspect them before migration; no changes were made.', unexpected_policies;
  end if;

  select string_agg(i.indexrelid::regclass::text, ', ' order by i.indexrelid::regclass::text)
  into unexpected_policies
  from pg_index i
  join pg_attribute a
    on a.attrelid = i.indrelid and a.attnum = any(i.indkey)
  where i.indrelid = 'public.classified_ads'::regclass
    and i.indisunique and not i.indisprimary
    and not (
      i.indnatts = 1 and a.attname = 'slug'
    );
  if unexpected_policies is not null then
    raise exception 'Unexpected unique index(es) may block duplicate ad submissions: %. Review before migration; no changes were made.', unexpected_policies;
  end if;
  select string_agg(i.indexrelid::regclass::text, ', ' order by i.indexrelid::regclass::text)
  into unexpected_policies
  from pg_index i
  where i.indrelid = 'public.ad_images'::regclass
    and i.indisunique and not i.indisprimary;
  if unexpected_policies is not null then
    raise exception 'Unique image index(es) would block duplicate ad images: %. Review before migration; no changes were made.', unexpected_policies;
  end if;

  select string_agg(policyname, ', ' order by policyname)
  into unexpected_policies
  from pg_policies
  where schemaname='storage' and tablename='objects'
    and permissive='RESTRICTIVE' and cmd in ('INSERT','ALL')
    and roles && array['anon'::name,'authenticated'::name,'public'::name];
  if unexpected_policies is not null then
    raise exception 'Restrictive Storage insert policies found: %. Inspect them before migration; no changes were made.', unexpected_policies;
  end if;

  select string_agg(policyname || ' (' || cmd || ')', ', ' order by policyname)
  into unexpected_policies
  from pg_policies
  where schemaname='storage' and tablename='objects'
    and cmd in ('INSERT','ALL')
    and roles && array['anon'::name,'authenticated'::name,'public'::name]
    and policyname not in ('public_upload_classified_images','users_upload_own_images');
  if unexpected_policies is not null then
    raise exception 'Unreviewed Storage upload policies found: %. Inspect them before migration; no changes were made.', unexpected_policies;
  end if;
end
$preflight$;

alter table public.classified_ads enable row level security;
alter table public.classified_ads alter column user_id drop not null;
alter table public.classified_ads alter column status set default 'published';
alter table public.classified_ads alter column featured set default false;

drop policy if exists "public_published" on public.classified_ads;
create policy "public_published" on public.classified_ads for select to anon, authenticated
  using (status = 'published' or user_id = auth.uid() or public.can_moderate());

drop policy if exists "owner_insert" on public.classified_ads;
create policy "owner_insert" on public.classified_ads for insert to anon, authenticated
  with check (
    status = 'published'
    and featured = false
    and (user_id is null or user_id = auth.uid())
  );

drop policy if exists "owner_update_pending" on public.classified_ads;
drop policy if exists "owner_renew_expired" on public.classified_ads;
drop policy if exists "ad_owner_renew_or_moderator_update" on public.classified_ads;
drop policy if exists "classified_ads_admin_update" on public.classified_ads;
create policy "classified_ads_admin_update" on public.classified_ads for update to authenticated
  using (public.is_admin())
  with check (public.is_admin());

drop policy if exists "owner_delete" on public.classified_ads;
drop policy if exists "classified_ads_admin_delete" on public.classified_ads;
create policy "classified_ads_admin_delete" on public.classified_ads for delete to authenticated
  using (public.is_admin());

revoke update, delete on table public.classified_ads from public, anon;
do $revoke_anon_column_updates$
declare
  column_names text;
begin
  select string_agg(format('%I', attname), ', ' order by attnum)
  into column_names
  from pg_attribute
  where attrelid='public.classified_ads'::regclass
    and attnum > 0 and not attisdropped;
  execute format(
    'revoke update (%s) on table public.classified_ads from public, anon',
    column_names
  );
end
$revoke_anon_column_updates$;
grant select, insert on table public.classified_ads to anon, authenticated;
grant update, delete on table public.classified_ads to authenticated;

alter table public.ad_images enable row level security;
alter table public.ad_images alter column user_id drop not null;

drop policy if exists "images_public_read" on public.ad_images;
create policy "images_public_read" on public.ad_images for select to anon, authenticated
  using (
    exists(select 1 from public.classified_ads a where a.id = ad_id and a.status = 'published')
    or user_id = auth.uid()
    or public.can_moderate()
  );

drop policy if exists "images_owner_insert" on public.ad_images;
create policy "images_owner_insert" on public.ad_images for insert to anon, authenticated
  with check (
    (user_id is null and exists(
      select 1 from public.classified_ads a where a.id = ad_id and a.status = 'published'
    ))
    or (user_id = auth.uid() and exists(
      select 1 from public.classified_ads a
      where a.id = ad_id and a.user_id = auth.uid() and a.status = 'published'
    ))
  );
grant select, insert on table public.ad_images to anon, authenticated;

drop policy if exists "public_upload_classified_images" on storage.objects;
create policy "public_upload_classified_images" on storage.objects for insert to anon, authenticated
  with check (
    bucket_id = 'classified-images'
    and (storage.foldername(name))[1] = 'ads'
    and exists(
      select 1 from public.classified_ads a
      where a.id::text = (storage.foldername(name))[2] and a.status = 'published'
    )
  );

drop policy if exists "admins_delete_classified_images" on storage.objects;
create policy "admins_delete_classified_images" on storage.objects for delete to authenticated
  using (bucket_id = 'classified-images' and public.is_admin());

commit;
