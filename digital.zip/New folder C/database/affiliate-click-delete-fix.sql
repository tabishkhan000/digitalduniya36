-- Apply to an existing Supabase project to let deals and coupons be deleted.
-- Associated click records are deleted with their offer to preserve the XOR check.
begin;

do $preflight$
begin
  if to_regclass('public.affiliate_clicks') is null
    or to_regclass('public.deals') is null
    or to_regclass('public.coupons') is null then
    raise exception 'Required affiliate_clicks, deals, or coupons table is missing; run database/schema.sql first.';
  end if;
end
$preflight$;

alter table public.affiliate_clicks
  drop constraint if exists affiliate_clicks_deal_id_fkey,
  add constraint affiliate_clicks_deal_id_fkey
    foreign key (deal_id) references public.deals(id) on delete cascade;

alter table public.affiliate_clicks
  drop constraint if exists affiliate_clicks_coupon_id_fkey,
  add constraint affiliate_clicks_coupon_id_fkey
    foreign key (coupon_id) references public.coupons(id) on delete cascade;

commit;
