import { getSupabase, getUser } from "./supabase.js";
import { SUPABASE_URL } from "./config.js";

export async function checkModeratorAccess() {
  const supabase = await getSupabase();
  if (!supabase) throw new Error("Supabase isn't configured.");
  const { data, error } = await supabase.rpc("can_moderate");
  if (error) throw error;
  const { data: isAdmin, error: adminError } = await supabase.rpc("is_admin");
  if (adminError) throw adminError;
  return { allowed: Boolean(data), isAdmin: Boolean(isAdmin), user: await getUser() };
}

export async function moderateRecord(table, id, status) {
  const supabase = await getSupabase();
  if (!supabase) throw new Error("Supabase isn't configured.");
  const update = { status };
  if (table === "news_articles" && status === "published") {
    update.verified = true;
    update.published_at = new Date().toISOString();
  }
  if (table === "blog_posts" && status === "published") update.published_at = new Date().toISOString();
  const { error } = await supabase.from(table).update(update).eq("id", id);
  if (error) throw error;
}

export async function deleteModeratedRecord(table, id) {
  const supabase = await getSupabase();
  if (!supabase) throw new Error("Supabase isn't configured.");
  if (table === "deals") {
    const { data: deal, error } = await supabase.from("deals").select("image_url").eq("id", id).maybeSingle();
    if (error) throw error;
    const publicPrefix = `${SUPABASE_URL.replace(/\/$/, "")}/storage/v1/object/public/deal-images/`;
    if (deal?.image_url?.startsWith(publicPrefix)) {
      const path = deal.image_url.slice(publicPrefix.length);
      const { error: storageError } = await supabase.storage.from("deal-images").remove([path]);
      if (storageError) throw storageError;
    }
  }
  if (table === "classified_ads") {
    const { data: images, error: imageError } = await supabase.from("ad_images")
      .select("image_url").eq("ad_id", id);
    if (imageError) throw imageError;
    const publicPrefix = `${SUPABASE_URL.replace(/\/$/, "")}/storage/v1/object/public/classified-images/`;
    const paths = (images || []).flatMap(({ image_url }) => {
      if (!image_url.startsWith(publicPrefix)) return [];
      const path = image_url.slice(publicPrefix.length);
      const parts = path.split("/");
      const isAdImage = (parts[0] === "ads" && parts[1] === id) || (parts.length > 2 && parts[1] === id);
      return isAdImage ? [path] : [];
    });
    if (paths.length) {
      const { error: storageError } = await supabase.storage.from("classified-images").remove(paths);
      if (storageError) throw storageError;
    }
  }
  const { error } = await supabase.from(table).delete().eq("id", id);
  if (error) throw error;
}

export async function createModeratedRecord(table, values) {
  const supabase = await getSupabase();
  if (!supabase) throw new Error("Supabase isn't configured.");
  const { error } = await supabase.from(table).insert({ ...values, status: "pending" });
  if (error) throw error;
}

export async function grantUserRole(userId, role) {
  const supabase = await getSupabase();
  if (!supabase) throw new Error("Supabase isn't configured.");
  const { error } = await supabase.from("user_roles").insert({ user_id: userId, role });
  if (error) throw error;
}

export async function revokeUserRole(roleId) {
  const supabase = await getSupabase();
  if (!supabase) throw new Error("Supabase isn't configured.");
  const { error } = await supabase.from("user_roles").delete().eq("id", roleId);
  if (error) throw error;
}
