import { checkSupabaseConnection } from "./supabase.js";

export async function initializeConnectionStatus() {
  const status = document.querySelector("#connection-status");
  if (!status) return;
  status.dataset.state = "checking";
  status.textContent = "Checking Supabase…";
  status.setAttribute("aria-live", "polite");
  const result = await checkSupabaseConnection();
  status.dataset.state = result.databaseReady ? "connected" : result.connected ? "schema-missing" : "disconnected";
  status.textContent = result.databaseReady
    ? "Supabase connected"
    : result.connected
      ? "Supabase reachable · setup needed"
      : "Supabase connection unavailable";
  status.title = result.message;
  status.setAttribute("aria-label", result.message);
  return result;
}

export function watchNetworkStatus() {
  window.addEventListener("online", initializeConnectionStatus);
  window.addEventListener("offline", () => {
    const status = document.querySelector("#connection-status");
    if (!status) return;
    status.dataset.state = "disconnected";
    status.textContent = "Offline";
    status.title = "Your browser is offline.";
  });
}
