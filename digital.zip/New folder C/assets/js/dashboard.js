import { getSupabase, updateOwnProfile, uploadOwnedImage } from "./supabase.js";

const OWNED_TABLES = [
  ["Blogs","blog_posts"],["Ads","classified_ads"],["Businesses","businesses"],
  ["Jobs","jobs"],["Comments","blog_comments"],["Reviews","business_reviews"]
];

export async function loadOwnSubmissions(userId) {
  const supabase = await getSupabase();
  if (!supabase) throw new Error("Supabase isn't configured.");
  const groups = await Promise.all(OWNED_TABLES.map(async ([name, table]) => {
    const { data, error } = await supabase.from(table).select("*")
      .eq("user_id", userId).order("created_at", { ascending: false }).limit(50);
    if (error) throw error;
    return { name, table, rows: data || [] };
  }));
  return groups.flatMap(group => group.rows.map(row => ({ ...row, _table: group.table, _name: group.name })));
}

export async function saveProfile(userId, values, avatar) {
  const profile = { ...values };
  if (avatar) {
    const upload = await uploadOwnedImage("user-avatars", avatar);
    profile.avatar_url = upload.url;
  }
  return updateOwnProfile(userId, profile);
}

export async function removeOwnSubmission(userId, table, id) {
  const supabase = await getSupabase();
  if (!supabase) throw new Error("Supabase isn't configured.");
  const { error } = await supabase.from(table).delete().eq("id", id).eq("user_id", userId);
  if (error) throw error;
}

export async function changeOwnPassword(password) {
  const supabase = await getSupabase();
  if (!supabase) throw new Error("Supabase isn't configured.");
  const { error } = await supabase.auth.updateUser({ password });
  if (error) throw error;
}
