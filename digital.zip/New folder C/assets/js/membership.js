import { getProfile, getSupabase, getUser } from "./supabase.js";
import { escapeHtml, formatDate, setPageTitle, showToast } from "./shared.js";

const categoryLabels = {
  classified_ads: "Classified ads",
  blog_posts: "Blog posts",
  jobs: "Job listings",
  businesses: "Business listings",
  deals: "Product deals",
  coupons: "Coupons",
  community_questions: "Community questions",
  community_answers: "Community answers",
  blog_comments: "Blog comments",
  business_reviews: "Business reviews"
};

function money(paise) {
  const amount = Number(paise || 0) / 100;
  return `₹${amount.toLocaleString("en-IN", { minimumFractionDigits: 0, maximumFractionDigits: 2 })}`;
}

function dateTime(value) {
  if (!value) return "Not available";
  return new Intl.DateTimeFormat("en-IN", {
    dateStyle: "medium",
    timeStyle: "short"
  }).format(new Date(value));
}

function messageHtml(message, type = "info") {
  return `<div class="notice notice-${type}" role="status">${escapeHtml(message)}</div>`;
}

async function loadSummary(supabase) {
  const { data, error } = await supabase.rpc("get_my_membership_summary");
  if (error) throw error;
  if (!data || typeof data !== "object") throw new Error("Membership information could not be loaded.");
  return data;
}

function introCountdown(summary, targets) {
  const expiry = new Date(summary.intro_offer_expires_at).getTime();
  const serverNow = new Date(summary.server_now).getTime();
  if (!Number.isFinite(expiry) || !Number.isFinite(serverNow)) return;
  const localStart = Date.now();
  const update = () => {
    if (targets.every(target => !target.isConnected)) {
      clearInterval(timer);
      return;
    }
    const remaining = expiry - serverNow - (Date.now() - localStart);
    if (remaining <= 0) {
      targets.forEach(target => {
        target.textContent = "Introductory offer expired. Refreshing plans…";
      });
      clearInterval(timer);
      const app = targets.find(target => target.isConnected)?.closest("#app");
      loadSummaryFromPage(app).catch(error => {
        targets.forEach(target => {
          target.textContent = error.message;
        });
      });
      return;
    }
    const hours = Math.floor(remaining / 3_600_000);
    const minutes = Math.floor((remaining % 3_600_000) / 60_000);
    const seconds = Math.floor((remaining % 60_000) / 1_000);
    const text = `${hours}h ${minutes}m ${seconds}s remaining`;
    targets.forEach(target => {
      target.textContent = text;
    });
  };
  let timer;
  update();
  timer = setInterval(update, 1000);
}

async function loadSummaryFromPage(app) {
  if (!app) return;
  const supabase = await getSupabase();
  const user = await getUser();
  if (!supabase || !user) return;
  const summary = await loadSummary(supabase);
  renderPricingContent(app, user, summary);
}

export async function renderMembershipPricing(app) {
  setPageTitle("Membership plans", "Choose a DigitalDuniya360 membership for posting access.");
  app.innerHTML = `<section class="page-hero"><div class="container"><span class="eyebrow">Membership</span><h1>More room to share.</h1><p>Your first submission in each category is free. Membership lets you submit more while it is active.</p></div></section><section class="section"><div class="container" id="pricing-content">${messageHtml("Loading your plans…")}</div></section>`;
  try {
    const [supabase, user] = await Promise.all([getSupabase(), getUser()]);
    const summary = supabase && user ? await loadSummary(supabase) : null;
    renderPricingContent(app, user, summary);
  } catch (error) {
    app.querySelector("#pricing-content").innerHTML = messageHtml(error.message, "error");
  }
}

function renderPricingContent(app, user, summary) {
  const root = app.querySelector("#pricing-content");
  if (!root) return;
  const plans = summary?.plans || [
    { code: "intro-60d", name: "Introductory Membership", amount_paise: 900, duration_days: 60, is_introductory: true },
    { code: "standard-monthly-12", name: "Standard Monthly Membership", amount_paise: 49900, duration_days: 30, billing_type: "subscription", billing_cycles: 12, is_introductory: false }
  ];
  const introEligible = Boolean(summary?.intro_offer_eligible);
  const introWindowOpen = Boolean(summary?.intro_offer_expires_at && summary?.server_now
    && new Date(summary.server_now) < new Date(summary.intro_offer_expires_at));
  const introLocked = Boolean(user && introWindowOpen);
  const active = summary?.active_membership;
  const activeSubscription = (summary?.subscriptions || []).find(subscription =>
    !["cancelled", "completed", "expired"].includes(subscription.status)
    && (!subscription.current_period_end || new Date(subscription.current_period_end) > new Date(summary.server_now))
  );
  const introPlan = plans.find(plan => plan.code === "intro-60d");
  const standardPlan = plans.find(plan => plan.code === "standard-monthly-12");
  const card = (plan, eligible, extra = "") => {
    if (!plan) return "";
    const isRecurring = plan.billing_type === "subscription";
    const resumeSubscription = isRecurring && activeSubscription?.status === "created";
    const alreadySubscribed = isRecurring && activeSubscription && !resumeSubscription;
    const available = Boolean(user) && eligible && plan.is_active !== false && !alreadySubscribed;
    const amount = money(plan.amount_paise);
    const duration = isRecurring ? " / month" : ` / ${plan.duration_days} days`;
    const validity = isRecurring
      ? `Billed monthly for up to ${plan.billing_cycles} cycles. Cancel future renewals at any time.`
      : `Valid for ${plan.duration_days} days from its server-recorded start date.`;
    return `<article class="membership-card ${plan.is_introductory ? "membership-card-intro" : ""}">
      <span class="eyebrow">${plan.is_introductory ? "First 72 hours only" : "Recurring subscription"}</span>
      <h2>${escapeHtml(plan.name)}</h2>
      <p class="membership-price">${amount}<span>${duration}</span></p>
      <p>${plan.is_introductory ? "One purchase per account. The offer is calculated from your registration time." : `Available after the introductory 72-hour window. ${validity}`}</p>
      <ul><li>Submit in categories after your one free submission</li><li>${escapeHtml(validity)}</li><li>${isRecurring ? "Razorpay charges automatically each billing cycle until cancelled or all cycles complete." : "One-time payment; no recurring charge."}</li></ul>
      ${extra}
      ${!user
        ? `<a class="button" href="/register.html?next=%2Fpricing">Create an account to check eligibility</a>`
        : available
        ? `<button class="button" type="button" data-buy-plan="${escapeHtml(plan.code)}">${resumeSubscription ? "Continue setup" : isRecurring ? "Start subscription" : active ? "Renew membership" : "Choose plan"} · ${amount}</button>`
        : `<button class="button button-outline" type="button" disabled>${plan.is_active === false ? "Temporarily unavailable" : alreadySubscribed ? "Subscription already active" : plan.is_introductory ? "Offer not available" : introLocked ? "Available after the 72-hour offer" : "Not available yet"}</button>`}
    </article>`;
  };

  root.innerHTML = `${active ? messageHtml(`Active: ${active.plan_name} until ${dateTime(active.expires_at)}.`, "success") : ""}
    ${user && summary?.intro_offer_eligible ? `<div class="membership-countdown"><strong>Your introductory offer</strong><span id="intro-countdown"></span></div>` : ""}
    ${user && !summary?.intro_offer_eligible && summary?.registered_at
      ? `<p class="membership-registration">Registered ${dateTime(summary.registered_at)}. ${summary?.intro_offer_expires_at ? `Intro offer deadline: ${dateTime(summary.intro_offer_expires_at)}.` : ""}</p>`
      : ""}
    ${user ? "" : messageHtml("Sign in or register to see your personal 72-hour introductory eligibility. The server checks your registration timestamp at checkout.")}
    <div class="membership-grid">
      ${card(introPlan, introEligible, introEligible ? `<p class="membership-countdown-inline">Offer expires in <span id="intro-countdown-inline"></span></p>` : "")}
      ${card(standardPlan, Boolean(summary && !introWindowOpen), introLocked ? `<p class="membership-locked-note">Available when your personal introductory window ends.</p>` : "")}
    </div>
    ${activeSubscription ? messageHtml(`Your ${activeSubscription.plan_name || "monthly"} subscription is ${activeSubscription.status}${activeSubscription.cancel_at_cycle_end ? ` and ends ${dateTime(activeSubscription.current_period_end)}` : ""}.`, "info") : ""}
    <div class="membership-security"><span aria-hidden="true">🔒</span> Payments are processed by Razorpay. Membership activates only after backend verification. The ₹9 introductory plan is one-time; the ₹499 monthly subscription renews automatically until cancelled or all 12 cycles complete.</div>
    <div class="form-message membership-payment-message" id="pricing-message" aria-live="polite"></div>
    <p class="membership-fineprint">One free submission is available per category. Existing submissions are counted as used credits. Free credits do not reset when a membership expires.</p>`;

  if (summary?.intro_offer_eligible) {
    const countdowns = [...root.querySelectorAll("#intro-countdown, #intro-countdown-inline")];
    if (countdowns.length) introCountdown(summary, countdowns);
  }
  root.querySelectorAll("[data-buy-plan]").forEach(button => button.addEventListener("click", () => startCheckout(button.dataset.buyPlan, button)));
}

async function loadRazorpayCheckout() {
  if (window.Razorpay) return;
  await new Promise((resolve, reject) => {
    const existing = document.querySelector('script[data-razorpay-checkout]');
    if (existing) {
      existing.addEventListener("load", () => resolve(), { once: true });
      existing.addEventListener("error", () => reject(new Error("Razorpay Checkout could not be loaded.")), { once: true });
      return;
    }
    const script = document.createElement("script");
    script.src = "https://checkout.razorpay.com/v1/checkout.js";
    script.async = true;
    script.dataset.razorpayCheckout = "true";
    script.onload = () => resolve();
    script.onerror = () => {
      script.remove();
      reject(new Error("Razorpay Checkout could not be loaded."));
    };
    document.head.append(script);
  });
  if (!window.Razorpay) throw new Error("Razorpay Checkout is unavailable in this browser.");
}

async function paymentFunction(supabase, body) {
  const { data, error } = await supabase.functions.invoke("membership-payment", { body });
  if (error) {
    const response = error.context instanceof Response ? await error.context.clone().json().catch(() => null) : null;
    throw new Error(response?.error || error.message || "Payment request failed.");
  }
  return data;
}

async function startCheckout(planCode, button) {
  const message = document.querySelector("#pricing-message") || document.querySelector("#account-payment-message");
  if (!message) return;
  const supabase = await getSupabase();
  const user = await getUser();
  if (!supabase || !user) {
    location.href = "/login.html?next=%2Fpricing";
    return;
  }
  button.disabled = true;
  message.textContent = "Preparing a secure payment…";
  message.className = "form-message";
  try {
    const order = await paymentFunction(supabase, { action: "create-order", planCode });
    await loadRazorpayCheckout();
    const isSubscription = Boolean(order.subscription_id);
    let responseHandled = false;
    const checkout = new window.Razorpay({
      key: order.key_id,
      ...(isSubscription
        ? { subscription_id: order.subscription_id }
        : { order_id: order.order_id, amount: order.amount_paise, currency: "INR" }),
      name: "DigitalDuniya360",
      description: isSubscription
        ? `${order.plan_name} · ${money(order.amount_paise)} monthly, up to ${order.billing_cycles} cycles`
        : `${order.plan_name} · 60 days`,
      prefill: {
        email: user.email || "",
        name: user.user_metadata?.full_name || ""
      },
      theme: { color: "#d65a24" },
      handler: async payment => {
        responseHandled = true;
        message.textContent = "Verifying the captured payment with our server…";
        try {
          const result = await paymentFunction(supabase, {
            action: isSubscription ? "verify-subscription" : "verify-payment",
            transactionId: order.transaction_id,
            ...(isSubscription
              ? { razorpay_subscription_id: payment.razorpay_subscription_id, razorpay_payment_id: payment.razorpay_payment_id, razorpay_signature: payment.razorpay_signature }
              : { razorpay_order_id: payment.razorpay_order_id, razorpay_payment_id: payment.razorpay_payment_id, razorpay_signature: payment.razorpay_signature })
          });
          if (result?.status === "paid") {
            message.textContent = isSubscription
              ? "Subscription payment verified. Your membership is active."
              : "Payment verified. Your membership is active.";
            message.className = "form-message form-success";
            showToast("Membership activated.");
            if (location.pathname.startsWith("/pricing")) {
              await loadSummaryFromPage(document.querySelector("#app"));
            } else {
              await renderMyAccount(document.querySelector("#app"));
            }
          } else if (result?.status === "failed") {
            message.textContent = "Razorpay reports that the payment failed. No membership was activated.";
            message.className = "form-message form-error";
          } else {
            message.textContent = isSubscription
              ? "Subscription authorization is being confirmed. Membership appears after Razorpay confirms the first captured payment."
              : "Payment is pending capture verification. Your membership will appear after Razorpay confirms it.";
            message.className = "form-message";
          }
        } catch (error) {
          message.textContent = `${error.message} Your payment is not treated as active until server verification succeeds.`;
          message.className = "form-message form-error";
        } finally {
          button.disabled = false;
        }
      },
      modal: {
        ondismiss: async () => {
          if (!responseHandled) {
            if (isSubscription) {
              message.textContent = "Checkout was closed. If you authorized the subscription, it will appear here after Razorpay confirms it.";
            } else try {
              await paymentFunction(supabase, { action: "cancel-order", transactionId: order.transaction_id });
              message.textContent = "Checkout was closed. No membership was activated.";
            } catch (error) {
              message.textContent = `Checkout closed, but its status could not be updated: ${error.message}`;
              message.className = "form-message form-error";
            }
          }
          button.disabled = false;
        }
      }
    });
    checkout.on("payment.failed", async response => {
      responseHandled = true;
      const failure = response?.error || {};
      if (isSubscription) {
        message.textContent = "The subscription payment did not complete. Razorpay will report its final status; no membership was activated unless payment is verified.";
        message.className = "form-message form-error";
        button.disabled = false;
        return;
      }
      try {
        await paymentFunction(supabase, {
          action: "payment-failed",
          transactionId: order.transaction_id,
          failureCode: failure.code || "checkout_failed",
          failureDescription: failure.description || "Payment was not completed."
        });
        message.textContent = "Payment failed. No membership was activated; you may try again.";
        message.className = "form-message form-error";
      } catch (error) {
        message.textContent = `Payment failed, but its status could not be updated: ${error.message}`;
        message.className = "form-message form-error";
      } finally {
        button.disabled = false;
      }
    });
    checkout.open();
  } catch (error) {
    message.textContent = error.message;
    message.className = "form-message form-error";
    button.disabled = false;
  }
}

export async function renderMyAccount(app) {
  setPageTitle("My account", "View your membership, posting credits and payment history.");
  app.innerHTML = `<section class="page-hero"><div class="container"><span class="eyebrow">My account</span><h1>Your membership and credits.</h1></div></section><section class="section"><div class="container" id="account-content">${messageHtml("Loading account…")}</div></section>`;
  try {
    const user = await getUser();
    if (!user) {
      app.querySelector("#account-content").innerHTML = messageHtml("Sign in to view your account.", "info") + `<a class="button" href="/login.html?next=%2Fmy-account">Log in</a>`;
      return;
    }
    const supabase = await getSupabase();
    if (!supabase) throw new Error("Supabase is not configured.");
    const [summary, profile] = await Promise.all([loadSummary(supabase), getProfile(user.id)]);
    renderAccountContent(app, user, profile, summary);
  } catch (error) {
    app.querySelector("#account-content").innerHTML = messageHtml(error.message, "error");
  }
}

function renderAccountContent(app, user, profile, summary) {
  const root = app.querySelector("#account-content");
  const active = summary.active_membership;
  const subscription = (summary.subscriptions || []).find(item =>
    !["cancelled", "completed", "expired"].includes(item.status)
    && (!item.current_period_end || new Date(item.current_period_end) > new Date(summary.server_now))
  );
  const used = new Set((summary.free_usage || []).filter(item => item.used).map(item => item.category));
  const credits = (summary.free_usage || []).map(item => `<tr><td>${escapeHtml(categoryLabels[item.category] || item.category)}</td><td>${item.used ? "Used" : "1 free submission available"}</td><td>${item.first_used_at ? dateTime(item.first_used_at) : "—"}</td></tr>`).join("");
  const payments = (summary.payment_history || []).map(item => `<tr><td>${escapeHtml(item.plan_name)}</td><td>${money(item.amount_paise)}</td><td><span class="pill">${escapeHtml(item.status)}</span></td><td>${dateTime(item.created_at)}</td><td>${item.paid_at ? dateTime(item.paid_at) : "—"}</td></tr>`).join("");
  const history = (summary.membership_history || []).map(item => `<tr><td>${escapeHtml(item.plan_name)}</td><td>${money(item.amount_paise)}</td><td><span class="pill">${escapeHtml(item.status)}</span></td><td>${dateTime(item.starts_at)}</td><td>${dateTime(item.expires_at)}</td></tr>`).join("");
  const needsUpgrade = !active && used.size > 0;
  const standardAvailable = summary.server_now && summary.intro_offer_expires_at
    && new Date(summary.server_now) >= new Date(summary.intro_offer_expires_at);
  root.innerHTML = `<div class="dashboard-panel account-profile"><h2>Profile</h2><p><strong>${escapeHtml(profile?.full_name || user.user_metadata?.full_name || "Member")}</strong> · ${escapeHtml(user.email || "")}</p><p>Registered ${dateTime(summary.registered_at)}</p><a class="button button-outline button-small" href="/user-dashboard.html">Manage profile and submissions</a></div>
    <div class="dashboard-panel"><h2>Membership status</h2>
      ${active
        ? `<p><strong>${escapeHtml(active.plan_name)}</strong> · Active</p><p>Started: ${dateTime(active.starts_at)}</p><p>Expires: ${dateTime(active.expires_at)}</p>`
        : `<p>No active paid membership. Free credits remain available for categories not yet used.</p>${needsUpgrade ? `<a class="button" href="/pricing">Upgrade membership</a>` : ""}`}
      ${subscription
        ? `<p>Recurring plan: ${escapeHtml(subscription.plan_name)} · ${escapeHtml(subscription.status)}${subscription.current_period_end ? ` through ${dateTime(subscription.current_period_end)}` : ""}.</p>${subscription.cancel_at_cycle_end
          ? `<p>Automatic renewal is cancelled. Membership access remains available until the current paid period ends.</p>`
          : subscription.status === "created"
            ? `<button class="button" type="button" data-buy-plan="standard-monthly-12">Continue subscription setup · ₹499/month</button> <button class="button button-outline" type="button" data-cancel-subscription="${escapeHtml(subscription.razorpay_subscription_id)}">Cancel setup</button>`
            : `<button class="button button-outline" type="button" data-cancel-subscription="${escapeHtml(subscription.razorpay_subscription_id)}">Cancel future renewals</button>`}`
        : standardAvailable
          ? `<button class="button" type="button" data-buy-plan="standard-monthly-12">Start ₹499/month subscription</button>`
          : `<p>The monthly subscription becomes available after your personal 72-hour introductory window ends.</p>`}
      <p>Introductory offer: ${summary.intro_offer_eligible ? `Eligible until ${dateTime(summary.intro_offer_expires_at)}` : `Not eligible. ${dateTime(summary.intro_offer_expires_at)}`}</p>
      <p>The ₹499 plan renews automatically each month for up to 12 cycles unless cancelled. Cancellation stops future cycles; it does not remove access already paid for.</p>
      <a class="button button-outline button-small" href="/pricing">View membership plans</a>
    </div>
    <div class="dashboard-panel"><h2>Free posting credits</h2><p>Credits persist across devices and do not reset after membership expiry.</p><div class="table-wrap"><table class="data-table"><thead><tr><th>Category</th><th>Credit</th><th>First used</th></tr></thead><tbody>${credits}</tbody></table></div></div>
    <div class="dashboard-panel"><h2>Membership history</h2><div class="table-wrap">${history ? `<table class="data-table"><thead><tr><th>Plan</th><th>Paid</th><th>Status</th><th>Starts</th><th>Expires</th></tr></thead><tbody>${history}</tbody></table>` : "<p>No membership history yet.</p>"}</div></div>
    <div class="dashboard-panel"><h2>Payment history</h2><div class="table-wrap">${payments ? `<table class="data-table"><thead><tr><th>Plan</th><th>Amount</th><th>Status</th><th>Created</th><th>Paid</th></tr></thead><tbody>${payments}</tbody></table>` : "<p>No payment transactions yet.</p>"}</div></div>
    <div id="account-payment-message" class="form-message" aria-live="polite"></div>
    <div class="dashboard-panel"><button class="button button-outline button-small" id="account-logout" type="button">Log out</button></div>`;
  root.querySelector("#account-logout").addEventListener("click", async () => {
    const supabase = await getSupabase();
    const { error } = await supabase.auth.signOut();
    if (error) showToast(error.message, "error");
    else location.href = "/";
  });
  root.querySelectorAll("[data-buy-plan]").forEach(button => button.addEventListener("click", () => startCheckout(button.dataset.buyPlan, button)));
  root.querySelectorAll("[data-cancel-subscription]").forEach(button => button.addEventListener("click", async () => {
    button.disabled = true;
    try {
      const supabase = await getSupabase();
      const result = await paymentFunction(supabase, {
        action: "cancel-subscription",
        subscriptionId: button.dataset.cancelSubscription
      });
      showToast(result.cancel_at_cycle_end
        ? `Future renewals cancelled. Access continues until ${dateTime(result.current_period_end)}.`
        : "Subscription cancelled.");
      await renderMyAccount(app);
    } catch (error) {
      button.disabled = false;
      showToast(error.message || "Subscription cancellation failed.", "error");
    }
  }));
}

export async function renderAdminLogin(app) {
  setPageTitle("Admin Login", "Authorized DigitalDuniya360 administrators only.");
  app.innerHTML = `<section class="auth-wrap"><form class="auth-card" id="admin-login-form"><span class="eyebrow">Restricted access</span><h1>Admin Login</h1><p>Sign in with an existing administrator account. There is no public admin registration.</p><div class="field"><label for="admin-email">Admin email</label><input id="admin-email" name="email" type="email" autocomplete="username" required></div><div class="field"><label for="admin-password">Password</label><input id="admin-password" name="password" type="password" autocomplete="current-password" required></div><button class="button" type="submit">Sign in securely</button><div class="form-message" aria-live="polite"></div></form></section>`;
  const form = app.querySelector("#admin-login-form");
  form.addEventListener("submit", async event => {
    event.preventDefault();
    const button = form.querySelector("button");
    const message = form.querySelector(".form-message");
    button.disabled = true;
    message.textContent = "Checking administrator access…";
    message.className = "form-message";
    try {
      const supabase = await getSupabase();
      if (!supabase) throw new Error("Supabase is not configured.");
      const values = Object.fromEntries(new FormData(form));
      const { error } = await supabase.auth.signInWithPassword({
        email: String(values.email).trim(),
        password: String(values.password)
      });
      if (error) throw error;
      const { data, error: roleError } = await supabase.rpc("is_admin");
      if (roleError) throw roleError;
      if (!data) {
        await supabase.auth.signOut();
        throw new Error("Sign-in failed or this account is not authorized.");
      }
      location.href = "/admin/";
    } catch (error) {
      message.textContent = error.message || "Sign-in failed or this account is not authorized.";
      message.classList.add("form-error");
    } finally {
      button.disabled = false;
    }
  });
}

async function adminApi(body) {
  const supabase = await getSupabase();
  if (!supabase) throw new Error("Supabase is not configured.");
  const { data, error } = await supabase.functions.invoke("admin-console", { body });
  if (error) {
    const response = error.context instanceof Response ? await error.context.clone().json().catch(() => null) : null;
    throw new Error(response?.error || error.message || "Administrator request failed.");
  }
  return data;
}

function csvDownload(filename, rows) {
  if (!rows.length) throw new Error("There are no rows to export.");
  const columns = [...new Set(rows.flatMap(row => Object.keys(row)))];
  const csvCell = value => {
    let text = String(value ?? "");
    if (/^\s*[=+\-@]/.test(text)) text = `'${text}`;
    return `"${text.replace(/"/g, '""')}"`;
  };
  const csv = [columns, ...rows.map(row => columns.map(column => row[column] ?? ""))]
    .map(row => row.map(csvCell).join(","))
    .join("\r\n");
  const url = URL.createObjectURL(new Blob([`\uFEFF${csv}`], { type: "text/csv;charset=utf-8" }));
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  link.click();
  URL.revokeObjectURL(url);
}

async function loadCompleteReport(report, query = "") {
  const limit = 100;
  const rows = [];
  let offset = 0;
  while (true) {
    const result = await adminApi({
      action: report,
      limit,
      offset,
      ...(report === "users" ? { query } : {})
    });
    const page = report === "users" ? result.users || [] : result.rows || [];
    rows.push(...page);
    if (page.length < limit) return rows;
    offset += page.length;
  }
}

function adminTable(headers, rows, emptyText) {
  if (!rows.length) return `<p>${escapeHtml(emptyText)}</p>`;
  return `<div class="table-wrap"><table class="data-table"><thead><tr>${headers.map(header => `<th>${escapeHtml(header.label)}</th>`).join("")}</tr></thead><tbody>${rows.map(row => `<tr>${headers.map(header => `<td>${header.render ? header.render(row) : escapeHtml(row[header.key] ?? "—")}</td>`).join("")}</tr>`).join("")}</tbody></table></div>`;
}

export async function renderAdminMembershipSections(root, currentUser) {
  if (!root) return;
  root.innerHTML = `<h2>Membership and account administration</h2><p>Loading membership, account, payment and audit data…</p>`;
  try {
    const [overview, users, plans, memberships, subscriptions, payments, freeUsage, activity, ads, blogs, jobs, businesses] = await Promise.all([
      adminApi({ action: "overview" }),
      adminApi({ action: "users", limit: 25, offset: 0 }),
      adminApi({ action: "plans" }),
      adminApi({ action: "memberships", limit: 100 }),
      adminApi({ action: "subscriptions", limit: 100 }),
      adminApi({ action: "payments", limit: 100 }),
      adminApi({ action: "free-usage", limit: 200 }),
      adminApi({ action: "activity", limit: 100 }),
      adminApi({ action: "content", table: "classified_ads" }),
      adminApi({ action: "content", table: "blog_posts" }),
      adminApi({ action: "content", table: "jobs" }),
      adminApi({ action: "content", table: "businesses" })
    ]);
    root.innerHTML = `<h2>Membership and account administration</h2>
      <div class="stat-grid membership-admin-stats" id="membership-admin-stats"></div>
      <details class="dashboard-panel" open><summary><h3>10. User management · 2. Registered · 3. Free · 4. Paid</h3></summary>
        <form id="admin-user-search" class="form-grid"><div class="field"><label for="admin-user-query">Search users by name or email</label><input id="admin-user-query" name="query" maxlength="120"></div><div class="field"><button class="button button-small" type="submit">Search</button></div></form>
        <div id="admin-user-results"></div><div id="admin-user-detail"></div>
      </details>
      <details class="dashboard-panel"><summary><h3>11. Classified ads management</h3></summary><div id="admin-content-ads"></div></details>
      <details class="dashboard-panel"><summary><h3>12. Blog management</h3></summary><div id="admin-content-blogs"></div></details>
      <details class="dashboard-panel"><summary><h3>13. Job listings management</h3></summary><div id="admin-content-jobs"></div></details>
      <details class="dashboard-panel"><summary><h3>14. Business listings management</h3></summary><div id="admin-content-businesses"></div></details>
      <details class="dashboard-panel"><summary><h3>15. Free usage tracking</h3></summary><div id="admin-free-usage"></div><button class="button button-outline button-small" data-export="free-usage">Download CSV</button></details>
      <details class="dashboard-panel"><summary><h3>16. Membership and subscription management · 5. Active · 6. Expired</h3></summary><div id="admin-memberships"></div><h4>Recurring subscriptions</h4><div id="admin-subscriptions"></div></details>
      <details class="dashboard-panel"><summary><h3>17. Payment transaction history · 7–9. Payments and revenue</h3></summary><div id="admin-payments"></div><button class="button button-outline button-small" data-export="payments">Download CSV</button></details>
      <details class="dashboard-panel"><summary><h3>18. CSV reports</h3></summary><p>Exports retrieve the full dataset in pages. The users report follows the current search filter.</p><button class="button button-outline button-small" data-export="users">Users CSV</button> <button class="button button-outline button-small" data-export="payments">Payments CSV</button> <button class="button button-outline button-small" data-export="free-usage">Free usage CSV</button></details>
      <details class="dashboard-panel"><summary><h3>19. Plan and offer settings</h3></summary><p>Prices, durations and the 72-hour window are server-controlled. Availability can be paused; active checkouts still settle normally.</p><div id="admin-plans"></div></details>
      <details class="dashboard-panel"><summary><h3>20. Admin activity logs</h3></summary><div id="admin-activity"></div></details>`;

    const stats = [
      ["Registered users", overview.total_users],
      ["Free users", overview.free_users],
      ["Paid users", overview.paid_users],
      ["Active memberships", overview.active_memberships],
      ["Expired memberships", overview.expired_memberships],
      ["₹9 payments", overview.intro_payments],
      ["₹499 monthly payments", overview.standard_payments],
      ["Verified revenue", money(overview.verified_revenue_paise)]
    ];
    root.querySelector("#membership-admin-stats").innerHTML = stats
      .map(([label, value]) => `<div class="stat-card"><span>${escapeHtml(label)}</span><strong>${escapeHtml(value)}</strong></div>`)
      .join("");

    let currentUsers = users.users || [];
    let currentPayments = payments.rows || [];
    let currentUsage = freeUsage.rows || [];
    const renderUsers = rows => {
      root.querySelector("#admin-user-results").innerHTML = adminTable([
        { label: "Name", render: row => `<button class="button-quiet" data-user-detail="${escapeHtml(row.id)}">${escapeHtml(row.full_name || "Member")}</button>` },
        { label: "Email", key: "email" },
        { label: "Registered", render: row => dateTime(row.created_at) },
        { label: "Status", key: "account_status" },
        { label: "Action", render: row => `<button class="button button-outline button-small" data-user-state="${row.account_status === "suspended" ? "restore" : "suspend"}" data-user-id="${escapeHtml(row.id)}">${row.account_status === "suspended" ? "Restore" : "Suspend"}</button>` }
      ], rows, "No matching users.");
    };
    const renderContent = (target, rows, table) => {
      root.querySelector(target).innerHTML = adminTable([
        { label: "Content", render: row => escapeHtml(row.title || row.name || row.company_name || "Untitled") },
        { label: "Category", key: "category" },
        { label: "Location", render: row => escapeHtml([row.city].filter(Boolean).join(", ") || "—") },
        { label: "Status", key: "status" },
        { label: "Created", render: row => dateTime(row.created_at) },
        { label: "Action", render: row => {
          const next = row.status === "published" ? (table === "businesses" ? "suspended" : "archived") : "published";
          return `<button class="button button-outline button-small" data-content-state="${next}" data-content-table="${table}" data-content-id="${escapeHtml(row.id)}">${next === "published" ? "Publish" : "Archive"}</button>`;
        } }
      ], rows, "No content found.");
    };
    renderUsers(currentUsers);
    renderContent("#admin-content-ads", ads.rows || [], "classified_ads");
    renderContent("#admin-content-blogs", blogs.rows || [], "blog_posts");
    renderContent("#admin-content-jobs", jobs.rows || [], "jobs");
    renderContent("#admin-content-businesses", businesses.rows || [], "businesses");
    root.querySelector("#admin-free-usage").innerHTML = adminTable([
      { label: "User", render: row => escapeHtml(row.user?.email || row.user_id) },
      { label: "Category", render: row => escapeHtml(categoryLabels[row.category] || row.category) },
      { label: "First used", render: row => dateTime(row.first_used_at) },
      { label: "Source record", key: "source_id" }
    ], currentUsage, "No free credits have been used.");
    root.querySelector("#admin-memberships").innerHTML = adminTable([
      { label: "User ID", key: "user_id" },
      { label: "Plan", render: row => escapeHtml(row.plan?.name || "Membership") },
      { label: "Status", render: row => {
        const status = row.status === "cancelled" ? "cancelled" : new Date(row.expires_at) <= new Date() ? "expired" : new Date(row.starts_at) > new Date() ? "scheduled" : "active";
        return escapeHtml(status);
      } },
      { label: "Starts", render: row => dateTime(row.starts_at) },
      { label: "Expires", render: row => dateTime(row.expires_at) },
      { label: "Action", render: row => row.status === "active" && new Date(row.expires_at) > new Date()
        ? row.razorpay_subscription_id
          ? "Manage in recurring subscriptions"
          : `<button class="button button-outline button-small" data-cancel-membership="${escapeHtml(row.id)}">Cancel access</button>`
        : "—" }
    ], memberships.rows || [], "No memberships yet.");
    root.querySelector("#admin-subscriptions").innerHTML = adminTable([
      { label: "User ID", key: "user_id" },
      { label: "Plan", render: row => escapeHtml(row.plan?.name || "Subscription") },
      { label: "Status", render: row => `${escapeHtml(row.status)}${row.cancel_at_cycle_end ? " · cancel at period end" : ""}` },
      { label: "Period end", render: row => dateTime(row.current_period_end) },
      { label: "Action", render: row => !["cancelled", "completed", "expired"].includes(row.status) && !row.cancel_at_cycle_end
        ? `<button class="button button-outline button-small" data-cancel-subscription="${escapeHtml(row.razorpay_subscription_id)}">Stop future charges</button>`
        : "—" }
    ], subscriptions.rows || [], "No recurring subscriptions.");
    root.querySelector("#admin-payments").innerHTML = adminTable([
      { label: "User ID", key: "user_id" },
      { label: "Plan", render: row => escapeHtml(row.plan?.name || "Membership") },
      { label: "Amount", render: row => money(row.amount_paise) },
      { label: "Status", key: "status" },
      { label: "Order ID", key: "order_id" },
      { label: "Subscription", key: "subscription_id" },
      { label: "Invoice", key: "invoice_id" },
      { label: "Payment ID", key: "payment_id" },
      { label: "Created", render: row => dateTime(row.created_at) },
      { label: "Paid", render: row => dateTime(row.paid_at) }
    ], currentPayments, "No transactions yet.");
    root.querySelector("#admin-plans").innerHTML = adminTable([
      { label: "Plan", key: "name" },
      { label: "Price", render: row => money(row.amount_paise) },
      { label: "Duration", render: row => row.billing_type === "subscription"
        ? `Monthly · ${escapeHtml(row.billing_cycles)} cycles`
        : `${escapeHtml(row.duration_days)} days` },
      { label: "Intro window", render: row => row.intro_window_hours ? `${escapeHtml(row.intro_window_hours)} hours` : "After intro expires" },
      { label: "Availability", render: row => `<button class="button button-outline button-small" data-plan-toggle="${escapeHtml(row.code)}" data-plan-active="${row.is_active}">${row.is_active ? "Pause plan" : "Enable plan"}</button>` }
    ], plans.rows || [], "No plans configured.");
    root.querySelector("#admin-activity").innerHTML = adminTable([
      { label: "Time", render: row => dateTime(row.created_at) },
      { label: "Actor", key: "actor_id" },
      { label: "Action", key: "action" },
      { label: "Entity", render: row => `${escapeHtml(row.entity_type)} ${escapeHtml(row.entity_id || "")}` },
      { label: "Details", render: row => escapeHtml(JSON.stringify(row.details || {})) }
    ], activity.rows || [], "No admin activity recorded yet.");

    let currentUserQuery = "";
    root.querySelector("#admin-user-search").addEventListener("submit", async event => {
      event.preventDefault();
      const form = event.currentTarget;
      const button = form.querySelector('button[type="submit"]');
      button.disabled = true;
      try {
        currentUserQuery = String(new FormData(form).get("query") || "");
        const results = await adminApi({ action: "users", query: currentUserQuery, limit: 25, offset: 0 });
        currentUsers = results.users || [];
        renderUsers(currentUsers);
      } catch (error) {
        showToast(error.message, "error");
      } finally {
        button.disabled = false;
      }
    });
    root.addEventListener("click", async event => {
      const button = event.target instanceof Element ? event.target.closest("button") : null;
      if (!button) return;
      button.disabled = true;
      try {
        if (button.dataset.userDetail) {
          const details = await adminApi({ action: "user-detail", userId: button.dataset.userDetail });
          root.querySelector("#admin-user-detail").innerHTML = `<h3>${escapeHtml(details.profile.full_name || "User details")}</h3><p>${escapeHtml(details.profile.email || "")} · ${escapeHtml(details.profile.account_status)}</p><h4>Memberships</h4>${adminTable([{label:"Plan",render:row=>escapeHtml(row.plan?.name||"Membership")},{label:"Status",key:"status"},{label:"Expires",render:row=>dateTime(row.expires_at)}],details.memberships,"No memberships.")}<h4>Subscriptions</h4>${adminTable([{label:"Plan",render:row=>escapeHtml(row.plan?.name||"Subscription")},{label:"Status",render:row=>`${escapeHtml(row.status)}${row.cancel_at_cycle_end?" · ending this period":""}`},{label:"Period end",render:row=>dateTime(row.current_period_end)}],details.subscriptions,"No subscriptions.")}<h4>Payments</h4>${adminTable([{label:"Plan",render:row=>escapeHtml(row.plan?.name||"Membership")},{label:"Amount",render:row=>money(row.amount_paise)},{label:"Status",key:"status"}],details.payments,"No payments.")}<h4>Free usage</h4>${adminTable([{label:"Category",render:row=>escapeHtml(categoryLabels[row.category]||row.category)},{label:"Used",render:row=>dateTime(row.first_used_at)}],details.free_usage,"No credits used.")}`;
        } else if (button.dataset.userState) {
          const action = button.dataset.userState;
          if (!confirm(`${action === "suspend" ? "Suspend" : "Restore"} this account?`)) return;
          await adminApi({ action, userId: button.dataset.userId });
          showToast(`Account ${action === "suspend" ? "suspended" : "restored"}.`);
          const result = await adminApi({ action: "users", query: currentUserQuery, limit: 25, offset: 0 });
          currentUsers = result.users || [];
          renderUsers(currentUsers);
        } else if (button.dataset.contentState) {
          await adminApi({
            action: "set-content-status",
            table: button.dataset.contentTable,
            id: button.dataset.contentId,
            status: button.dataset.contentState
          });
          showToast("Content status updated.");
          location.reload();
        } else if (button.dataset.cancelMembership) {
          if (!confirm("Cancel this membership now? This does not refund its payment.")) return;
          await adminApi({ action: "cancel-membership", membershipId: button.dataset.cancelMembership });
          showToast("Membership cancelled.");
          location.reload();
        } else if (button.dataset.cancelSubscription) {
          if (!confirm("Stop future subscription charges? Paid access continues until the current billing period ends.")) return;
          const result = await adminApi({
            action: "cancel-subscription",
            subscriptionId: button.dataset.cancelSubscription
          });
          showToast(result.cancel_at_cycle_end
            ? `Future charges stopped. Access continues until ${dateTime(result.current_period_end)}.`
            : "Subscription cancelled.");
          location.reload();
        } else if (button.dataset.planToggle) {
          const next = button.dataset.planActive !== "true";
          await adminApi({ action: "set-plan-active", code: button.dataset.planToggle, isActive: next });
          showToast(`Plan ${next ? "enabled" : "paused"}.`);
          location.reload();
        } else if (button.dataset.export) {
          const report = button.dataset.export;
          if (report === "users") {
            const rows = await loadCompleteReport(report, currentUserQuery);
            csvDownload("digitalduniya360-users.csv", rows);
          } else if (report === "payments") {
            const rows = await loadCompleteReport(report);
            csvDownload("digitalduniya360-payments.csv", rows.map(row => ({
              ...row, plan: row.plan?.name || "", amount: money(row.amount_paise)
            })));
          } else {
            const rows = await loadCompleteReport(report);
            csvDownload("digitalduniya360-free-usage.csv", rows.map(row => ({
              user_id: row.user_id, email: row.user?.email || "", category: row.category,
              first_used_at: row.first_used_at, source_id: row.source_id
            })));
          }
        }
      } catch (error) {
        showToast(error.message, "error");
      } finally {
        button.disabled = false;
      }
    });
  } catch (error) {
    root.innerHTML = `<h2>Membership administration unavailable</h2>${messageHtml(error.message, "error")}`;
  }
}
