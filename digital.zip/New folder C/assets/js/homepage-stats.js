// Edit values and copy in this object to update the homepage.
export const homepageStats = {
  seoTitle: "DigitalDuniya360 – India's Digital Marketplace & Blog Platform",
  seoDescription: "Discover blogs, business listings, classified ads, product listings, deals and digital resources on DigitalDuniya360, India's all-in-one online platform.",
  whyChoose: {
    eyebrow: "Made for your digital journey",
    title: "Why Choose DigitalDuniya360?",
    items: [
      { icon: "＋", title: "Free Account Registration", description: "Create an account to manage your community activity." },
      { icon: "↗", title: "Easy Ad Posting", description: "Share a product or service listing with the community." },
      { icon: "◷", title: "Job Opportunities", description: "Browse openings or share a job opportunity." },
      { icon: "⌂", title: "Business Promotion", description: "Help people discover your business and services." },
      { icon: "⌕", title: "Free SEO Tools", description: "Use practical browser-based tools for your digital work." },
      { icon: "▤", title: "Blogs & Knowledge Resources", description: "Explore community perspectives and helpful resources." }
    ]
  },
  privacy: {
    eyebrow: "Your account and community",
    title: "Your Privacy Matters",
    description: "Account details you provide support sign-in and the features you choose. Content in public listings may be visible to other visitors. Avoid sharing passwords, financial details or other sensitive information in public posts."
  },
  join: {
    eyebrow: "Join our community",
    headline: "Be Part of India's Growing Digital Community",
    description: "Discover opportunities, promote your business, find jobs and connect with people across India.",
    buttons: [
      { label: "Create Free Account", href: "register.html", style: "primary" },
      { label: "Post Your First Ad", href: "post-ad.html", style: "secondary" },
      { label: "Explore Jobs", href: "jobs.html", style: "secondary" }
    ]
  }
};
