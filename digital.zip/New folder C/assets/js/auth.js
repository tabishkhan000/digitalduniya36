import { getSupabase, isSupabaseConfigured } from "./supabase.js";

export async function submitAuthForm(form, mode, recovering = false) {
  if (!isSupabaseConfigured) throw new Error("Supabase isn't configured. Check assets/js/config.js.");
  const supabase = await getSupabase();
  const values = Object.fromEntries(new FormData(form));

  if (recovering) {
    const { error } = await supabase.auth.updateUser({ password: values.password });
    if (error) throw error;
    return { message: "Password updated. You can now sign in.", redirect: "login.html" };
  }
  if (mode === "login") {
    const { error } = await supabase.auth.signInWithPassword({ email: values.email, password: values.password });
    if (error) throw error;
    return { message: "Signed in. Redirecting…", redirect: "user-dashboard.html" };
  }
  const { data, error } = await supabase.auth.signUp({
    email: values.email,
    password: values.password,
    options: {
      data: { full_name: values.full_name.trim() },
      emailRedirectTo: `${location.origin}/login.html`
    }
  });
  if (error) throw error;
  return {
    message: data.session
      ? "Account created and signed in."
      : "Account created. Check your email to verify your address.",
    redirect: data.session ? "user-dashboard.html" : ""
  };
}

export async function requestPasswordReset(email) {
  if (!isSupabaseConfigured) throw new Error("Supabase isn't configured. Check assets/js/config.js.");
  const address = email.trim().toLowerCase();
  if (!address) throw new Error("Enter your email address first.");
  const supabase = await getSupabase();
  const { error } = await supabase.auth.resetPasswordForEmail(address, {
    redirectTo: `${location.origin}/login.html?type=recovery`
  });
  if (error) throw error;
}

export async function signOut() {
  const supabase = await getSupabase();
  if (!supabase) throw new Error("Supabase isn't configured.");
  const { error } = await supabase.auth.signOut();
  if (error) throw error;
}
