import { SUPABASE_PUBLISHABLE_KEY, SUPABASE_URL } from "./config.js";

export const isSupabaseConfigured = /^https:\/\/[a-z0-9-]+\.supabase\.co\/?$/i.test(SUPABASE_URL)
  && SUPABASE_PUBLISHABLE_KEY.startsWith("sb_publishable_");
let clientPromise;

export async function getSupabase() {
  if (!isSupabaseConfigured) return null;
  if (!clientPromise) {
    clientPromise = import("https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/+esm")
      .then(({ createClient }) => createClient(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY, {
        auth: {
          persistSession: true,
          autoRefreshToken: true,
          detectSessionInUrl: true,
          flowType: "pkce"
        }
      }))
      .catch(error => {
        clientPromise = null;
        throw error;
      });
  }
  return clientPromise;
}

export async function checkSupabaseConnection() {
  if (!isSupabaseConfigured) {
    return { connected: false, databaseReady: false, message: "Supabase project URL or publishable key is missing." };
  }
  try {
    const authResponse = await fetch(`${SUPABASE_URL}/auth/v1/health`, {
      headers: { apikey: SUPABASE_PUBLISHABLE_KEY },
      cache: "no-store"
    });
    if (!authResponse.ok) {
      return { connected: false, databaseReady: false, message: `Supabase Auth returned HTTP ${authResponse.status}. Check the project URL and publishable key.` };
    }
    const databaseResponse = await fetch(`${SUPABASE_URL}/rest/v1/profiles?select=id&limit=1`, {
      headers: { apikey: SUPABASE_PUBLISHABLE_KEY },
      cache: "no-store"
    });
    if (databaseResponse.ok) {
      return { connected: true, databaseReady: true, message: "Supabase Auth and database are connected." };
    }
    const detail = await databaseResponse.json().catch(() => ({}));
    if (databaseResponse.status === 404 && detail.code === "PGRST205") {
      return { connected: true, databaseReady: false, message: "Supabase is reachable, but the profiles table is missing. Run database/schema.sql in the Supabase SQL Editor." };
    }
    if (databaseResponse.status === 401 || databaseResponse.status === 403) {
      return { connected: true, databaseReady: false, message: "Supabase is reachable, but database access was denied. Check the publishable key and RLS policies." };
    }
    return { connected: true, databaseReady: false, message: `Supabase is reachable, but the database check returned HTTP ${databaseResponse.status}${detail.message ? `: ${detail.message}` : "."}` };
  } catch (error) {
    return { connected: false, databaseReady: false, message: `Could not reach Supabase: ${error.message}` };
  }
}

export async function getUser() {
  const supabase = await getSupabase();
  if (!supabase) return null;
  const { data: sessionData, error: sessionError } = await supabase.auth.getSession();
  if (sessionError) throw sessionError;
  if (!sessionData.session) return null;
  const { data, error } = await supabase.auth.getUser();
  if (error) throw error;
  return data.user;
}

export async function fetchPublished(table, limit = 6) {
  const supabase = await getSupabase();
  if (!supabase) return [];
  const { data, error } = await supabase.from(table).select("*")
    .eq("status", "published").order("created_at", { ascending: false }).limit(limit);
  if (error) throw error;
  return data || [];
}

export async function submitOwned(table, values) {
  const supabase = await getSupabase();
  const user = await getUser();
  if (!user) throw new Error("Please sign in before submitting.");
  if (!supabase) throw new Error("Connect Supabase first to submit content.");
  const { data, error } = await supabase.rpc("submit_content_with_access", {
    p_category: table,
    p_payload: values
  });
  if (error) throw error;
  if (!data?.record) throw new Error("Submission completed without a returned record.");
  return { ...data.record, access: data.access };
}

export async function uploadOwnedImage(bucket, file, pathParts = []) {
  const supabase = await getSupabase();
  if (!supabase) throw new Error("Supabase is not configured. Add the project URL in assets/js/config.js.");
  const user = await getUser();
  if (!user) throw new Error("Please sign in before uploading an image.");
  const allowedTypes = ["image/jpeg", "image/png", "image/webp"];
  if (!allowedTypes.includes(file.type)) throw new Error("Only JPG, PNG or WebP images are accepted.");
  if (file.size > 5 * 1024 * 1024) throw new Error("Each image must be smaller than 5 MB.");
  const safeName = file.name.replace(/[^a-zA-Z0-9._-]/g, "_");
  const path = [user.id, ...pathParts, `${crypto.randomUUID()}-${safeName}`].join("/");
  const { data, error } = await supabase.storage.from(bucket).upload(path, file, {
    upsert: false,
    contentType: file.type
  });
  if (error) throw error;
  const { data: publicData } = supabase.storage.from(bucket).getPublicUrl(data.path);
  return { path: data.path, url: publicData.publicUrl };
}

export async function uploadAdImage(file, adId) {
  const supabase = await getSupabase();
  if (!supabase) throw new Error("Supabase is not configured. Add the project URL in assets/js/config.js.");
  const allowedTypes = ["image/jpeg", "image/png", "image/webp"];
  if (!allowedTypes.includes(file.type)) throw new Error("Only JPG, PNG or WebP images are accepted.");
  if (file.size > 5 * 1024 * 1024) throw new Error("Each image must be smaller than 5 MB.");
  const safeName = file.name.replace(/[^a-zA-Z0-9._-]/g, "_");
  const path = `ads/${adId}/${crypto.randomUUID()}-${safeName}`;
  const { data, error } = await supabase.storage.from("classified-images").upload(path, file, {
    upsert: false,
    contentType: file.type
  });
  if (error) throw error;
  const { data: publicData } = supabase.storage.from("classified-images").getPublicUrl(data.path);
  return { path: data.path, url: publicData.publicUrl };
}

export async function getProfile(userId) {
  const supabase = await getSupabase();
  if (!supabase) throw new Error("Supabase is not configured. Add the project URL in assets/js/config.js.");
  const { data, error } = await supabase.from("profiles").select("*").eq("id", userId).maybeSingle();
  if (error) throw error;
  return data;
}

export async function updateOwnProfile(userId, values) {
  const supabase = await getSupabase();
  if (!supabase) throw new Error("Supabase is not configured. Add the project URL in assets/js/config.js.");
  const { data, error } = await supabase.from("profiles").update(values).eq("id", userId).select().single();
  if (error) throw error;
  return data;
}
