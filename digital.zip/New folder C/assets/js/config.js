// Public browser configuration only. Never place a Supabase secret/service-role key here.
export const SUPABASE_URL = "https://prqdjdyebdabbjhsruqz.supabase.co";
export const SUPABASE_PUBLISHABLE_KEY = "sb_publishable_8UrgwjCmpZh7TBlU-oA1gw_cvNx_cWE";
